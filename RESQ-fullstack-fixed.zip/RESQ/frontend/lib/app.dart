import 'package:flutter/material.dart';
import 'config/theme.dart';
import 'config/app_config.dart';
import 'services/api_service.dart';
import 'services/auth_service.dart';
import 'screens/splash_screen.dart';
import 'screens/auth/role_selection_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/donor/donor_dashboard.dart';
import 'screens/admin/admin_dashboard.dart';
import 'screens/transporter/transporter_dashboard.dart';

class ResqApp extends StatefulWidget {
  const ResqApp({super.key});

  @override
  State<ResqApp> createState() => _ResqAppState();
}

class _ResqAppState extends State<ResqApp> {
  final api = ApiService();
  late final AuthService auth;

  @override
  void initState() {
    super.initState();
    auth = AuthService(api);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: ResqTheme.light,
      home: SplashScreen(auth: auth),
      routes: {
        '/role': (_) => RoleSelectionScreen(auth: auth),
        '/login': (_) => LoginScreen(auth: auth),
        '/register': (_) => RegisterScreen(auth: auth),
        '/donor': (_) => DonorDashboard(auth: auth),
        '/admin': (_) => AdminDashboard(auth: auth),
        '/transporter': (_) => TransporterDashboard(auth: auth),
      },
    );
  }
}
