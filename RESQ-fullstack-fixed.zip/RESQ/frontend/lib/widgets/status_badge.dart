import 'package:flutter/material.dart';
import '../config/theme.dart';

class StatusBadge extends StatelessWidget {
  final String status;
  const StatusBadge({super.key, required this.status});

  Color get _color {
    switch (status.toUpperCase()) {
      case 'PENDING_APPROVAL':
      case 'PLANNED':
      case 'ASSIGNED':
        return ResqTheme.orange;
      case 'APPROVED':
      case 'TRANSPORT_PENDING':
      case 'TRANSPORT_ARRANGED':
      case 'READY_FOR_DISPATCH':
        return Colors.blue;
      case 'IN_TRANSIT':
        return ResqTheme.teal;
      case 'RECEIVED':
      case 'COMPLETED':
      case 'ARRIVED':
        return ResqTheme.green;
      case 'REJECTED':
      case 'CANCELLED':
        return ResqTheme.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status.replaceAll('_', ' '),
        style: TextStyle(color: _color, fontSize: 11, fontWeight: FontWeight.w600),
      ),
    );
  }
}
