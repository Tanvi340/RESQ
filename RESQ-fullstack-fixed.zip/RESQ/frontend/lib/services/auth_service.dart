import '../models/user.dart';
import 'api_service.dart';

class AuthService {
  final ApiService api;
  User? currentUser;

  AuthService(this.api);

  Future<User> login(String email, String password) async {
    final data = await api.post(
      '/auth/login',
      body: {'email': email, 'password': password},
      auth: false,
    ) as Map<String, dynamic>;
    await api.saveTokens(
      data['access_token'] as String,
      data['refresh_token'] as String,
    );
    currentUser = User.fromJson(data['user'] as Map<String, dynamic>);
    return currentUser!;
  }

  Future<User> register({
    required String fullName,
    required String email,
    required String password,
    String role = 'DONOR',
    String? phone,
  }) async {
    final data = await api.post(
      '/auth/register',
      body: {
        'full_name': fullName,
        'email': email,
        'password': password,
        'role': role,
        if (phone != null) 'phone_number': phone,
      },
      auth: false,
    ) as Map<String, dynamic>;
    return User.fromJson(data);
  }

  Future<User?> loadMe() async {
    final token = await api.getToken();
    if (token == null) return null;
    try {
      final data = await api.get('/auth/me') as Map<String, dynamic>;
      currentUser = User.fromJson(data);
      return currentUser;
    } catch (_) {
      await api.clearTokens();
      return null;
    }
  }

  Future<void> logout() async {
    try {
      await api.post('/auth/logout');
    } catch (_) {}
    await api.clearTokens();
    currentUser = null;
  }
}
