import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../config/api_config.dart';

class ApiException implements Exception {
  final String message;
  final String? errorCode;
  final int statusCode;
  ApiException(this.message, {this.errorCode, this.statusCode = 400});
  @override
  String toString() => message;
}

class ApiService {
  final _storage = const FlutterSecureStorage();
  static const _tokenKey = 'access_token';
  static const _refreshKey = 'refresh_token';

  Future<String?> getToken() => _storage.read(key: _tokenKey);
  Future<void> saveTokens(String access, String refresh) async {
    await _storage.write(key: _tokenKey, value: access);
    await _storage.write(key: _refreshKey, value: refresh);
  }

  Future<void> clearTokens() async {
    await _storage.delete(key: _tokenKey);
    await _storage.delete(key: _refreshKey);
  }

  Future<Map<String, String>> _headers({bool auth = true}) async {
    final h = {'Content-Type': 'application/json', 'Accept': 'application/json'};
    if (auth) {
      final t = await getToken();
      if (t != null) h['Authorization'] = 'Bearer $t';
    }
    return h;
  }

  Future<dynamic> get(String path, {bool auth = true}) async {
    try {
      final res = await http
          .get(Uri.parse('${ApiConfig.baseUrl}$path'), headers: await _headers(auth: auth))
          .timeout(ApiConfig.timeout);
      return _handle(res);
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        'Network error: $e. Check backend is running and CORS allows this origin.',
      );
    }
  }

  Future<dynamic> post(String path, {Map<String, dynamic>? body, bool auth = true}) async {
    try {
      final res = await http
          .post(
            Uri.parse('${ApiConfig.baseUrl}$path'),
            headers: await _headers(auth: auth),
            body: body != null ? jsonEncode(body) : null,
          )
          .timeout(ApiConfig.timeout);
      return _handle(res);
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        'Network error: $e. Check backend is running and CORS allows this origin.',
      );
    }
  }

  Future<dynamic> patch(String path, {Map<String, dynamic>? body, bool auth = true}) async {
    try {
      final res = await http
          .patch(
            Uri.parse('${ApiConfig.baseUrl}$path'),
            headers: await _headers(auth: auth),
            body: body != null ? jsonEncode(body) : null,
          )
          .timeout(ApiConfig.timeout);
      return _handle(res);
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        'Network error: $e. Check backend is running and CORS allows this origin.',
      );
    }
  }

  dynamic _handle(http.Response res) {
    Map<String, dynamic>? json;
    try {
      json = jsonDecode(res.body) as Map<String, dynamic>?;
    } catch (_) {}

    if (res.statusCode >= 200 && res.statusCode < 300) {
      return json?['data'] ?? json;
    }
    final msg = json?['message']?.toString() ?? 'Request failed (${res.statusCode})';
    final code = json?['error_code']?.toString();
    throw ApiException(msg, errorCode: code, statusCode: res.statusCode);
  }
}
