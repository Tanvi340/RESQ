import 'package:flutter/material.dart';
import '../../models/donation.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';
import '../../widgets/status_badge.dart';

class DonationHistoryScreen extends StatefulWidget {
  final AuthService auth;
  const DonationHistoryScreen({super.key, required this.auth});

  @override
  State<DonationHistoryScreen> createState() => _DonationHistoryScreenState();
}

class _DonationHistoryScreenState extends State<DonationHistoryScreen> {
  List<Donation> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await widget.auth.api.get('/donations/my') as List;
      setState(() {
        _items = data.map((e) => Donation.fromJson(e as Map<String, dynamic>)).toList();
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My donations')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _items.length,
              itemBuilder: (_, i) {
                final d = _items[i];
                return Card(
                  child: ListTile(
                    title: Text(d.resourceName),
                    subtitle: Text('${d.quantity} ${d.unit} → ${d.hubName}\n${d.createdAt ?? ''}'),
                    isThreeLine: true,
                    trailing: StatusBadge(status: d.status),
                  ),
                );
              },
            ),
    );
  }
}
