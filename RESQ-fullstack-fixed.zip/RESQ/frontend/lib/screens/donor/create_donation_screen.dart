import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../models/hub.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';

class CreateDonationScreen extends StatefulWidget {
  final AuthService auth;
  const CreateDonationScreen({super.key, required this.auth});

  @override
  State<CreateDonationScreen> createState() => _CreateDonationScreenState();
}

class _CreateDonationScreenState extends State<CreateDonationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _qty = TextEditingController(text: '10');
  final _desc = TextEditingController();
  List<Map<String, dynamic>> _resources = [];
  int? _resourceId;
  String _unit = 'units';
  List<Hub> _hubs = [];
  Hub? _selectedHub;
  bool _loadingResources = true;
  bool _loadingHubs = false;
  bool _submitting = false;
  String? _error;
  String? _info;

  // Sample Chennai location (matches seed hubs)
  static const double _lat = 13.0827;
  static const double _lon = 80.2707;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  @override
  void dispose() {
    _qty.dispose();
    _desc.dispose();
    super.dispose();
  }

  Future<void> _bootstrap() async {
    await _loadResources();
    if (_resourceId != null) {
      await _findHubs();
    }
  }

  Future<void> _loadResources() async {
    setState(() {
      _loadingResources = true;
      _error = null;
    });
    try {
      List data;
      try {
        data = await widget.auth.api.get('/hubs/resources/catalog', auth: false) as List;
      } catch (_) {
        data = await widget.auth.api.get('/admin/resources') as List;
      }
      setState(() {
        _resources = data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
        if (_resources.isNotEmpty) {
          _resourceId = _resources.first['id'] is int
              ? _resources.first['id'] as int
              : (_resources.first['id'] as num).toInt();
          _unit = _resources.first['default_unit'] as String? ?? 'units';
        } else {
          _error = 'No resources in database. Run: python seed.py';
        }
        _loadingResources = false;
      });
    } on ApiException catch (e) {
      setState(() {
        _error = 'Could not load resources: ${e.message}';
        _loadingResources = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Could not load resources. Is the backend running?';
        _loadingResources = false;
      });
    }
  }

  Future<void> _findHubs() async {
    setState(() {
      _loadingHubs = true;
      _error = null;
      _info = null;
      _selectedHub = null;
      _hubs = [];
    });

    try {
      final qty = double.tryParse(_qty.text) ?? 10;
      List data = [];

      if (_resourceId != null) {
        try {
          data = await widget.auth.api.get(
            '/hubs/nearby?latitude=$_lat&longitude=$_lon&radius_km=100'
            '&resource_id=$_resourceId&quantity=$qty',
            auth: false,
          ) as List;
        } catch (_) {
          data = [];
        }
      }

      // Fallback: all active hubs
      if (data.isEmpty) {
        final all = await widget.auth.api.get('/hubs', auth: false) as List;
        data = all;
        _info = 'Showing all active hubs (nearby filter returned none).';
      } else {
        _info = 'Recommended hubs near you (ranked by distance & capacity).';
      }

      final hubs = <Hub>[];
      for (final e in data) {
        try {
          hubs.add(Hub.fromJson(Map<String, dynamic>.from(e as Map)));
        } catch (_) {
          // skip malformed entries
        }
      }

      // Prefer hubs that can accept, keep rank order
      hubs.sort((a, b) {
        final aOk = a.isAcceptable ? 0 : 1;
        final bOk = b.isAcceptable ? 0 : 1;
        if (aOk != bOk) return aOk - bOk;
        final as = a.score ?? 0;
        final bs = b.score ?? 0;
        return bs.compareTo(as);
      });

      setState(() {
        _hubs = hubs;
        _loadingHubs = false;
        if (hubs.isEmpty) {
          _error = 'No hubs found. Run python seed.py in the backend folder.';
        } else {
          // Auto-select first acceptable hub
          _selectedHub = hubs.firstWhere(
            (h) => h.isAcceptable,
            orElse: () => hubs.first,
          );
        }
      });
    } on ApiException catch (e) {
      setState(() {
        _error = e.message;
        _loadingHubs = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load hubs. Check backend + CORS.';
        _loadingHubs = false;
      });
    }
  }

  Future<void> _submit() async {
    if (_selectedHub == null || _resourceId == null) {
      setState(() => _error = 'Select a resource and a hub');
      return;
    }
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      await widget.auth.api.post('/donations', body: {
        'hub_id': _selectedHub!.id,
        'resource_id': _resourceId,
        'quantity': double.parse(_qty.text),
        'unit': _unit,
        'condition': 'Good',
        'description': _desc.text.trim().isEmpty ? null : _desc.text.trim(),
        'donor_latitude': _lat,
        'donor_longitude': _lon,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 12),
              Expanded(child: Text('Donation submitted for approval')),
            ],
          ),
          backgroundColor: ResqTheme.green,
        ),
      );
      Navigator.pop(context, true);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Submission failed');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ResqTheme.bg,
      appBar: AppBar(
        title: const Text('Create donation'),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: ResqTheme.heroGradient)),
      ),
      body: _loadingResources
          ? const Center(child: CircularProgressIndicator(color: ResqTheme.teal))
          : SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Header card
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: ResqTheme.tealGradient,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: ResqTheme.teal.withOpacity(0.25),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.volunteer_activism, color: Colors.white, size: 32),
                          SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Offer relief supplies',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  'Pick a resource, find a nearby hub, and submit.',
                                  style: TextStyle(color: Colors.white70, fontSize: 13),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Resource section
                    _sectionTitle(Icons.inventory_2_outlined, 'Resource details'),
                    const SizedBox(height: 10),
                    if (_resources.isEmpty)
                      _errorBox('No resources loaded. In backend folder run:\npython seed.py')
                    else
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            children: [
                              DropdownButtonFormField<int>(
                                value: _resourceId,
                                decoration: const InputDecoration(
                                  labelText: 'Resource type',
                                  prefixIcon: Icon(Icons.category_outlined),
                                ),
                                items: _resources.map((r) {
                                  final id = r['id'] is int
                                      ? r['id'] as int
                                      : (r['id'] as num).toInt();
                                  return DropdownMenuItem(
                                    value: id,
                                    child: Text('${r['name']} (${r['category']})'),
                                  );
                                }).toList(),
                                onChanged: (v) {
                                  setState(() {
                                    _resourceId = v;
                                    final r = _resources.firstWhere((e) {
                                      final id = e['id'] is int
                                          ? e['id'] as int
                                          : (e['id'] as num).toInt();
                                      return id == v;
                                    });
                                    _unit = r['default_unit'] as String? ?? 'units';
                                    _hubs = [];
                                    _selectedHub = null;
                                  });
                                  _findHubs();
                                },
                              ),
                              const SizedBox(height: 14),
                              TextFormField(
                                controller: _qty,
                                keyboardType: TextInputType.number,
                                decoration: InputDecoration(
                                  labelText: 'Quantity ($_unit)',
                                  prefixIcon: const Icon(Icons.numbers),
                                ),
                                validator: (v) {
                                  if (v == null ||
                                      double.tryParse(v) == null ||
                                      double.parse(v) <= 0) {
                                    return 'Enter a positive quantity';
                                  }
                                  return null;
                                },
                              ),
                              const SizedBox(height: 14),
                              TextFormField(
                                controller: _desc,
                                maxLines: 2,
                                decoration: const InputDecoration(
                                  labelText: 'Description (optional)',
                                  prefixIcon: Icon(Icons.notes_outlined),
                                  alignLabelWithHint: true,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                    const SizedBox(height: 24),
                    _sectionTitle(Icons.warehouse_outlined, 'Select a hub'),
                    const SizedBox(height: 10),

                    // Find hubs button
                    SizedBox(
                      height: 48,
                      child: ElevatedButton.icon(
                        onPressed: _loadingHubs ? null : _findHubs,
                        icon: _loadingHubs
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.my_location),
                        label: Text(
                          _loadingHubs ? 'Finding nearby hubs…' : 'Find / refresh hubs',
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: ResqTheme.navy,
                        ),
                      ),
                    ),

                    if (_info != null) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: ResqTheme.blue.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: ResqTheme.blue.withOpacity(0.2)),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.info_outline, size: 18, color: ResqTheme.blue),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                _info!,
                                style: TextStyle(color: ResqTheme.blue.withOpacity(0.9), fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],

                    if (_error != null) ...[
                      const SizedBox(height: 12),
                      _errorBox(_error!),
                    ],

                    const SizedBox(height: 14),

                    if (_loadingHubs)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 32),
                        child: Center(child: CircularProgressIndicator(color: ResqTheme.teal)),
                      )
                    else if (_hubs.isNotEmpty) ...[
                      Text(
                        '${_hubs.length} hub${_hubs.length == 1 ? '' : 's'} available',
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: ResqTheme.muted,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 10),
                      ..._hubs.map((h) => _HubCard(
                            hub: h,
                            selected: _selectedHub?.id == h.id,
                            onTap: () => setState(() => _selectedHub = h),
                          )),
                      const SizedBox(height: 20),
                      SizedBox(
                        height: 52,
                        child: ElevatedButton.icon(
                          onPressed: _submitting || _selectedHub == null ? null : _submit,
                          icon: _submitting
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Icon(Icons.send_rounded),
                          label: Text(
                            _submitting ? 'Submitting…' : 'Submit donation request',
                          ),
                        ),
                      ),
                    ] else if (!_loadingHubs && _resources.isNotEmpty)
                      Container(
                        margin: const EdgeInsets.only(top: 8),
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: ResqTheme.border),
                        ),
                        child: Column(
                          children: [
                            Icon(Icons.location_off_outlined,
                                size: 40, color: Colors.grey.shade400),
                            const SizedBox(height: 12),
                            Text(
                              'No hubs listed yet',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.grey.shade700,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'Tap “Find / refresh hubs”. If still empty, run seed.py and confirm the API returns data.',
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _sectionTitle(IconData icon, String title) {
    return Row(
      children: [
        Icon(icon, size: 20, color: ResqTheme.teal),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: ResqTheme.navy,
          ),
        ),
      ],
    );
  }

  Widget _errorBox(String msg) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: ResqTheme.red.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: ResqTheme.red.withOpacity(0.25)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.error_outline, color: ResqTheme.red, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Text(msg, style: const TextStyle(color: ResqTheme.red, fontSize: 13)),
          ),
        ],
      ),
    );
  }
}

class _HubCard extends StatelessWidget {
  final Hub hub;
  final bool selected;
  final VoidCallback onTap;

  const _HubCard({
    required this.hub,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final can = hub.isAcceptable;
    final statusColor = hub.operatingStatus.toUpperCase() == 'ACTIVE'
        ? ResqTheme.green
        : ResqTheme.orange;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: selected
                  ? ResqTheme.teal.withOpacity(0.08)
                  : Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: selected
                    ? ResqTheme.teal
                    : (can ? ResqTheme.border : ResqTheme.red.withOpacity(0.35)),
                width: selected ? 2 : 1,
              ),
              boxShadow: selected
                  ? [
                      BoxShadow(
                        color: ResqTheme.teal.withOpacity(0.15),
                        blurRadius: 10,
                        offset: const Offset(0, 3),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: selected
                        ? ResqTheme.teal
                        : ResqTheme.teal.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.warehouse_rounded,
                    color: selected ? Colors.white : ResqTheme.teal,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              hub.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: ResqTheme.navy,
                              ),
                            ),
                          ),
                          if (selected)
                            const Icon(Icons.check_circle, color: ResqTheme.teal, size: 22),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        [
                          if (hub.distanceKm != null)
                            '${hub.distanceKm!.toStringAsFixed(1)} km',
                          if (hub.city.isNotEmpty) hub.city,
                          if (hub.state.isNotEmpty) hub.state,
                        ].join(' · '),
                        style: const TextStyle(fontSize: 12, color: ResqTheme.muted),
                      ),
                      if (hub.address.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(
                          hub.address,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                        ),
                      ],
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          _chip(
                            Icons.inventory_2_outlined,
                            'Cap ${hub.availableCapacity.toStringAsFixed(0)}',
                            ResqTheme.blue,
                          ),
                          _chip(
                            Icons.circle,
                            hub.operatingStatus,
                            statusColor,
                          ),
                          if (!can)
                            _chip(
                              Icons.block,
                              'Cannot accept',
                              ResqTheme.red,
                            )
                          else if (hub.canAcceptDonation == true)
                            _chip(
                              Icons.check,
                              'Can accept',
                              ResqTheme.green,
                            ),
                          if (hub.score != null)
                            _chip(
                              Icons.star_outline,
                              'Score ${(hub.score! * 100).toStringAsFixed(0)}%',
                              ResqTheme.orange,
                            ),
                        ],
                      ),
                      if (hub.recommendationReasons != null &&
                          hub.recommendationReasons!.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text(
                          hub.recommendationReasons!.take(2).join(' · '),
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.grey.shade600,
                            fontStyle: FontStyle.italic,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _chip(IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
