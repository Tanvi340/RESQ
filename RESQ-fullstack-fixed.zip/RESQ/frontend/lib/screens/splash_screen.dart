import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../config/app_config.dart';
import '../services/auth_service.dart';

class SplashScreen extends StatefulWidget {
  final AuthService auth;
  const SplashScreen({super.key, required this.auth});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await Future.delayed(const Duration(milliseconds: 800));
    final user = await widget.auth.loadMe();
    if (!mounted) return;
    if (user == null) {
      Navigator.pushReplacementNamed(context, '/role');
    } else if (user.isDonor) {
      Navigator.pushReplacementNamed(context, '/donor');
    } else if (user.isAgent) {
      Navigator.pushReplacementNamed(context, '/transporter');
    } else {
      Navigator.pushReplacementNamed(context, '/admin');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ResqTheme.navy,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.health_and_safety, size: 72, color: ResqTheme.tealLight),
            const SizedBox(height: 16),
            Text(
              AppConfig.appName,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 36,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              AppConfig.appTagline,
              style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            const CircularProgressIndicator(color: ResqTheme.tealLight),
          ],
        ),
      ),
    );
  }
}
