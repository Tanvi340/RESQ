import 'package:flutter/material.dart';
import '../../services/auth_service.dart';

class InventoryScreen extends StatefulWidget {
  final AuthService auth;
  const InventoryScreen({super.key, required this.auth});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  List<dynamic> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await widget.auth.api.get('/inventory') as List;
      setState(() {
        _items = data;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Inventory')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Text('No inventory items'))
              : ListView.builder(
                  itemCount: _items.length,
                  itemBuilder: (_, i) {
                    final inv = _items[i] as Map<String, dynamic>;
                    final res = inv['resource'] as Map<String, dynamic>?;
                    return ListTile(
                      title: Text(res?['name']?.toString() ?? 'Resource #${inv['resource_id']}'),
                      subtitle: Text(
                        'Available: ${inv['available_quantity']} ${inv['unit']} · '
                        'Reserved: ${inv['reserved_quantity']}',
                      ),
                      leading: const Icon(Icons.inventory_2_outlined),
                    );
                  },
                ),
    );
  }
}
