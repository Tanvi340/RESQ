import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';

class CreateDeliveryScreen extends StatefulWidget {
  final AuthService auth;
  const CreateDeliveryScreen({super.key, required this.auth});

  @override
  State<CreateDeliveryScreen> createState() => _CreateDeliveryScreenState();
}

class _CreateDeliveryScreenState extends State<CreateDeliveryScreen> {
  final _destName = TextEditingController(text: 'Flood-affected zone — North Chennai');
  final _destAddr = TextEditingController(text: 'Tondiarpet low-lying area');
  final _lat = TextEditingController(text: '13.1265');
  final _lon = TextEditingController(text: '80.2950');
  final _qty = TextEditingController(text: '20');
  List<dynamic> _hubs = [];
  List<dynamic> _inventory = [];
  List<dynamic> _agents = [];
  int? _hubId;
  int? _resourceId;
  int? _agentId;
  bool _submitting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadHubs();
    _loadAgents();
  }

  Future<void> _loadAgents() async {
    try {
      final data = await widget.auth.api.get('/admin/agents') as List;
      setState(() {
        _agents = data;
        if (_agents.isNotEmpty) {
          _agentId = _agents.first['id'] as int;
        }
      });
    } catch (_) {
      // Agents optional at create time; can assign later
    }
  }

  Future<void> _loadHubs() async {
    try {
      final data = await widget.auth.api.get('/hubs') as List;
      setState(() {
        _hubs = data;
        if (_hubs.isNotEmpty) {
          _hubId = _hubs.first['id'] as int;
          _loadInventory();
        }
      });
    } catch (_) {}
  }

  Future<void> _loadInventory() async {
    if (_hubId == null) return;
    try {
      final data = await widget.auth.api.get('/hubs/$_hubId/inventory') as List;
      setState(() {
        _inventory = data;
        if (_inventory.isNotEmpty) {
          _resourceId = _inventory.first['resource_id'] as int;
        } else {
          _resourceId = null;
        }
      });
    } catch (_) {}
  }

  Future<void> _submit() async {
    if (_hubId == null || _resourceId == null) {
      setState(() => _error = 'Select hub and resource');
      return;
    }
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      await widget.auth.api.post('/deliveries', body: {
        'source_hub_id': _hubId,
        'destination_name': _destName.text.trim(),
        'destination_address': _destAddr.text.trim(),
        'destination_latitude': double.parse(_lat.text),
        'destination_longitude': double.parse(_lon.text),
        if (_agentId != null) 'assigned_agent_id': _agentId,
        'items': [
          {
            'resource_id': _resourceId,
            'quantity': double.parse(_qty.text),
          }
        ],
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _agentId != null
                ? 'Delivery created and agent assigned'
                : 'Delivery created (assign an agent from the deliveries list)',
          ),
        ),
      );
      Navigator.pop(context);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Failed to create delivery');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create relief delivery')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            DropdownButtonFormField<int>(
              value: _hubId,
              decoration: const InputDecoration(labelText: 'Source hub'),
              items: _hubs
                  .map((h) => DropdownMenuItem(
                        value: h['id'] as int,
                        child: Text(h['name'] as String? ?? 'Hub'),
                      ))
                  .toList(),
              onChanged: (v) {
                setState(() => _hubId = v);
                _loadInventory();
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _destName,
              decoration: const InputDecoration(labelText: 'Destination name'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _destAddr,
              decoration: const InputDecoration(labelText: 'Destination address'),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _lat,
                    decoration: const InputDecoration(labelText: 'Latitude'),
                    keyboardType: TextInputType.number,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _lon,
                    decoration: const InputDecoration(labelText: 'Longitude'),
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: _resourceId,
              decoration: const InputDecoration(labelText: 'Resource from inventory'),
              items: _inventory.map((inv) {
                final res = inv['resource'] as Map<String, dynamic>?;
                return DropdownMenuItem(
                  value: inv['resource_id'] as int,
                  child: Text(
                    '${res?['name'] ?? inv['resource_id']} '
                    '(avail: ${inv['available_quantity']})',
                  ),
                );
              }).toList(),
              onChanged: (v) => setState(() => _resourceId = v),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _qty,
              decoration: const InputDecoration(labelText: 'Quantity'),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int?>(
              value: _agentId,
              decoration: const InputDecoration(
                labelText: 'Assign delivery agent',
                helperText: 'Required before the agent can dispatch & share GPS',
              ),
              items: [
                const DropdownMenuItem<int?>(
                  value: null,
                  child: Text('— No agent yet —'),
                ),
                ..._agents.map((a) => DropdownMenuItem<int?>(
                      value: a['id'] as int,
                      child: Text('${a['full_name']} (${a['email']})'),
                    )),
              ],
              onChanged: (v) => setState(() => _agentId = v),
            ),
            if (_agents.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'No agents found. Run seed.py (agent1@resq.local) or assign later from the deliveries list.',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
              ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: const TextStyle(color: ResqTheme.red)),
            ],
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _submitting ? null : _submit,
              child: _submitting
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Text('Create delivery'),
            ),
          ],
        ),
      ),
    );
  }
}
