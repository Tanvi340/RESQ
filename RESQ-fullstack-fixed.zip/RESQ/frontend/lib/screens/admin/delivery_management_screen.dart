import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../models/delivery.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';
import '../../widgets/status_badge.dart';
import '../tracking/delivery_map_screen.dart';

class DeliveryManagementScreen extends StatefulWidget {
  final AuthService auth;
  const DeliveryManagementScreen({super.key, required this.auth});

  @override
  State<DeliveryManagementScreen> createState() => _DeliveryManagementScreenState();
}

class _DeliveryManagementScreenState extends State<DeliveryManagementScreen> {
  List<Delivery> _items = [];
  List<dynamic> _agents = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
    _loadAgents();
  }

  Future<void> _loadAgents() async {
    try {
      final data = await widget.auth.api.get('/admin/agents') as List;
      setState(() => _agents = data);
    } catch (_) {}
  }

  Future<void> _load() async {
    try {
      final data = await widget.auth.api.get('/deliveries') as List;
      setState(() {
        _items = data.map((e) => Delivery.fromJson(e as Map<String, dynamic>)).toList();
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  Future<void> _dispatch(int id) async {
    try {
      await widget.auth.api.post('/deliveries/$id/dispatch');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Delivery dispatched')),
        );
      }
      _load();
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    }
  }

  Future<void> _showAssignDialog(Delivery d) async {
    if (_agents.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No delivery agents found. Run seed.py (agent1@resq.local).'),
        ),
      );
      return;
    }

    int? selected = d.assignedAgentId ?? _agents.first['id'] as int;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Assign delivery agent'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Delivery #${d.id} → ${d.destinationName}'),
              const SizedBox(height: 16),
              DropdownButtonFormField<int>(
                value: selected,
                decoration: const InputDecoration(labelText: 'Agent'),
                items: _agents
                    .map(
                      (a) => DropdownMenuItem(
                        value: a['id'] as int,
                        child: Text('${a['full_name']} (${a['email']})'),
                      ),
                    )
                    .toList(),
                onChanged: (v) => setLocal(() => selected = v),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: selected == null ? null : () => Navigator.pop(ctx, true),
              child: const Text('Assign'),
            ),
          ],
        ),
      ),
    );

    if (confirmed != true || selected == null) return;

    try {
      await widget.auth.api.patch(
        '/deliveries/${d.id}/assign',
        body: {'assigned_agent_id': selected},
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Agent assigned')),
        );
      }
      _load();
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Relief deliveries')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Text('No deliveries yet'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _items.length,
                  itemBuilder: (_, i) {
                    final d = _items[i];
                    final canAssign =
                        d.status == 'PLANNED' || d.status == 'ASSIGNED';
                    final canDispatch =
                        d.status == 'ASSIGNED' || d.status == 'READY_FOR_DISPATCH';

                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    d.destinationName,
                                    style: const TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                ),
                                StatusBadge(status: d.status),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text('From: ${d.hubName}'),
                            Text('Agent: ${d.agentName}'),
                            const SizedBox(height: 10),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                if (canAssign)
                                  OutlinedButton.icon(
                                    onPressed: () => _showAssignDialog(d),
                                    icon: const Icon(Icons.person_add_alt_1, size: 18),
                                    label: Text(
                                      d.assignedAgentId == null ? 'Assign agent' : 'Change agent',
                                    ),
                                  ),
                                if (canDispatch)
                                  ElevatedButton.icon(
                                    onPressed: d.assignedAgentId == null
                                        ? null
                                        : () => _dispatch(d.id),
                                    icon: const Icon(Icons.local_shipping, size: 18),
                                    label: const Text('Dispatch'),
                                  ),
                                TextButton.icon(
                                  onPressed: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => DeliveryMapScreen(
                                        auth: widget.auth,
                                        delivery: d,
                                      ),
                                    ),
                                  ),
                                  icon: const Icon(Icons.map_outlined, size: 18),
                                  label: const Text('Map'),
                                ),
                              ],
                            ),
                            if (canDispatch && d.assignedAgentId == null)
                              Padding(
                                padding: const EdgeInsets.only(top: 6),
                                child: Text(
                                  'Assign an agent before dispatch.',
                                  style: TextStyle(fontSize: 12, color: ResqTheme.orange),
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
