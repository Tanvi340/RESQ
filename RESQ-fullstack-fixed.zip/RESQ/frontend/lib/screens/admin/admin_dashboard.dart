import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';
import 'pending_donations_screen.dart';
import 'inventory_screen.dart';
import 'delivery_management_screen.dart';
import 'create_delivery_screen.dart';

class AdminDashboard extends StatefulWidget {
  final AuthService auth;
  const AdminDashboard({super.key, required this.auth});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  Map<String, dynamic>? _stats;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await widget.auth.api.get('/admin/dashboard') as Map<String, dynamic>;
      setState(() {
        _stats = data;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = widget.auth.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: const Text('RESQ Admin'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await widget.auth.logout();
              if (context.mounted) Navigator.pushReplacementNamed(context, '/role');
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              'Welcome, ${user?.fullName ?? 'Admin'}',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: ResqTheme.navy),
            ),
            const SizedBox(height: 16),
            if (_loading)
              const Center(child: CircularProgressIndicator())
            else if (_stats != null) ...[
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  _Tile('Pending approvals', '${_stats!['pending_approvals'] ?? 0}', ResqTheme.orange),
                  _Tile('In transit', '${_stats!['in_transit'] ?? 0}', ResqTheme.teal),
                  _Tile('Received', '${_stats!['received'] ?? 0}', ResqTheme.green),
                  _Tile('Awaiting transport', '${_stats!['awaiting_transport'] ?? 0}', Colors.blue),
                ],
              ),
            ],
            const SizedBox(height: 28),
            const Text('Operations', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            _MenuTile(
              icon: Icons.pending_actions,
              title: 'Pending donations',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => PendingDonationsScreen(auth: widget.auth)),
              ),
            ),
            _MenuTile(
              icon: Icons.inventory_2_outlined,
              title: 'Hub inventory',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => InventoryScreen(auth: widget.auth)),
              ),
            ),
            _MenuTile(
              icon: Icons.local_shipping_outlined,
              title: 'Relief deliveries',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => DeliveryManagementScreen(auth: widget.auth)),
              ),
            ),
            _MenuTile(
              icon: Icons.add_road,
              title: 'Create delivery',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => CreateDeliveryScreen(auth: widget.auth)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _Tile(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: (MediaQuery.of(context).size.width - 44) / 2,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color)),
            Text(label, style: TextStyle(fontSize: 12, color: color.withOpacity(0.9))),
          ],
        ),
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _MenuTile({required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: ResqTheme.teal),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
