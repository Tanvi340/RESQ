import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../models/donation.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';
import '../../widgets/status_badge.dart';

class PendingDonationsScreen extends StatefulWidget {
  final AuthService auth;
  const PendingDonationsScreen({super.key, required this.auth});

  @override
  State<PendingDonationsScreen> createState() => _PendingDonationsScreenState();
}

class _PendingDonationsScreenState extends State<PendingDonationsScreen> {
  List<Donation> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await widget.auth.api.get('/donations?status=PENDING_APPROVAL') as List;
      setState(() {
        _items = data.map((e) => Donation.fromJson(e as Map<String, dynamic>)).toList();
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  Future<void> _approve(int id) async {
    try {
      await widget.auth.api.post('/donations/$id/approve', body: {});
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Approved')));
      _load();
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _reject(int id) async {
    try {
      await widget.auth.api.post('/donations/$id/reject', body: {
        'rejection_reason': 'Not suitable for current hub capacity or requirements',
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Rejected')));
      _load();
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _confirmReceipt(int id) async {
    try {
      await widget.auth.api.post('/donations/$id/confirm-receipt');
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Receipt confirmed')));
      _load();
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pending donations')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Text('No pending donations'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _items.length,
                  itemBuilder: (_, i) {
                    final d = _items[i];
                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(d.resourceName,
                                      style: const TextStyle(fontWeight: FontWeight.bold)),
                                ),
                                StatusBadge(status: d.status),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text('${d.quantity} ${d.unit} · Hub #${d.hubId}'),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                ElevatedButton(
                                  onPressed: () => _approve(d.id),
                                  child: const Text('Approve'),
                                ),
                                const SizedBox(width: 8),
                                OutlinedButton(
                                  onPressed: () => _reject(d.id),
                                  child: const Text('Reject'),
                                ),
                                const SizedBox(width: 8),
                                TextButton(
                                  onPressed: () => _confirmReceipt(d.id),
                                  child: const Text('Confirm receipt'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
