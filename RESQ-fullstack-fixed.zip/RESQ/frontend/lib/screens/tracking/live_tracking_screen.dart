import 'package:flutter/material.dart';
import '../../models/delivery.dart';
import '../../services/auth_service.dart';
import '../../widgets/status_badge.dart';
import 'delivery_map_screen.dart';

/// Lists deliveries the current user is allowed to track.
class LiveTrackingScreen extends StatefulWidget {
  final AuthService auth;
  const LiveTrackingScreen({super.key, required this.auth});

  @override
  State<LiveTrackingScreen> createState() => _LiveTrackingScreenState();
}

class _LiveTrackingScreenState extends State<LiveTrackingScreen> {
  List<Delivery> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await widget.auth.api.get('/deliveries/my') as List;
      setState(() {
        _items = data.map((e) => Delivery.fromJson(e as Map<String, dynamic>)).toList();
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Track deliveries')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'No relief deliveries linked to your donations yet.\n'
                      'Once the hub allocates your resources to a delivery, '
                      'you can track them here.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: _items.length,
                  itemBuilder: (_, i) {
                    final d = _items[i];
                    return ListTile(
                      title: Text(d.destinationName),
                      subtitle: Text('${d.hubName} · ${d.status}'),
                      trailing: StatusBadge(status: d.status),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => DeliveryMapScreen(auth: widget.auth, delivery: d),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
