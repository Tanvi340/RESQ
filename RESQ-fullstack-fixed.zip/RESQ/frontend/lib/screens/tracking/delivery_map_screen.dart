import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../../config/theme.dart';
import '../../config/api_config.dart';
import '../../models/delivery.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';
import '../../widgets/status_badge.dart';

class DeliveryMapScreen extends StatefulWidget {
  final AuthService auth;
  final Delivery delivery;
  const DeliveryMapScreen({super.key, required this.auth, required this.delivery});

  @override
  State<DeliveryMapScreen> createState() => _DeliveryMapScreenState();
}

class _DeliveryMapScreenState extends State<DeliveryMapScreen> {
  late Delivery _delivery;
  LocationUpdate? _location;
  Timer? _poll;
  final _mapController = MapController();

  @override
  void initState() {
    super.initState();
    _delivery = widget.delivery;
    _refreshLocation();
    _poll = Timer.periodic(
      Duration(seconds: ApiConfig.locationPollSeconds),
      (_) => _refreshLocation(),
    );
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  Future<void> _refreshLocation() async {
    try {
      final data = await widget.auth.api.get('/deliveries/${_delivery.id}/location')
          as Map<String, dynamic>;
      final loc = LocationUpdate.fromJson(data);
      // Refresh delivery detail for last_* fields
      final d = await widget.auth.api.get('/deliveries/${_delivery.id}') as Map<String, dynamic>;
      if (mounted) {
        setState(() {
          _location = loc;
          _delivery = Delivery.fromJson(d);
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final hubLat = (_delivery.sourceHub?['latitude'] as num?)?.toDouble() ?? 13.08;
    final hubLon = (_delivery.sourceHub?['longitude'] as num?)?.toDouble() ?? 80.27;
    final dest = LatLng(_delivery.destinationLatitude, _delivery.destinationLongitude);
    final hub = LatLng(hubLat, hubLon);
    LatLng? agent;
    if (_delivery.lastLatitude != null && _delivery.lastLongitude != null) {
      agent = LatLng(_delivery.lastLatitude!, _delivery.lastLongitude!);
    }

    final center = agent ?? dest;

    return Scaffold(
      appBar: AppBar(
        title: Text('Delivery #${_delivery.id}'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _refreshLocation),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: center,
                initialZoom: 12,
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.resq.app',
                ),
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: [hub, dest],
                      color: Colors.blueGrey.withOpacity(0.5),
                      strokeWidth: 3,
                      isDotted: true,
                    ),
                  ],
                ),
                MarkerLayer(
                  markers: [
                    Marker(
                      point: hub,
                      width: 40,
                      height: 40,
                      child: const Icon(Icons.warehouse, color: ResqTheme.navy, size: 36),
                    ),
                    Marker(
                      point: dest,
                      width: 40,
                      height: 40,
                      child: const Icon(Icons.flag, color: ResqTheme.red, size: 36),
                    ),
                    if (agent != null)
                      Marker(
                        point: agent,
                        width: 44,
                        height: 44,
                        child: Icon(
                          Icons.local_shipping,
                          color: (_location?.isLive ?? false) ? ResqTheme.teal : ResqTheme.orange,
                          size: 40,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        _delivery.destinationName,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ),
                    StatusBadge(status: _delivery.status),
                  ],
                ),
                const SizedBox(height: 8),
                Text('From: ${_delivery.hubName}'),
                Text('Agent: ${_delivery.agentName}'),
                const SizedBox(height: 8),
                _FreshnessChip(location: _location),
                if (_location?.recordedAt != null)
                  Text(
                    'Last update: ${_location!.recordedAt}',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  ),
                const SizedBox(height: 8),
                const Text(
                  'Hub (navy) · Destination (red) · Agent (teal/orange)',
                  style: TextStyle(fontSize: 11, color: Colors.grey),
                ),
                const Text(
                  'Dashed line is an approximate visual guide, not a road route.',
                  style: TextStyle(fontSize: 11, color: Colors.grey),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FreshnessChip extends StatelessWidget {
  final LocationUpdate? location;
  const _FreshnessChip({this.location});

  @override
  Widget build(BuildContext context) {
    final f = location?.freshness ?? 'LOCATION_UNAVAILABLE';
    Color c;
    String label;
    switch (f) {
      case 'LIVE':
        c = ResqTheme.green;
        label = 'LIVE';
        break;
      case 'STALE':
        c = ResqTheme.orange;
        label = 'STALE (${location?.ageSeconds ?? '?'}s ago)';
        break;
      case 'COMPLETED':
        c = ResqTheme.navy;
        label = 'COMPLETED';
        break;
      default:
        c = Colors.grey;
        label = 'LOCATION UNAVAILABLE';
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: c.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
      child: Text(label, style: TextStyle(color: c, fontWeight: FontWeight.w600, fontSize: 12)),
    );
  }
}
