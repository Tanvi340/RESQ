import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../config/app_config.dart';
import '../../services/auth_service.dart';

class RoleSelectionScreen extends StatelessWidget {
  final AuthService auth;
  const RoleSelectionScreen({super.key, required this.auth});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: ResqTheme.heroGradient),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 48),
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.health_and_safety, size: 40, color: Colors.white),
              ),
              const SizedBox(height: 16),
              Text(
                AppConfig.appName,
                style: const TextStyle(
                  fontSize: 34,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Disaster Relief Coordination',
                style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 14),
              ),
              const SizedBox(height: 36),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    color: ResqTheme.bg,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          'Sign in as',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: ResqTheme.navy,
                          ),
                        ),
                        const SizedBox(height: 20),
                        _RoleCard(
                          icon: Icons.volunteer_activism,
                          title: 'Donor',
                          subtitle: 'Donate resources & track deliveries',
                          color: ResqTheme.teal,
                          onTap: () => Navigator.pushNamed(
                            context,
                            '/login',
                            arguments: {'roleHint': 'DONOR'},
                          ),
                        ),
                        const SizedBox(height: 12),
                        _RoleCard(
                          icon: Icons.admin_panel_settings,
                          title: 'Hub Admin',
                          subtitle: 'Manage hubs, donations & deliveries',
                          color: ResqTheme.navy,
                          onTap: () => Navigator.pushNamed(
                            context,
                            '/login',
                            arguments: {'roleHint': 'HUB_ADMIN'},
                          ),
                        ),
                        const SizedBox(height: 12),
                        _RoleCard(
                          icon: Icons.local_shipping,
                          title: 'Delivery Agent',
                          subtitle: 'View assignments & share GPS location',
                          color: ResqTheme.orange,
                          onTap: () => Navigator.pushNamed(
                            context,
                            '/login',
                            arguments: {'roleHint': 'DELIVERY_AGENT'},
                          ),
                        ),
                        const Spacer(),
                        TextButton(
                          onPressed: () => Navigator.pushNamed(context, '/register'),
                          child: const Text('New donor? Create an account'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _RoleCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: ResqTheme.border),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: color, size: 26),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: color,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: const TextStyle(color: ResqTheme.muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey.shade400),
            ],
          ),
        ),
      ),
    );
  }
}
