import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../../config/theme.dart';
import '../../config/app_config.dart';
import '../../models/delivery.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';
import '../../widgets/status_badge.dart';
import '../tracking/delivery_map_screen.dart';

class TransporterDashboard extends StatefulWidget {
  final AuthService auth;
  const TransporterDashboard({super.key, required this.auth});

  @override
  State<TransporterDashboard> createState() => _TransporterDashboardState();
}

class _TransporterDashboardState extends State<TransporterDashboard> {
  List<Delivery> _items = [];
  bool _loading = true;
  Timer? _gpsTimer;
  int? _trackingDeliveryId;
  bool _simulating = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _gpsTimer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final data = await widget.auth.api.get('/deliveries/my') as List;
      setState(() {
        _items = data.map((e) => Delivery.fromJson(e as Map<String, dynamic>)).toList();
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  Future<void> _dispatch(Delivery d) async {
    try {
      await widget.auth.api.post('/deliveries/${d.id}/dispatch');
      _load();
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _complete(Delivery d) async {
    try {
      await widget.auth.api.post('/deliveries/${d.id}/complete');
      _stopTracking();
      _load();
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<bool> _ensurePermission() async {
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Location permission is required for live tracking')),
        );
      }
      return false;
    }
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please enable location services')),
        );
      }
      return false;
    }
    return true;
  }

  Future<void> _startLiveTracking(Delivery d) async {
    if (!await _ensurePermission()) return;
    _stopTracking();
    setState(() {
      _trackingDeliveryId = d.id;
      _simulating = false;
    });
    await _sendCurrentPosition(d.id, simulated: false);
    _gpsTimer = Timer.periodic(const Duration(seconds: 12), (_) {
      _sendCurrentPosition(d.id, simulated: false);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Live GPS tracking started')),
    );
  }

  /// Demo-only: walks a straight line from hub toward destination.
  Future<void> _startSimulatedTracking(Delivery d) async {
    if (!AppConfig.enableSimulatedTracking) return;
    _stopTracking();
    setState(() {
      _trackingDeliveryId = d.id;
      _simulating = true;
    });
    final hubLat = (d.sourceHub?['latitude'] as num?)?.toDouble() ?? 13.08;
    final hubLon = (d.sourceHub?['longitude'] as num?)?.toDouble() ?? 80.27;
    final steps = 8;
    var step = 0;
    _gpsTimer = Timer.periodic(const Duration(seconds: 5), (t) async {
      step++;
      final tFrac = step / steps;
      final lat = hubLat + (d.destinationLatitude - hubLat) * tFrac;
      final lon = hubLon + (d.destinationLongitude - hubLon) * tFrac;
      try {
        await widget.auth.api.post('/deliveries/${d.id}/locations', body: {
          'latitude': lat,
          'longitude': lon,
          'accuracy_m': 15.0,
          'is_simulated': true,
        });
      } catch (_) {}
      if (step >= steps) {
        t.cancel();
        if (mounted) {
          setState(() {
            _trackingDeliveryId = null;
            _simulating = false;
          });
        }
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('SIMULATED tracking started (demo only)'),
        backgroundColor: ResqTheme.orange,
      ),
    );
  }

  Future<void> _sendCurrentPosition(int deliveryId, {required bool simulated}) async {
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      await widget.auth.api.post('/deliveries/$deliveryId/locations', body: {
        'latitude': pos.latitude,
        'longitude': pos.longitude,
        'accuracy_m': pos.accuracy,
        'is_simulated': simulated,
      });
    } catch (_) {}
  }

  void _stopTracking() {
    _gpsTimer?.cancel();
    _gpsTimer = null;
    setState(() {
      _trackingDeliveryId = null;
      _simulating = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = widget.auth.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: const Text('RESQ Transporter'),
        actions: [
          if (_trackingDeliveryId != null)
            TextButton(
              onPressed: _stopTracking,
              child: Text(_simulating ? 'Stop sim' : 'Stop GPS', style: const TextStyle(color: Colors.white)),
            ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              _stopTracking();
              await widget.auth.logout();
              if (context.mounted) Navigator.pushReplacementNamed(context, '/role');
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    'Hello, ${user?.fullName ?? 'Agent'}',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: ResqTheme.navy),
                  ),
                  if (_trackingDeliveryId != null)
                    Container(
                      margin: const EdgeInsets.only(top: 12),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: (_simulating ? ResqTheme.orange : ResqTheme.teal).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _simulating
                            ? 'SIMULATED tracking active for delivery #$_trackingDeliveryId'
                            : 'Live GPS tracking active for delivery #$_trackingDeliveryId',
                        style: TextStyle(
                          color: _simulating ? ResqTheme.orange : ResqTheme.teal,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  const SizedBox(height: 16),
                  if (_items.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(child: Text('No assigned deliveries')),
                    )
                  else
                    ..._items.map((d) => Card(
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(d.destinationName,
                                          style: const TextStyle(fontWeight: FontWeight.bold)),
                                    ),
                                    StatusBadge(status: d.status),
                                  ],
                                ),
                                Text('From ${d.hubName}'),
                                const SizedBox(height: 10),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: [
                                    if (d.status == 'ASSIGNED' || d.status == 'PLANNED')
                                      ElevatedButton(
                                        onPressed: () => _dispatch(d),
                                        child: const Text('Start / Dispatch'),
                                      ),
                                    if (d.status == 'IN_TRANSIT' || d.status == 'ASSIGNED') ...[
                                      OutlinedButton(
                                        onPressed: () => _startLiveTracking(d),
                                        child: const Text('Share live GPS'),
                                      ),
                                      if (AppConfig.enableSimulatedTracking)
                                        OutlinedButton(
                                          onPressed: () => _startSimulatedTracking(d),
                                          child: const Text('Simulate track'),
                                        ),
                                    ],
                                    if (d.status == 'IN_TRANSIT' || d.status == 'ARRIVED')
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(backgroundColor: ResqTheme.green),
                                        onPressed: () => _complete(d),
                                        child: const Text('Complete delivery'),
                                      ),
                                    TextButton(
                                      onPressed: () => Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) =>
                                              DeliveryMapScreen(auth: widget.auth, delivery: d),
                                        ),
                                      ),
                                      child: const Text('Map'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        )),
                ],
              ),
            ),
    );
  }
}
