class Hub {
  final int id;
  final String name;
  final String? description;
  final String address;
  final String city;
  final String state;
  final double latitude;
  final double longitude;
  final double totalStorageCapacity;
  final double reservedCapacity;
  final double currentOccupiedCapacity;
  final double availableCapacity;
  final List<String> acceptedResourceCategories;
  final String operatingStatus;
  final double? distanceKm;
  final bool? acceptsResource;
  final bool? canAcceptDonation;
  final List<String>? recommendationReasons;
  final double? score;
  final String? contactPhone;

  Hub({
    required this.id,
    required this.name,
    this.description,
    required this.address,
    required this.city,
    required this.state,
    required this.latitude,
    required this.longitude,
    required this.totalStorageCapacity,
    required this.reservedCapacity,
    required this.currentOccupiedCapacity,
    required this.availableCapacity,
    required this.acceptedResourceCategories,
    required this.operatingStatus,
    this.distanceKm,
    this.acceptsResource,
    this.canAcceptDonation,
    this.recommendationReasons,
    this.score,
    this.contactPhone,
  });

  /// Supports both list-hubs (`id`) and nearby-recommendation (`hub_id`) payloads.
  factory Hub.fromJson(Map<String, dynamic> j) {
    final rawId = j['id'] ?? j['hub_id'];
    final id = rawId is int
        ? rawId
        : (rawId is num ? rawId.toInt() : int.tryParse('$rawId') ?? 0);

    double asDouble(dynamic v, [double fallback = 0]) {
      if (v == null) return fallback;
      if (v is num) return v.toDouble();
      return double.tryParse('$v') ?? fallback;
    }

    return Hub(
      id: id,
      name: j['name'] as String? ?? '',
      description: j['description'] as String?,
      address: j['address'] as String? ?? '',
      city: j['city'] as String? ?? '',
      state: j['state'] as String? ?? '',
      latitude: asDouble(j['latitude']),
      longitude: asDouble(j['longitude']),
      totalStorageCapacity: asDouble(j['total_storage_capacity']),
      reservedCapacity: asDouble(j['reserved_capacity']),
      currentOccupiedCapacity: asDouble(j['current_occupied_capacity']),
      availableCapacity: asDouble(j['available_capacity']),
      acceptedResourceCategories: (j['accepted_resource_categories'] as List?)
              ?.map((e) => e.toString())
              .toList() ??
          [],
      operatingStatus: j['operating_status'] as String? ?? 'ACTIVE',
      distanceKm: j['distance_km'] != null ? asDouble(j['distance_km']) : null,
      acceptsResource: j['accepts_resource'] as bool?,
      canAcceptDonation: j['can_accept_donation'] as bool?,
      recommendationReasons: (j['recommendation_reasons'] as List?)
          ?.map((e) => e.toString())
          .toList(),
      score: j['score'] != null ? asDouble(j['score']) : null,
      contactPhone: j['contact_phone'] as String?,
    );
  }

  bool get isAcceptable => canAcceptDonation ?? true;
}
