class Delivery {
  final int id;
  final int sourceHubId;
  final int? disasterId;
  final String destinationName;
  final String? destinationAddress;
  final double destinationLatitude;
  final double destinationLongitude;
  final int? assignedAgentId;
  final String status;
  final String? notes;
  final String? dispatchedAt;
  final String? arrivedAt;
  final String? completedAt;
  final double? lastLatitude;
  final double? lastLongitude;
  final String? lastLocationAt;
  final double? lastAccuracyM;
  final Map<String, dynamic>? sourceHub;
  final Map<String, dynamic>? disaster;
  final Map<String, dynamic>? assignedAgent;
  final List<DeliveryItem> items;

  Delivery({
    required this.id,
    required this.sourceHubId,
    this.disasterId,
    required this.destinationName,
    this.destinationAddress,
    required this.destinationLatitude,
    required this.destinationLongitude,
    this.assignedAgentId,
    required this.status,
    this.notes,
    this.dispatchedAt,
    this.arrivedAt,
    this.completedAt,
    this.lastLatitude,
    this.lastLongitude,
    this.lastLocationAt,
    this.lastAccuracyM,
    this.sourceHub,
    this.disaster,
    this.assignedAgent,
    this.items = const [],
  });

  factory Delivery.fromJson(Map<String, dynamic> j) => Delivery(
        id: j['id'] as int,
        sourceHubId: j['source_hub_id'] as int? ?? 0,
        disasterId: j['disaster_id'] as int?,
        destinationName: j['destination_name'] as String? ?? '',
        destinationAddress: j['destination_address'] as String?,
        destinationLatitude: (j['destination_latitude'] as num?)?.toDouble() ?? 0,
        destinationLongitude: (j['destination_longitude'] as num?)?.toDouble() ?? 0,
        assignedAgentId: j['assigned_agent_id'] as int?,
        status: j['status'] as String? ?? 'PLANNED',
        notes: j['notes'] as String?,
        dispatchedAt: j['dispatched_at'] as String?,
        arrivedAt: j['arrived_at'] as String?,
        completedAt: j['completed_at'] as String?,
        lastLatitude: (j['last_latitude'] as num?)?.toDouble(),
        lastLongitude: (j['last_longitude'] as num?)?.toDouble(),
        lastLocationAt: j['last_location_at'] as String?,
        lastAccuracyM: (j['last_accuracy_m'] as num?)?.toDouble(),
        sourceHub: j['source_hub'] as Map<String, dynamic>?,
        disaster: j['disaster'] as Map<String, dynamic>?,
        assignedAgent: j['assigned_agent'] as Map<String, dynamic>?,
        items: (j['items'] as List?)
                ?.map((e) => DeliveryItem.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
      );

  String get hubName => sourceHub?['name']?.toString() ?? 'Hub #$sourceHubId';
  String get agentName => assignedAgent?['full_name']?.toString() ?? 'Unassigned';
  bool get hasLiveLocation => lastLatitude != null && lastLongitude != null;
}

class DeliveryItem {
  final int id;
  final int resourceId;
  final double quantity;
  final String unit;
  final Map<String, dynamic>? resource;

  DeliveryItem({
    required this.id,
    required this.resourceId,
    required this.quantity,
    required this.unit,
    this.resource,
  });

  factory DeliveryItem.fromJson(Map<String, dynamic> j) => DeliveryItem(
        id: j['id'] as int? ?? 0,
        resourceId: j['resource_id'] as int? ?? 0,
        quantity: (j['quantity'] as num?)?.toDouble() ?? 0,
        unit: j['unit'] as String? ?? '',
        resource: j['resource'] as Map<String, dynamic>?,
      );

  String get resourceName => resource?['name']?.toString() ?? 'Resource #$resourceId';
}

class LocationUpdate {
  final double? latitude;
  final double? longitude;
  final double? accuracyM;
  final String? recordedAt;
  final String freshness;
  final int? ageSeconds;
  final String status;

  LocationUpdate({
    this.latitude,
    this.longitude,
    this.accuracyM,
    this.recordedAt,
    required this.freshness,
    this.ageSeconds,
    required this.status,
  });

  factory LocationUpdate.fromJson(Map<String, dynamic> j) => LocationUpdate(
        latitude: (j['latitude'] as num?)?.toDouble(),
        longitude: (j['longitude'] as num?)?.toDouble(),
        accuracyM: (j['accuracy_m'] as num?)?.toDouble(),
        recordedAt: j['recorded_at'] as String?,
        freshness: j['freshness'] as String? ?? 'LOCATION_UNAVAILABLE',
        ageSeconds: j['age_seconds'] as int?,
        status: j['status'] as String? ?? '',
      );

  bool get isLive => freshness == 'LIVE';
  bool get isStale => freshness == 'STALE';
}
