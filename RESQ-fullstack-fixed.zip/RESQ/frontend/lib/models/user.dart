class User {
  final int id;
  final String fullName;
  final String email;
  final String? phoneNumber;
  final String role;
  final bool isActive;

  User({
    required this.id,
    required this.fullName,
    required this.email,
    this.phoneNumber,
    required this.role,
    this.isActive = true,
  });

  factory User.fromJson(Map<String, dynamic> j) => User(
        id: j['id'] as int,
        fullName: j['full_name'] as String? ?? '',
        email: j['email'] as String? ?? '',
        phoneNumber: j['phone_number'] as String?,
        role: j['role'] as String? ?? 'DONOR',
        isActive: j['is_active'] as bool? ?? true,
      );

  bool get isDonor => role == 'DONOR';
  bool get isHubAdmin => role == 'HUB_ADMIN' || role == 'SUPER_ADMIN';
  bool get isAgent => role == 'DELIVERY_AGENT';
  bool get isSuperAdmin => role == 'SUPER_ADMIN';
}
