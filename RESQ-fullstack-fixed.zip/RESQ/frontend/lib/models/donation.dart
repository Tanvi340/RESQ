class Donation {
  final int id;
  final int donorId;
  final int hubId;
  final int resourceId;
  final double quantity;
  final String unit;
  final String? condition;
  final String? description;
  final String status;
  final double? estimatedVolume;
  final String? rejectionReason;
  final String? createdAt;
  final String? approvedAt;
  final String? receivedAt;
  final Map<String, dynamic>? resource;
  final Map<String, dynamic>? hub;

  Donation({
    required this.id,
    required this.donorId,
    required this.hubId,
    required this.resourceId,
    required this.quantity,
    required this.unit,
    this.condition,
    this.description,
    required this.status,
    this.estimatedVolume,
    this.rejectionReason,
    this.createdAt,
    this.approvedAt,
    this.receivedAt,
    this.resource,
    this.hub,
  });

  factory Donation.fromJson(Map<String, dynamic> j) => Donation(
        id: j['id'] as int,
        donorId: j['donor_id'] as int? ?? 0,
        hubId: j['hub_id'] as int? ?? 0,
        resourceId: j['resource_id'] as int? ?? 0,
        quantity: (j['quantity'] as num?)?.toDouble() ?? 0,
        unit: j['unit'] as String? ?? '',
        condition: j['condition'] as String?,
        description: j['description'] as String?,
        status: j['status'] as String? ?? 'PENDING_APPROVAL',
        estimatedVolume: (j['estimated_volume'] as num?)?.toDouble(),
        rejectionReason: j['rejection_reason'] as String?,
        createdAt: j['created_at'] as String?,
        approvedAt: j['approved_at'] as String?,
        receivedAt: j['received_at'] as String?,
        resource: j['resource'] as Map<String, dynamic>?,
        hub: j['hub'] as Map<String, dynamic>?,
      );

  String get resourceName => resource?['name']?.toString() ?? 'Resource #$resourceId';
  String get hubName => hub?['name']?.toString() ?? 'Hub #$hubId';
}
