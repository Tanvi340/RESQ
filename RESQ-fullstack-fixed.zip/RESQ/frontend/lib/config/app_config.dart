class AppConfig {
  static const String appName = 'RESQ';
  static const String appTagline = 'Disaster Relief Resource Coordination';
  static const bool enableSimulatedTracking = true; // demo only
}
