/// API base URL configuration.
///
/// - Android emulator: http://10.0.2.2:5000/api/v1
/// - iOS simulator / Windows desktop: http://127.0.0.1:5000/api/v1
/// - Physical device: http://<your-LAN-IP>:5000/api/v1
class ApiConfig {
  // Change this for your environment
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://127.0.0.1:5000/api/v1',
  );

  static const Duration timeout = Duration(seconds: 20);
  static const int locationPollSeconds = 10;
  static const int staleThresholdSeconds = 60;
}
