# RESQ Flutter Frontend

## Setup

```bash
flutter pub get
flutter run
```

### API base URL

Edit `lib/config/api_config.dart` or pass:

```bash
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:5000/api/v1
```

### Android location

Ensure `android/app/src/main/AndroidManifest.xml` includes:

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
```

## Screens

- Role selection → Donor / Admin / Delivery Agent login  
- Donor: dashboard, create donation, nearby hubs, history, track deliveries  
- Admin: dashboard, pending approvals, inventory, create/manage deliveries  
- Transporter: assigned deliveries, dispatch, live GPS / simulate, complete  
- Map: OpenStreetMap, hub + destination + agent markers, freshness badge  

## Demo flow

1. Start backend + seed  
2. Login as `donor1@resq.local` → create donation → select hub  
3. Login as `admin1@resq.local` → approve → confirm receipt  
4. Admin → Create delivery → assign inventory  
5. Login as `agent1@resq.local` → dispatch → Share live GPS or Simulate  
6. Open map as admin/donor to see updates  
