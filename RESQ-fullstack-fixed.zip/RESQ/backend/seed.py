"""
Seed development data for RESQ.
Run: python seed.py
Idempotent – skips existing records by email / name.
"""
import os
import sys
from datetime import datetime, timezone, timedelta

# Ensure backend root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv
load_dotenv()

from app import create_app
from app.extensions import db
from app.models.user import User, UserRole
from app.models.hub import Hub, HubStatus
from app.models.resource import Resource
from app.models.donation import Donation, DonationStatus
from app.models.inventory import Inventory
from app.models.disaster import Disaster, DisasterType, DisasterStatus
from app.models.transport import Transport, TransportStatus, TransportResponsibleParty

# Sample city: Chennai, India
CHENNAI_LAT, CHENNAI_LON = 13.0827, 80.2707

RESOURCES = [
    {"name": "Adult Clothing Pack", "category": "Clothing", "default_unit": "packs", "volume_per_unit": 5.0},
    {"name": "Children Clothing Pack", "category": "Clothing", "default_unit": "packs", "volume_per_unit": 3.0},
    {"name": "Wool Blanket", "category": "Blankets", "default_unit": "pieces", "volume_per_unit": 8.0},
    {"name": "Ready-to-Eat Meal Packet", "category": "Food", "default_unit": "packets", "volume_per_unit": 1.5, "is_perishable": True},
    {"name": "Bottled Water 1L", "category": "Drinking Water", "default_unit": "bottles", "volume_per_unit": 1.0},
    {"name": "Hygiene Kit", "category": "Hygiene Kits", "default_unit": "kits", "volume_per_unit": 3.0},
    {"name": "First Aid Kit", "category": "Medical Supplies", "default_unit": "kits", "volume_per_unit": 2.0, "requires_special_handling": True},
    {"name": "Tarpaulin Sheet", "category": "Shelter Materials", "default_unit": "sheets", "volume_per_unit": 15.0},
    {"name": "Baby Care Pack", "category": "Baby Supplies", "default_unit": "packs", "volume_per_unit": 2.5},
    {"name": "Sanitary Napkins Pack", "category": "Other Essentials", "default_unit": "packs", "volume_per_unit": 1.0},
]

HUBS = [
    {
        "name": "Central Chennai Relief Hub",
        "description": "Primary collection centre near Egmore",
        "address": "15 Pantheon Road, Egmore",
        "city": "Chennai",
        "state": "Tamil Nadu",
        "pincode": "600008",
        "latitude": 13.0732,
        "longitude": 80.2609,
        "total_storage_capacity": 5000.0,
        "accepted_resource_categories": [
            "Clothing", "Blankets", "Food", "Drinking Water",
            "Hygiene Kits", "Medical Supplies", "Shelter Materials",
            "Baby Supplies", "Other Essentials",
        ],
        "contact_phone": "+919876543210",
        "contact_email": "central@resq-hub.example",
    },
    {
        "name": "North Chennai Relief Hub",
        "description": "Serving Tondiarpet and surrounding areas",
        "address": "42 Thiruvottiyur High Road",
        "city": "Chennai",
        "state": "Tamil Nadu",
        "pincode": "600019",
        "latitude": 13.1265,
        "longitude": 80.2950,
        "total_storage_capacity": 3000.0,
        "accepted_resource_categories": [
            "Clothing", "Blankets", "Food", "Drinking Water", "Hygiene Kits",
        ],
        "contact_phone": "+919876543211",
        "contact_email": "north@resq-hub.example",
    },
    {
        "name": "South Chennai Relief Hub",
        "description": "Adyar and Besant Nagar coverage",
        "address": "8 Lattice Bridge Road, Adyar",
        "city": "Chennai",
        "state": "Tamil Nadu",
        "pincode": "600020",
        "latitude": 13.0067,
        "longitude": 80.2570,
        "total_storage_capacity": 4000.0,
        "accepted_resource_categories": [
            "Clothing", "Blankets", "Food", "Drinking Water",
            "Hygiene Kits", "Baby Supplies", "Shelter Materials",
        ],
        "contact_phone": "+919876543212",
        "contact_email": "south@resq-hub.example",
    },
    {
        "name": "West Chennai Medical Hub",
        "description": "Specialised for medical and hygiene supplies",
        "address": "25 Anna Nagar West",
        "city": "Chennai",
        "state": "Tamil Nadu",
        "pincode": "600040",
        "latitude": 13.0878,
        "longitude": 80.2089,
        "total_storage_capacity": 2000.0,
        "accepted_resource_categories": [
            "Medical Supplies", "Hygiene Kits", "Drinking Water", "Other Essentials",
        ],
        "contact_phone": "+919876543213",
        "contact_email": "medical@resq-hub.example",
    },
    {
        "name": "East Coast Emergency Hub",
        "description": "Near Marina Beach – cyclone response ready",
        "address": "3 Kamarajar Salai, Marina",
        "city": "Chennai",
        "state": "Tamil Nadu",
        "pincode": "600005",
        "latitude": 13.0499,
        "longitude": 80.2824,
        "total_storage_capacity": 6000.0,
        "accepted_resource_categories": [
            "Clothing", "Blankets", "Food", "Drinking Water",
            "Hygiene Kits", "Shelter Materials", "Other Essentials",
        ],
        "contact_phone": "+919876543214",
        "contact_email": "east@resq-hub.example",
    },
]


def get_or_create_user(email, full_name, password, role, phone=None):
    user = User.query.filter_by(email=email).first()
    if user:
        return user, False
    user = User(
        full_name=full_name,
        email=email,
        phone_number=phone,
        role=role,
        is_active=True,
    )
    user.set_password(password)
    db.session.add(user)
    db.session.flush()
    return user, True


def seed():
    app = create_app()
    with app.app_context():
        db.create_all()
        print("Seeding RESQ development data...")

        # Super admin
        super_admin, created = get_or_create_user(
            "superadmin@resq.local",
            "RESQ Super Admin",
            "SuperAdmin@123",
            UserRole.SUPER_ADMIN,
            "+919999999999",
        )
        print(f"  Super admin: {'created' if created else 'exists'} ({super_admin.email})")

        # Hub admins
        hub_admins = []
        for i, email in enumerate(
            [
                "admin1@resq.local",
                "admin2@resq.local",
                "admin3@resq.local",
            ]
        ):
            u, c = get_or_create_user(
                email,
                f"Hub Admin {i + 1}",
                "HubAdmin@123",
                UserRole.HUB_ADMIN,
                f"+9198765432{i:02d}",
            )
            hub_admins.append(u)
            print(f"  Hub admin: {'created' if c else 'exists'} ({u.email})")

        # Donors
        donors = []
        for i in range(1, 11):
            u, c = get_or_create_user(
                f"donor{i}@resq.local",
                f"Donor User {i}",
                "Donor@12345",
                UserRole.DONOR,
                f"+9198000000{i:02d}",
            )
            donors.append(u)
            if c:
                print(f"  Donor created: {u.email}")


        # Delivery agents
        agents = []
        for i, email in enumerate(["agent1@resq.local", "agent2@resq.local"]):
            u, c = get_or_create_user(
                email,
                f"Delivery Agent {i + 1}",
                "Agent@12345",
                UserRole.DELIVERY_AGENT,
                f"+9197000000{i:02d}",
            )
            agents.append(u)
            print(f"  Delivery agent: {'created' if c else 'exists'} ({u.email})")

        # Resources
        resource_map = {}
        for rdata in RESOURCES:
            r = Resource.query.filter_by(name=rdata["name"]).first()
            if not r:
                r = Resource(
                    name=rdata["name"],
                    category=rdata["category"],
                    default_unit=rdata["default_unit"],
                    volume_per_unit=rdata["volume_per_unit"],
                    is_perishable=rdata.get("is_perishable", False),
                    requires_special_handling=rdata.get("requires_special_handling", False),
                    is_active=True,
                    description=f"Standard {rdata['name']} for disaster relief",
                )
                db.session.add(r)
                db.session.flush()
                print(f"  Resource created: {r.name}")
            resource_map[rdata["name"]] = r

        # Hubs
        hubs = []
        for idx, hdata in enumerate(HUBS):
            h = Hub.query.filter_by(name=hdata["name"]).first()
            if not h:
                admin = hub_admins[idx % len(hub_admins)]
                h = Hub(
                    name=hdata["name"],
                    description=hdata["description"],
                    address=hdata["address"],
                    city=hdata["city"],
                    state=hdata["state"],
                    pincode=hdata["pincode"],
                    latitude=hdata["latitude"],
                    longitude=hdata["longitude"],
                    admin_id=admin.id,
                    total_storage_capacity=hdata["total_storage_capacity"],
                    reserved_capacity=0.0,
                    current_occupied_capacity=0.0,
                    contact_phone=hdata["contact_phone"],
                    contact_email=hdata["contact_email"],
                    operating_status=HubStatus.ACTIVE,
                )
                h.set_accepted_categories(hdata["accepted_resource_categories"])
                db.session.add(h)
                db.session.flush()
                print(f"  Hub created: {h.name} (admin: {admin.email})")
            hubs.append(h)

        # Sample inventory
        for hub in hubs:
            for rname, res in list(resource_map.items())[:5]:
                inv = Inventory.query.filter_by(hub_id=hub.id, resource_id=res.id).first()
                if not inv:
                    inv = Inventory(
                        hub_id=hub.id,
                        resource_id=res.id,
                        available_quantity=50.0 + (hub.id * 10),
                        reserved_quantity=0.0,
                        unit=res.default_unit,
                    )
                    db.session.add(inv)

        # Disaster
        disaster = Disaster.query.filter_by(title="Chennai Flood Response 2024").first()
        if not disaster:
            disaster = Disaster(
                title="Chennai Flood Response 2024",
                disaster_type=DisasterType.FLOOD,
                description="Heavy monsoon flooding affecting low-lying areas of Chennai.",
                affected_region="Chennai, Tamil Nadu",
                latitude=CHENNAI_LAT,
                longitude=CHENNAI_LON,
                severity="HIGH",
                status=DisasterStatus.ACTIVE,
                start_date=datetime.now(timezone.utc) - timedelta(days=5),
                created_by=super_admin.id,
            )
            db.session.add(disaster)
            db.session.flush()
            print(f"  Disaster created: {disaster.title}")

        # Sample donations in various states
        if Donation.query.count() == 0:
            # Pending
            d1 = Donation(
                donor_id=donors[0].id,
                hub_id=hubs[0].id,
                resource_id=resource_map["Adult Clothing Pack"].id,
                quantity=20,
                unit="packs",
                condition="Good",
                estimated_volume=100.0,
                status=DonationStatus.PENDING_APPROVAL,
                donor_latitude=13.08,
                donor_longitude=80.27,
                donor_address="T Nagar, Chennai",
                pickup_required=False,
                disaster_id=disaster.id,
            )
            db.session.add(d1)

            # Approved / transport pending
            d2 = Donation(
                donor_id=donors[1].id,
                hub_id=hubs[0].id,
                resource_id=resource_map["Bottled Water 1L"].id,
                quantity=100,
                unit="bottles",
                condition="Good",
                estimated_volume=100.0,
                status=DonationStatus.TRANSPORT_PENDING,
                donor_latitude=13.05,
                donor_longitude=80.25,
                approved_at=datetime.now(timezone.utc) - timedelta(hours=2),
                disaster_id=disaster.id,
            )
            db.session.add(d2)
            hubs[0].reserved_capacity += 100.0

            # Received
            d3 = Donation(
                donor_id=donors[2].id,
                hub_id=hubs[1].id,
                resource_id=resource_map["Hygiene Kit"].id,
                quantity=30,
                unit="kits",
                condition="Good",
                estimated_volume=90.0,
                status=DonationStatus.RECEIVED,
                approved_at=datetime.now(timezone.utc) - timedelta(days=2),
                received_at=datetime.now(timezone.utc) - timedelta(days=1),
                disaster_id=disaster.id,
            )
            db.session.add(d3)
            hubs[1].current_occupied_capacity += 90.0

            # Rejected
            d4 = Donation(
                donor_id=donors[3].id,
                hub_id=hubs[2].id,
                resource_id=resource_map["First Aid Kit"].id,
                quantity=5,
                unit="kits",
                condition="Damaged",
                estimated_volume=10.0,
                status=DonationStatus.REJECTED,
                rejection_reason="Items arrived damaged / expired",
            )
            db.session.add(d4)

            db.session.flush()
            print("  Sample donations created")

        db.session.commit()
        print("\nSeed completed successfully.")
        print("\n--- Development Credentials (DO NOT USE IN PRODUCTION) ---")
        print("Super Admin : superadmin@resq.local / SuperAdmin@123")
        print("Hub Admin   : admin1@resq.local / HubAdmin@123")
        print("Donor       : donor1@resq.local / Donor@12345")
        print("Agent       : agent1@resq.local / Agent@12345")
        print("---------------------------------------------------------")


if __name__ == "__main__":
    seed()
