"""Hub and recommendation tests."""
import pytest
from app.utils.distance import haversine_distance


def test_haversine_distance():
    # Chennai to a nearby point (~3-4 km)
    d = haversine_distance(13.0827, 80.2707, 13.0732, 80.2609)
    assert 0 < d < 10


def test_list_hubs(client, hub):
    resp = client.get("/api/v1/hubs")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["success"] is True
    assert len(data["data"]) >= 1


def test_get_hub(client, hub):
    resp = client.get(f"/api/v1/hubs/{hub.id}")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["data"]["name"] == "Test Relief Hub"


def test_nearby_hubs_within_radius(client, hub, resource):
    resp = client.get(
        "/api/v1/hubs/nearby",
        query_string={
            "latitude": 13.0827,
            "longitude": 80.2707,
            "radius_km": 50,
            "resource_id": resource.id,
            "quantity": 10,
        },
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["success"] is True
    assert len(data["data"]) >= 1
    first = data["data"][0]
    assert "distance_km" in first
    assert "recommendation_reasons" in first
    assert first["can_accept_donation"] is True


def test_nearby_excludes_out_of_radius(client, hub, resource):
    # Point far away (Delhi coords)
    resp = client.get(
        "/api/v1/hubs/nearby",
        query_string={
            "latitude": 28.6139,
            "longitude": 77.2090,
            "radius_km": 10,
            "resource_id": resource.id,
        },
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert len(data["data"]) == 0


def test_nearby_excludes_incompatible_resource(client, hub):
    from app.extensions import db
    from app.models.resource import Resource

    medical = Resource(
        name="Medical Item",
        category="Medical Supplies",
        default_unit="kits",
        volume_per_unit=2.0,
        is_active=True,
    )
    db.session.add(medical)
    db.session.commit()

    resp = client.get(
        "/api/v1/hubs/nearby",
        query_string={
            "latitude": 13.0827,
            "longitude": 80.2707,
            "radius_km": 50,
            "resource_id": medical.id,
            "quantity": 1,
        },
    )
    assert resp.status_code == 200
    data = resp.get_json()
    # Hub does not accept Medical Supplies
    for h in data["data"]:
        if h["hub_id"] == hub.id:
            assert h["accepts_resource"] is False
            assert h["can_accept_donation"] is False


def test_nearby_excludes_insufficient_capacity(client, hub, resource):
    from app.extensions import db

    hub.total_storage_capacity = 5.0
    hub.current_occupied_capacity = 4.0
    db.session.commit()

    resp = client.get(
        "/api/v1/hubs/nearby",
        query_string={
            "latitude": 13.0827,
            "longitude": 80.2707,
            "radius_km": 50,
            "resource_id": resource.id,
            "quantity": 10,  # needs 10 liters, only 1 available
        },
    )
    assert resp.status_code == 200
    data = resp.get_json()
    for h in data["data"]:
        if h["hub_id"] == hub.id:
            assert h["can_accept_donation"] is False


def test_create_hub(client, admin_headers):
    resp = client.post(
        "/api/v1/hubs",
        headers=admin_headers,
        json={
            "name": "New Hub",
            "address": "456 New Street",
            "city": "Chennai",
            "state": "Tamil Nadu",
            "latitude": 13.09,
            "longitude": 80.28,
            "total_storage_capacity": 2000,
            "accepted_resource_categories": ["Clothing", "Food"],
        },
    )
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["data"]["name"] == "New Hub"


def test_capacity_endpoint(client, hub):
    resp = client.get(f"/api/v1/hubs/{hub.id}/capacity")
    assert resp.status_code == 200
    data = resp.get_json()
    assert "available_capacity" in data["data"]
    assert data["data"]["total_storage_capacity"] == 1000.0
