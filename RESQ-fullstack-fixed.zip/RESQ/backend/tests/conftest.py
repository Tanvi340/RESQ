"""Pytest fixtures for RESQ backend tests."""
import pytest
from app import create_app
from app.config import TestingConfig
from app.extensions import db
from app.models.user import User, UserRole
from app.models.hub import Hub, HubStatus
from app.models.resource import Resource


@pytest.fixture(scope="function")
def app():
    application = create_app(TestingConfig)
    with application.app_context():
        db.create_all()
        yield application
        db.session.remove()
        db.drop_all()


@pytest.fixture(scope="function")
def client(app):
    return app.test_client()


@pytest.fixture
def donor(app):
    user = User(
        full_name="Test Donor",
        email="donor@test.com",
        role=UserRole.DONOR,
        is_active=True,
    )
    user.set_password("Donor@12345")
    db.session.add(user)
    db.session.commit()
    return user


@pytest.fixture
def hub_admin(app):
    user = User(
        full_name="Test Hub Admin",
        email="admin@test.com",
        role=UserRole.HUB_ADMIN,
        is_active=True,
    )
    user.set_password("Admin@12345")
    db.session.add(user)
    db.session.commit()
    return user


@pytest.fixture
def super_admin(app):
    user = User(
        full_name="Test Super Admin",
        email="super@test.com",
        role=UserRole.SUPER_ADMIN,
        is_active=True,
    )
    user.set_password("Super@12345")
    db.session.add(user)
    db.session.commit()
    return user


@pytest.fixture
def resource(app):
    r = Resource(
        name="Test Water Bottles",
        category="Drinking Water",
        default_unit="bottles",
        volume_per_unit=1.0,
        is_active=True,
    )
    db.session.add(r)
    db.session.commit()
    return r


@pytest.fixture
def hub(app, hub_admin):
    h = Hub(
        name="Test Relief Hub",
        description="Test hub",
        address="123 Test Street",
        city="Chennai",
        state="Tamil Nadu",
        pincode="600001",
        latitude=13.0827,
        longitude=80.2707,
        admin_id=hub_admin.id,
        total_storage_capacity=1000.0,
        reserved_capacity=0.0,
        current_occupied_capacity=0.0,
        contact_phone="+919999999999",
        operating_status=HubStatus.ACTIVE,
    )
    h.set_accepted_categories(
        ["Clothing", "Blankets", "Food", "Drinking Water", "Hygiene Kits"]
    )
    db.session.add(h)
    db.session.commit()
    return h


@pytest.fixture
def auth_headers(client, donor):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "donor@test.com", "password": "Donor@12345"},
    )
    data = resp.get_json()
    token = data["data"]["access_token"]
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def admin_headers(client, hub_admin):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "admin@test.com", "password": "Admin@12345"},
    )
    data = resp.get_json()
    token = data["data"]["access_token"]
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def super_headers(client, super_admin):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "super@test.com", "password": "Super@12345"},
    )
    data = resp.get_json()
    token = data["data"]["access_token"]
    return {"Authorization": f"Bearer {token}"}
