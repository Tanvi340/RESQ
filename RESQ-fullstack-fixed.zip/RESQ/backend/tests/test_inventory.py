"""Inventory tests."""
import pytest


def test_inventory_on_receipt(
    client, auth_headers, admin_headers, hub, resource
):
    # Create + approve + confirm
    resp = client.post(
        "/api/v1/donations",
        headers=auth_headers,
        json={
            "hub_id": hub.id,
            "resource_id": resource.id,
            "quantity": 25,
            "unit": "bottles",
        },
    )
    did = resp.get_json()["data"]["id"]
    client.post(f"/api/v1/donations/{did}/approve", headers=admin_headers, json={})
    client.post(f"/api/v1/donations/{did}/confirm-receipt", headers=admin_headers)

    inv = client.get(f"/api/v1/inventory/{hub.id}/{resource.id}", headers=admin_headers)
    assert inv.status_code == 200
    data = inv.get_json()["data"]
    assert data["available_quantity"] == 25


def test_inventory_adjustment(client, admin_headers, hub, resource):
    resp = client.post(
        "/api/v1/inventory/adjustments",
        headers=admin_headers,
        json={
            "hub_id": hub.id,
            "resource_id": resource.id,
            "quantity_change": 10,
            "reason": "Initial stock count verification",
        },
    )
    assert resp.status_code == 200
    assert resp.get_json()["data"]["available_quantity"] == 10

    # Negative adjustment
    resp2 = client.post(
        "/api/v1/inventory/adjustments",
        headers=admin_headers,
        json={
            "hub_id": hub.id,
            "resource_id": resource.id,
            "quantity_change": -3,
            "reason": "Damaged items removed",
        },
    )
    assert resp2.status_code == 200
    assert resp2.get_json()["data"]["available_quantity"] == 7


def test_negative_inventory_rejected(client, admin_headers, hub, resource):
    resp = client.post(
        "/api/v1/inventory/adjustments",
        headers=admin_headers,
        json={
            "hub_id": hub.id,
            "resource_id": resource.id,
            "quantity_change": -100,
            "reason": "Would go negative",
        },
    )
    assert resp.status_code == 409
