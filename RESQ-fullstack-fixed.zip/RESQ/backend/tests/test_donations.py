"""Donation lifecycle tests."""
import pytest


def _create_donation(client, headers, hub, resource, quantity=10):
    return client.post(
        "/api/v1/donations",
        headers=headers,
        json={
            "hub_id": hub.id,
            "resource_id": resource.id,
            "quantity": quantity,
            "unit": "bottles",
            "condition": "Good",
            "donor_latitude": 13.08,
            "donor_longitude": 80.27,
        },
    )


def test_create_donation(client, auth_headers, hub, resource):
    resp = _create_donation(client, auth_headers, hub, resource)
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["success"] is True
    assert data["data"]["status"] == "PENDING_APPROVAL"
    assert data["data"]["quantity"] == 10


def test_approve_donation(client, auth_headers, admin_headers, hub, resource):
    create_resp = _create_donation(client, auth_headers, hub, resource)
    donation_id = create_resp.get_json()["data"]["id"]

    resp = client.post(
        f"/api/v1/donations/{donation_id}/approve",
        headers=admin_headers,
        json={"admin_notes": "Looks good"},
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["data"]["status"] in ("APPROVED", "TRANSPORT_PENDING")

    # Capacity should be reserved
    cap = client.get(f"/api/v1/hubs/{hub.id}/capacity").get_json()["data"]
    assert cap["reserved_capacity"] > 0


def test_reject_donation(client, auth_headers, admin_headers, hub, resource):
    create_resp = _create_donation(client, auth_headers, hub, resource)
    donation_id = create_resp.get_json()["data"]["id"]

    resp = client.post(
        f"/api/v1/donations/{donation_id}/reject",
        headers=admin_headers,
        json={"rejection_reason": "Hub temporarily closed for maintenance"},
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["data"]["status"] == "REJECTED"


def test_donor_cannot_approve_own(client, auth_headers, hub, resource, donor):
    # Make donor also a hub admin of this hub? Better: try approve with donor token
    create_resp = _create_donation(client, auth_headers, hub, resource)
    donation_id = create_resp.get_json()["data"]["id"]

    resp = client.post(
        f"/api/v1/donations/{donation_id}/approve",
        headers=auth_headers,
        json={},
    )
    # Donor is not hub admin → 403
    assert resp.status_code == 403


def test_invalid_transition_approve_twice(
    client, auth_headers, admin_headers, hub, resource
):
    create_resp = _create_donation(client, auth_headers, hub, resource)
    donation_id = create_resp.get_json()["data"]["id"]

    client.post(
        f"/api/v1/donations/{donation_id}/approve",
        headers=admin_headers,
        json={},
    )
    resp = client.post(
        f"/api/v1/donations/{donation_id}/approve",
        headers=admin_headers,
        json={},
    )
    assert resp.status_code == 409


def test_cancel_pending(client, auth_headers, hub, resource):
    create_resp = _create_donation(client, auth_headers, hub, resource)
    donation_id = create_resp.get_json()["data"]["id"]

    resp = client.patch(
        f"/api/v1/donations/{donation_id}/cancel",
        headers=auth_headers,
    )
    assert resp.status_code == 200
    assert resp.get_json()["data"]["status"] == "CANCELLED"


def test_confirm_receipt(
    client, auth_headers, admin_headers, hub, resource
):
    create_resp = _create_donation(client, auth_headers, hub, resource, quantity=5)
    donation_id = create_resp.get_json()["data"]["id"]

    client.post(
        f"/api/v1/donations/{donation_id}/approve",
        headers=admin_headers,
        json={},
    )

    resp = client.post(
        f"/api/v1/donations/{donation_id}/confirm-receipt",
        headers=admin_headers,
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["data"]["status"] == "RECEIVED"

    # Inventory should increase
    inv = client.get(f"/api/v1/hubs/{hub.id}/inventory").get_json()["data"]
    found = [i for i in inv if i["resource_id"] == resource.id]
    assert len(found) >= 1
    assert found[0]["available_quantity"] >= 5


def test_duplicate_receipt_prevented(
    client, auth_headers, admin_headers, hub, resource
):
    create_resp = _create_donation(client, auth_headers, hub, resource)
    donation_id = create_resp.get_json()["data"]["id"]
    client.post(
        f"/api/v1/donations/{donation_id}/approve",
        headers=admin_headers,
        json={},
    )
    client.post(
        f"/api/v1/donations/{donation_id}/confirm-receipt",
        headers=admin_headers,
    )
    resp = client.post(
        f"/api/v1/donations/{donation_id}/confirm-receipt",
        headers=admin_headers,
    )
    assert resp.status_code == 409


def test_my_donations(client, auth_headers, hub, resource):
    _create_donation(client, auth_headers, hub, resource)
    resp = client.get("/api/v1/donations/my", headers=auth_headers)
    assert resp.status_code == 200
    data = resp.get_json()
    assert len(data["data"]) >= 1
