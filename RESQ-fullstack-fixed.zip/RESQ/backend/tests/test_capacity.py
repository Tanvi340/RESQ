"""Capacity and concurrency safety tests."""
import pytest
from app.extensions import db
from app.models.hub import Hub
from app.services.capacity_service import CapacityService
from app.utils.exceptions import InsufficientCapacityError


def test_reserve_capacity(app, hub):
    with app.app_context():
        CapacityService.reserve_capacity(hub, 100.0)
        db.session.commit()
        h = db.session.get(Hub, hub.id)
        assert h.reserved_capacity == 100.0
        assert h.available_capacity == 900.0


def test_insufficient_capacity_rejected(app, hub):
    with app.app_context():
        with pytest.raises(InsufficientCapacityError):
            CapacityService.reserve_capacity(hub, 2000.0)


def test_release_reservation(app, hub):
    with app.app_context():
        CapacityService.reserve_capacity(hub, 200.0)
        db.session.commit()
        CapacityService.release_reservation(hub, 200.0)
        db.session.commit()
        h = db.session.get(Hub, hub.id)
        assert h.reserved_capacity == 0.0


def test_occupy_capacity(app, hub):
    with app.app_context():
        CapacityService.reserve_capacity(hub, 150.0)
        db.session.commit()
        CapacityService.occupy_capacity(hub, 150.0)
        db.session.commit()
        h = db.session.get(Hub, hub.id)
        assert h.reserved_capacity == 0.0
        assert h.current_occupied_capacity == 150.0


def test_no_negative_capacity(app, hub):
    with app.app_context():
        CapacityService.reserve_capacity(hub, 50.0)
        db.session.commit()
        CapacityService.release_reservation(hub, 100.0)  # more than reserved
        db.session.commit()
        h = db.session.get(Hub, hub.id)
        assert h.reserved_capacity == 0.0


def test_approval_reserves_capacity(
    client, auth_headers, admin_headers, hub, resource
):
    resp = client.post(
        "/api/v1/donations",
        headers=auth_headers,
        json={
            "hub_id": hub.id,
            "resource_id": resource.id,
            "quantity": 50,
            "unit": "bottles",
        },
    )
    donation_id = resp.get_json()["data"]["id"]

    client.post(
        f"/api/v1/donations/{donation_id}/approve",
        headers=admin_headers,
        json={},
    )

    cap = client.get(f"/api/v1/hubs/{hub.id}/capacity").get_json()["data"]
    assert cap["reserved_capacity"] == 50.0  # volume_per_unit=1.0 * 50
