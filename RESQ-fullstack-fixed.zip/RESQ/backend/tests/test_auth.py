"""Authentication tests."""


def test_register_success(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={
            "full_name": "New Donor",
            "email": "newdonor@test.com",
            "password": "Password1",
            "role": "DONOR",
        },
    )
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["success"] is True
    assert data["data"]["email"] == "newdonor@test.com"
    assert data["data"]["role"] == "DONOR"


def test_register_duplicate_email(client, donor):
    resp = client.post(
        "/api/v1/auth/register",
        json={
            "full_name": "Duplicate",
            "email": "donor@test.com",
            "password": "Password1",
        },
    )
    assert resp.status_code == 409
    data = resp.get_json()
    assert data["success"] is False
    assert data["error_code"] == "EMAIL_EXISTS"


def test_register_cannot_self_assign_super_admin(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={
            "full_name": "Hacker",
            "email": "hacker@test.com",
            "password": "Password1",
            "role": "SUPER_ADMIN",
        },
    )
    assert resp.status_code == 422


def test_login_success(client, donor):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "donor@test.com", "password": "Donor@12345"},
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["success"] is True
    assert "access_token" in data["data"]
    assert "refresh_token" in data["data"]


def test_login_wrong_password(client, donor):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "donor@test.com", "password": "WrongPass1"},
    )
    assert resp.status_code == 401
    data = resp.get_json()
    assert data["success"] is False


def test_me_endpoint(client, auth_headers):
    resp = client.get("/api/v1/auth/me", headers=auth_headers)
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["data"]["email"] == "donor@test.com"


def test_me_unauthorized(client):
    resp = client.get("/api/v1/auth/me")
    assert resp.status_code == 401


def test_invalid_token(client):
    resp = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": "Bearer invalidtoken"},
    )
    assert resp.status_code == 401


def test_health(client):
    resp = client.get("/api/v1/health")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["success"] is True
    assert "RESQ backend is running" in data["message"]
