"""Transport tests."""
import pytest
from datetime import datetime, timezone, timedelta


def _setup_approved_donation(client, auth_headers, admin_headers, hub, resource):
    resp = client.post(
        "/api/v1/donations",
        headers=auth_headers,
        json={
            "hub_id": hub.id,
            "resource_id": resource.id,
            "quantity": 10,
            "unit": "bottles",
        },
    )
    did = resp.get_json()["data"]["id"]
    client.post(f"/api/v1/donations/{did}/approve", headers=admin_headers, json={})
    return did


def test_donor_managed_transport(
    client, auth_headers, admin_headers, hub, resource
):
    did = _setup_approved_donation(client, auth_headers, admin_headers, hub, resource)

    resp = client.post(
        f"/api/v1/donations/{did}/transport",
        headers=auth_headers,
        json={
            "responsible_party": "DONOR",
            "transport_method": "Personal vehicle",
            "scheduled_at": (datetime.now(timezone.utc) + timedelta(days=1)).isoformat(),
        },
    )
    assert resp.status_code == 201
    data = resp.get_json()["data"]
    assert data["responsible_party"] == "DONOR"
    assert data["status"] == "SCHEDULED"


def test_hub_admin_managed_transport(
    client, auth_headers, admin_headers, hub, resource
):
    did = _setup_approved_donation(client, auth_headers, admin_headers, hub, resource)

    resp = client.post(
        f"/api/v1/donations/{did}/transport",
        headers=admin_headers,
        json={
            "responsible_party": "HUB_ADMIN",
            "transport_method": "Hub van",
            "pickup_address": "Donor address",
            "destination_address": hub.address,
        },
    )
    assert resp.status_code == 201
    assert resp.get_json()["data"]["responsible_party"] == "HUB_ADMIN"


def test_transport_status_flow(
    client, auth_headers, admin_headers, hub, resource
):
    did = _setup_approved_donation(client, auth_headers, admin_headers, hub, resource)
    t_resp = client.post(
        f"/api/v1/donations/{did}/transport",
        headers=auth_headers,
        json={
            "responsible_party": "DONOR",
            "scheduled_at": (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat(),
        },
    )
    tid = t_resp.get_json()["data"]["id"]

    # Picked up
    r1 = client.post(
        f"/api/v1/transport/{tid}/mark-picked-up",
        headers=auth_headers,
    )
    assert r1.status_code == 200
    assert r1.get_json()["data"]["status"] == "PICKED_UP"

    # In transit
    r2 = client.post(
        f"/api/v1/transport/{tid}/mark-in-transit",
        headers=auth_headers,
    )
    assert r2.status_code == 200
    assert r2.get_json()["data"]["status"] == "IN_TRANSIT"

    # Delivered – does NOT mark donation RECEIVED
    r3 = client.post(
        f"/api/v1/transport/{tid}/mark-delivered",
        headers=auth_headers,
    )
    assert r3.status_code == 200
    assert r3.get_json()["data"]["status"] == "DELIVERED"

    # Donation still not RECEIVED
    d = client.get(f"/api/v1/donations/{did}", headers=auth_headers).get_json()["data"]
    assert d["status"] != "RECEIVED"

    # Admin confirms receipt
    conf = client.post(
        f"/api/v1/donations/{did}/confirm-receipt",
        headers=admin_headers,
    )
    assert conf.status_code == 200
    assert conf.get_json()["data"]["status"] == "RECEIVED"


def test_invalid_transport_transition(
    client, auth_headers, admin_headers, hub, resource
):
    did = _setup_approved_donation(client, auth_headers, admin_headers, hub, resource)
    t_resp = client.post(
        f"/api/v1/donations/{did}/transport",
        headers=auth_headers,
        json={"responsible_party": "DONOR"},
    )
    tid = t_resp.get_json()["data"]["id"]

    # Cannot mark delivered from NOT_ARRANGED
    resp = client.post(
        f"/api/v1/transport/{tid}/mark-delivered",
        headers=auth_headers,
    )
    assert resp.status_code == 409
