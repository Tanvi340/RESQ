"""RESQ application factory."""
import logging
import os
from flask import Flask, jsonify

from app.config import get_config
from app.extensions import db, migrate, jwt, cors


def create_app(config_object=None):
    """Application factory."""
    app = Flask(__name__, instance_relative_config=True)

    if config_object is None:
        config_object = get_config()
    app.config.from_object(config_object)

    # Ensure instance and upload folders exist
    try:
        os.makedirs(app.instance_path, exist_ok=True)
        os.makedirs(app.config.get("UPLOAD_FOLDER", "uploads"), exist_ok=True)
    except OSError:
        pass

    # Logging
    logging.basicConfig(
        level=getattr(logging, app.config.get("LOG_LEVEL", "INFO")),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # Extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    # Note: browsers forbid Access-Control-Allow-Origin: * together with
    # Access-Control-Allow-Credentials: true. Use * without credentials for local web.
    cors_origins = app.config.get("CORS_ORIGINS", "*")
    if cors_origins == "*" or cors_origins == ["*"]:
        cors.init_app(app, resources={r"/*": {"origins": "*"}})
    else:
        cors.init_app(
            app,
            origins=cors_origins if isinstance(cors_origins, list) else [cors_origins],
            supports_credentials=True,
        )

    # Optional OpenAPI (if flask-smorest installed)
    try:
        from app.extensions import api
        if api is not None:
            app.config.setdefault("API_TITLE", "RESQ API")
            app.config.setdefault("API_VERSION", "v1")
            app.config.setdefault("OPENAPI_VERSION", "3.0.3")
            app.config.setdefault("OPENAPI_URL_PREFIX", "/api/docs")
            app.config.setdefault("OPENAPI_SWAGGER_UI_PATH", "/swagger")
            app.config.setdefault(
                "OPENAPI_SWAGGER_UI_URL",
                "https://cdn.jsdelivr.net/npm/swagger-ui-dist/",
            )
            api.init_app(app)
    except Exception:
        pass

    # Register blueprints under /api/v1
    from app.routes import (
        auth_bp,
        user_bp,
        hub_bp,
        donation_bp,
        inventory_bp,
        transport_bp,
        disaster_bp,
        admin_bp,
    )
    from app.routes.delivery_routes import delivery_bp

    prefix = "/api/v1"
    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(hub_bp)
    app.register_blueprint(donation_bp)
    app.register_blueprint(inventory_bp)
    app.register_blueprint(transport_bp)
    app.register_blueprint(disaster_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(delivery_bp)

    # Health check
    @app.route(f"{prefix}/health")
    def health():
        return jsonify({"success": True, "message": "RESQ backend is running"}), 200

    @app.route(f"{prefix}/ready")
    def ready():
        try:
            db.session.execute(db.text("SELECT 1"))
            return jsonify({"success": True, "message": "Database ready"}), 200
        except Exception as e:
            return (
                jsonify(
                    {
                        "success": False,
                        "message": "Database not ready",
                        "error": str(e),
                    }
                ),
                503,
            )

    # JWT error handlers
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return (
            jsonify(
                {
                    "success": False,
                    "message": "Token has expired",
                    "error_code": "TOKEN_EXPIRED",
                }
            ),
            401,
        )

    @jwt.invalid_token_loader
    def invalid_token_callback(error):
        return (
            jsonify(
                {
                    "success": False,
                    "message": "Invalid token",
                    "error_code": "INVALID_TOKEN",
                }
            ),
            401,
        )

    @jwt.unauthorized_loader
    def missing_token_callback(error):
        return (
            jsonify(
                {
                    "success": False,
                    "message": "Authentication required",
                    "error_code": "UNAUTHORIZED",
                }
            ),
            401,
        )

    # Global error handler
    @app.errorhandler(404)
    def not_found(e):
        return (
            jsonify(
                {
                    "success": False,
                    "message": "Endpoint not found",
                    "error_code": "NOT_FOUND",
                }
            ),
            404,
        )

    @app.errorhandler(500)
    def internal_error(e):
        app.logger.exception("Internal server error")
        return (
            jsonify(
                {
                    "success": False,
                    "message": "Internal server error",
                    "error_code": "SERVER_ERROR",
                }
            ),
            500,
        )

    # Import models so Alembic can discover them
    with app.app_context():
        from app import models  # noqa: F401

    return app
