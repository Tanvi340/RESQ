"""Hub routes."""
from flask import Blueprint, g, request
from marshmallow import ValidationError as MarshmallowValidationError

from app.schemas.hub_schema import (
    HubCreateSchema,
    HubUpdateSchema,
    HubStatusSchema,
    NearbyHubsSchema,
)
from app.services.hub_service import HubService
from app.services.recommendation_service import RecommendationService
from app.services.capacity_service import CapacityService
from app.services.inventory_service import InventoryService
from app.utils.decorators import jwt_required_custom, hub_admin_required, roles_required
from app.utils.responses import success_response, error_response
from app.utils.exceptions import RESQException

hub_bp = Blueprint("hubs", __name__, url_prefix="/api/v1/hubs")

create_schema = HubCreateSchema()
update_schema = HubUpdateSchema()
status_schema = HubStatusSchema()
nearby_schema = NearbyHubsSchema()


@hub_bp.route("", methods=["GET"])
def list_hubs():
    try:
        city = request.args.get("city")
        status = request.args.get("status")
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 20, type=int)
        pagination = HubService.list_hubs(city=city, status=status, page=page, per_page=per_page)
        return success_response(
            [h.to_dict() for h in pagination.items],
            "Hubs retrieved",
            meta={
                "page": pagination.page,
                "per_page": pagination.per_page,
                "total": pagination.total,
                "pages": pagination.pages,
            },
        )
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@hub_bp.route("/nearby", methods=["GET"])
def nearby_hubs():
    try:
        args = {
            "latitude": request.args.get("latitude", type=float),
            "longitude": request.args.get("longitude", type=float),
            "radius_km": request.args.get("radius_km", 50.0, type=float),
            "resource_id": request.args.get("resource_id", type=int),
            "resource_category": request.args.get("resource_category"),
            "required_capacity": request.args.get("required_capacity", 0.0, type=float),
            "quantity": request.args.get("quantity", type=float),
        }
        # Filter None values for schema
        data = nearby_schema.load({k: v for k, v in args.items() if v is not None})
        results = RecommendationService.recommend_hubs(**data)
        return success_response(results, "Nearby hubs retrieved")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@hub_bp.route("/<int:hub_id>", methods=["GET"])
def get_hub(hub_id):
    try:
        hub = HubService.get_hub(hub_id)
        return success_response(hub.to_dict(include_admin=True), "Hub retrieved")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@hub_bp.route("/<int:hub_id>/capacity", methods=["GET"])
def get_capacity(hub_id):
    try:
        hub = HubService.get_hub(hub_id)
        summary = CapacityService.get_capacity_summary(hub)
        return success_response(summary, "Capacity retrieved")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@hub_bp.route("/<int:hub_id>/inventory", methods=["GET"])
def get_inventory(hub_id):
    try:
        items = InventoryService.get_hub_inventory(hub_id)
        return success_response(items, "Inventory retrieved")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@hub_bp.route("", methods=["POST"])
@hub_admin_required
def create_hub():
    try:
        data = create_schema.load(request.get_json(silent=True) or {})
        hub = HubService.create_hub(data, g.current_user)
        return success_response(hub.to_dict(include_admin=True), "Hub created", 201)
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@hub_bp.route("/<int:hub_id>", methods=["PATCH"])
@hub_admin_required
def update_hub(hub_id):
    try:
        data = update_schema.load(request.get_json(silent=True) or {})
        hub = HubService.update_hub(hub_id, data, g.current_user)
        return success_response(hub.to_dict(include_admin=True), "Hub updated")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@hub_bp.route("/<int:hub_id>/status", methods=["PATCH"])
@hub_admin_required
def update_status(hub_id):
    try:
        data = status_schema.load(request.get_json(silent=True) or {})
        hub = HubService.update_status(hub_id, data["operating_status"], g.current_user)
        return success_response(hub.to_dict(), "Hub status updated")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@hub_bp.route("/resources/catalog", methods=["GET"])
def resource_catalog():
    """Public list of active resources for donation forms."""
    from app.models.resource import Resource
    resources = Resource.query.filter_by(is_active=True).all()
    return success_response([r.to_dict() for r in resources], "Resources retrieved")

