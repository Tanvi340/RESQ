"""Disaster / relief operation routes."""
from flask import Blueprint, g, request
from marshmallow import Schema, fields, validate, ValidationError as MarshmallowValidationError

from app.extensions import db
from app.models.disaster import Disaster, DisasterType, DisasterStatus
from app.models.donation import Donation
from app.models.hub import Hub
from app.models.user import UserRole
from app.models.audit_log import AuditLog
from app.utils.decorators import jwt_required_custom, roles_required, super_admin_required
from app.utils.responses import success_response, error_response
from app.utils.exceptions import RESQException, NotFoundError, ForbiddenError

disaster_bp = Blueprint("disasters", __name__, url_prefix="/api/v1/disasters")


class DisasterCreateSchema(Schema):
    title = fields.Str(required=True, validate=validate.Length(min=3, max=255))
    disaster_type = fields.Str(
        required=True,
        validate=validate.OneOf([t.value for t in DisasterType]),
    )
    description = fields.Str(allow_none=True)
    affected_region = fields.Str(required=True)
    latitude = fields.Float(allow_none=True)
    longitude = fields.Float(allow_none=True)
    severity = fields.Str(load_default="MODERATE")
    start_date = fields.DateTime(allow_none=True)
    end_date = fields.DateTime(allow_none=True)


class DisasterUpdateSchema(Schema):
    title = fields.Str(validate=validate.Length(min=3, max=255))
    description = fields.Str(allow_none=True)
    affected_region = fields.Str()
    latitude = fields.Float(allow_none=True)
    longitude = fields.Float(allow_none=True)
    severity = fields.Str()
    status = fields.Str(validate=validate.OneOf([s.value for s in DisasterStatus]))
    start_date = fields.DateTime(allow_none=True)
    end_date = fields.DateTime(allow_none=True)


create_schema = DisasterCreateSchema()
update_schema = DisasterUpdateSchema()


@disaster_bp.route("", methods=["GET"])
def list_disasters():
    status = request.args.get("status")
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)
    q = Disaster.query
    if status:
        try:
            q = q.filter_by(status=DisasterStatus[status])
        except KeyError:
            return error_response(f"Invalid status: {status}", "VALIDATION_ERROR", 422)
    q = q.order_by(Disaster.created_at.desc())
    pagination = q.paginate(page=page, per_page=per_page, error_out=False)
    return success_response(
        [d.to_dict() for d in pagination.items],
        "Disasters retrieved",
        meta={
            "page": pagination.page,
            "per_page": pagination.per_page,
            "total": pagination.total,
            "pages": pagination.pages,
        },
    )


@disaster_bp.route("/<int:disaster_id>", methods=["GET"])
def get_disaster(disaster_id):
    disaster = db.session.get(Disaster, disaster_id)
    if not disaster:
        return error_response("Disaster not found", "NOT_FOUND", 404)
    return success_response(disaster.to_dict(), "Disaster retrieved")


@disaster_bp.route("", methods=["POST"])
@roles_required("HUB_ADMIN", "SUPER_ADMIN")
def create_disaster():
    try:
        data = create_schema.load(request.get_json(silent=True) or {})
        disaster = Disaster(
            title=data["title"],
            disaster_type=DisasterType[data["disaster_type"]],
            description=data.get("description"),
            affected_region=data["affected_region"],
            latitude=data.get("latitude"),
            longitude=data.get("longitude"),
            severity=data.get("severity", "MODERATE"),
            start_date=data.get("start_date"),
            end_date=data.get("end_date"),
            created_by=g.current_user.id,
            status=DisasterStatus.ACTIVE,
        )
        db.session.add(disaster)
        db.session.flush()
        log = AuditLog(
            actor_id=g.current_user.id,
            action="DISASTER_CREATED",
            entity_type="Disaster",
            entity_id=disaster.id,
        )
        db.session.add(log)
        db.session.commit()
        return success_response(disaster.to_dict(), "Disaster created", 201)
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@disaster_bp.route("/<int:disaster_id>", methods=["PATCH"])
@roles_required("HUB_ADMIN", "SUPER_ADMIN")
def update_disaster(disaster_id):
    try:
        disaster = db.session.get(Disaster, disaster_id)
        if not disaster:
            return error_response("Disaster not found", "NOT_FOUND", 404)
        data = update_schema.load(request.get_json(silent=True) or {})
        for field in (
            "title",
            "description",
            "affected_region",
            "latitude",
            "longitude",
            "severity",
            "start_date",
            "end_date",
        ):
            if field in data:
                setattr(disaster, field, data[field])
        if "status" in data:
            disaster.status = DisasterStatus[data["status"]]
        db.session.commit()
        return success_response(disaster.to_dict(), "Disaster updated")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@disaster_bp.route("/<int:disaster_id>/hubs", methods=["GET"])
def disaster_hubs(disaster_id):
    disaster = db.session.get(Disaster, disaster_id)
    if not disaster:
        return error_response("Disaster not found", "NOT_FOUND", 404)
    # Return active hubs (optionally near disaster location)
    hubs = Hub.query.filter_by(operating_status="ACTIVE").limit(50).all()
    return success_response([h.to_dict() for h in hubs], "Related hubs")


@disaster_bp.route("/<int:disaster_id>/donations", methods=["GET"])
@jwt_required_custom
def disaster_donations(disaster_id):
    disaster = db.session.get(Disaster, disaster_id)
    if not disaster:
        return error_response("Disaster not found", "NOT_FOUND", 404)
    donations = Donation.query.filter_by(disaster_id=disaster_id).all()
    return success_response(
        [d.to_dict(include_relations=True) for d in donations], "Disaster donations"
    )
