"""Delivery and tracking API routes."""
from flask import Blueprint, g, request
from marshmallow import Schema, fields, validate, ValidationError as MarshmallowValidationError

from app.services.delivery_service import DeliveryService
from app.utils.decorators import jwt_required_custom, hub_admin_required
from app.utils.responses import success_response, error_response
from app.utils.exceptions import RESQException
from datetime import datetime

delivery_bp = Blueprint("deliveries", __name__, url_prefix="/api/v1/deliveries")


class DeliveryItemSchema(Schema):
    resource_id = fields.Int(required=True)
    quantity = fields.Float(required=True, validate=validate.Range(min=0.01))
    unit = fields.Str(allow_none=True)


class AllocationSchema(Schema):
    donation_id = fields.Int(required=True)
    resource_id = fields.Int(required=True)
    allocated_quantity = fields.Float(required=True, validate=validate.Range(min=0.01))


class DeliveryCreateSchema(Schema):
    source_hub_id = fields.Int(required=True)
    disaster_id = fields.Int(allow_none=True)
    destination_name = fields.Str(required=True, validate=validate.Length(min=2, max=255))
    destination_address = fields.Str(allow_none=True)
    destination_latitude = fields.Float(required=True, validate=validate.Range(min=-90, max=90))
    destination_longitude = fields.Float(
        required=True, validate=validate.Range(min=-180, max=180)
    )
    assigned_agent_id = fields.Int(allow_none=True)
    notes = fields.Str(allow_none=True)
    items = fields.List(fields.Nested(DeliveryItemSchema), required=True)
    allocations = fields.List(fields.Nested(AllocationSchema), load_default=[])


class LocationSubmitSchema(Schema):
    latitude = fields.Float(required=True, validate=validate.Range(min=-90, max=90))
    longitude = fields.Float(required=True, validate=validate.Range(min=-180, max=180))
    accuracy_m = fields.Float(allow_none=True)
    recorded_at = fields.DateTime(allow_none=True)
    is_simulated = fields.Bool(load_default=False)


create_schema = DeliveryCreateSchema()
location_schema = LocationSubmitSchema()


@delivery_bp.route("", methods=["POST"])
@hub_admin_required
def create_delivery():
    try:
        data = create_schema.load(request.get_json(silent=True) or {})
        delivery = DeliveryService.create_delivery(g.current_user, data)
        return success_response(delivery.to_dict(), "Delivery created", 201)
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@delivery_bp.route("", methods=["GET"])
@jwt_required_custom
def list_deliveries():
    try:
        status = request.args.get("status")
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 20, type=int)
        pagination = DeliveryService.list_deliveries(
            g.current_user, status=status, page=page, per_page=per_page
        )
        return success_response(
            [d.to_dict() for d in pagination.items],
            "Deliveries retrieved",
            meta={
                "page": pagination.page,
                "per_page": pagination.per_page,
                "total": pagination.total,
                "pages": pagination.pages,
            },
        )
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@delivery_bp.route("/my", methods=["GET"])
@jwt_required_custom
def my_deliveries():
    return list_deliveries()


@delivery_bp.route("/<int:delivery_id>", methods=["GET"])
@jwt_required_custom
def get_delivery(delivery_id):
    try:
        delivery = DeliveryService.get_delivery(delivery_id, g.current_user)
        return success_response(delivery.to_dict(), "Delivery retrieved")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@delivery_bp.route("/<int:delivery_id>/assign", methods=["PATCH"])
@hub_admin_required
def assign_agent(delivery_id):
    try:
        body = request.get_json(silent=True) or {}
        agent_id = body.get("assigned_agent_id")
        if not agent_id:
            return error_response("assigned_agent_id required", "VALIDATION_ERROR", 422)
        delivery = DeliveryService.assign_agent(delivery_id, agent_id, g.current_user)
        return success_response(delivery.to_dict(), "Agent assigned")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@delivery_bp.route("/<int:delivery_id>/dispatch", methods=["POST"])
@jwt_required_custom
def dispatch(delivery_id):
    try:
        delivery = DeliveryService.dispatch(delivery_id, g.current_user)
        return success_response(delivery.to_dict(), "Delivery dispatched")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@delivery_bp.route("/<int:delivery_id>/arrive", methods=["POST"])
@jwt_required_custom
def arrive(delivery_id):
    try:
        delivery = DeliveryService.mark_arrived(delivery_id, g.current_user)
        return success_response(delivery.to_dict(), "Marked as arrived")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@delivery_bp.route("/<int:delivery_id>/complete", methods=["POST"])
@jwt_required_custom
def complete(delivery_id):
    try:
        delivery = DeliveryService.complete(delivery_id, g.current_user)
        return success_response(delivery.to_dict(), "Delivery completed")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@delivery_bp.route("/<int:delivery_id>/cancel", methods=["POST"])
@hub_admin_required
def cancel(delivery_id):
    try:
        delivery = DeliveryService.cancel(delivery_id, g.current_user)
        return success_response(delivery.to_dict(), "Delivery cancelled")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@delivery_bp.route("/<int:delivery_id>/locations", methods=["POST"])
@jwt_required_custom
def submit_location(delivery_id):
    try:
        data = location_schema.load(request.get_json(silent=True) or {})
        loc = DeliveryService.submit_location(
            delivery_id,
            g.current_user,
            latitude=data["latitude"],
            longitude=data["longitude"],
            accuracy_m=data.get("accuracy_m"),
            recorded_at=data.get("recorded_at"),
            is_simulated=data.get("is_simulated", False),
        )
        return success_response(loc.to_dict(), "Location recorded", 201)
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@delivery_bp.route("/<int:delivery_id>/location", methods=["GET"])
@jwt_required_custom
def latest_location(delivery_id):
    try:
        data = DeliveryService.get_latest_location(delivery_id, g.current_user)
        return success_response(data, "Latest location")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@delivery_bp.route("/<int:delivery_id>/locations", methods=["GET"])
@jwt_required_custom
def location_history(delivery_id):
    try:
        limit = request.args.get("limit", 100, type=int)
        history = DeliveryService.get_location_history(
            delivery_id, g.current_user, limit=limit
        )
        return success_response(history, "Location history")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
