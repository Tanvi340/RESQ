"""User profile routes."""
from flask import Blueprint, g, request
from marshmallow import ValidationError as MarshmallowValidationError

from app.schemas.user_schema import UserUpdateSchema
from app.utils.decorators import jwt_required_custom
from app.utils.responses import success_response, error_response
from app.utils.exceptions import RESQException
from app.extensions import db

user_bp = Blueprint("users", __name__, url_prefix="/api/v1/users")
update_schema = UserUpdateSchema()


@user_bp.route("/me", methods=["PATCH"])
@jwt_required_custom
def update_me():
    try:
        data = update_schema.load(request.get_json(silent=True) or {})
        user = g.current_user
        if "full_name" in data:
            user.full_name = data["full_name"]
        if "phone_number" in data:
            user.phone_number = data["phone_number"]
        db.session.commit()
        return success_response(user.to_dict(), "Profile updated")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)
