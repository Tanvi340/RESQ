"""Inventory routes."""
from flask import Blueprint, g, request
from marshmallow import ValidationError as MarshmallowValidationError

from app.schemas.inventory_schema import InventoryAdjustSchema
from app.services.inventory_service import InventoryService
from app.utils.decorators import jwt_required_custom, hub_admin_required
from app.utils.responses import success_response, error_response
from app.utils.exceptions import RESQException

inventory_bp = Blueprint("inventory", __name__, url_prefix="/api/v1/inventory")
adjust_schema = InventoryAdjustSchema()


@inventory_bp.route("", methods=["GET"])
@hub_admin_required
def list_inventory():
    """List inventory for hubs managed by current admin."""
    from app.models.hub import Hub
    from app.models.user import UserRole
    from app.models.inventory import Inventory

    user = g.current_user
    if user.role == UserRole.SUPER_ADMIN:
        items = Inventory.query.all()
    else:
        hub_ids = [h.id for h in Hub.query.filter_by(admin_id=user.id).all()]
        items = Inventory.query.filter(Inventory.hub_id.in_(hub_ids)).all()
    return success_response(
        [i.to_dict(include_relations=True) for i in items], "Inventory retrieved"
    )


@inventory_bp.route("/<int:hub_id>", methods=["GET"])
@jwt_required_custom
def get_hub_inventory(hub_id):
    try:
        items = InventoryService.get_hub_inventory(hub_id, g.current_user)
        return success_response(items, "Hub inventory retrieved")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@inventory_bp.route("/<int:hub_id>/<int:resource_id>", methods=["GET"])
@jwt_required_custom
def get_item(hub_id, resource_id):
    try:
        inv = InventoryService.get_item(hub_id, resource_id)
        return success_response(inv.to_dict(include_relations=True), "Inventory item retrieved")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@inventory_bp.route("/adjustments", methods=["POST"])
@hub_admin_required
def adjust():
    try:
        data = adjust_schema.load(request.get_json(silent=True) or {})
        inv = InventoryService.adjust_inventory(data, g.current_user)
        return success_response(inv.to_dict(include_relations=True), "Inventory adjusted")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)
