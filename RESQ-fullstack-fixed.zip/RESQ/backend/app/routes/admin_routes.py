"""Administrator dashboard summary routes."""
from flask import Blueprint, g
from sqlalchemy import func

from app.extensions import db
from app.models.user import User, UserRole
from app.models.hub import Hub, HubStatus
from app.models.donation import Donation, DonationStatus
from app.models.inventory import Inventory
from app.models.resource import Resource
from app.models.audit_log import AuditLog
from app.utils.decorators import jwt_required_custom, hub_admin_required, super_admin_required
from app.utils.responses import success_response, error_response

admin_bp = Blueprint("admin", __name__, url_prefix="/api/v1/admin")


@admin_bp.route("/dashboard", methods=["GET"])
@hub_admin_required
def dashboard():
    user = g.current_user

    if user.role == UserRole.SUPER_ADMIN:
        return _global_dashboard()
    return _hub_admin_dashboard(user)


def _global_dashboard():
    total_donors = User.query.filter_by(role=UserRole.DONOR).count()
    active_hubs = Hub.query.filter_by(operating_status=HubStatus.ACTIVE).count()
    pending = Donation.query.filter_by(status=DonationStatus.PENDING_APPROVAL).count()
    awaiting_transport = Donation.query.filter(
        Donation.status.in_(
            [DonationStatus.TRANSPORT_PENDING, DonationStatus.TRANSPORT_ARRANGED]
        )
    ).count()
    in_transit = Donation.query.filter_by(status=DonationStatus.IN_TRANSIT).count()
    received = Donation.query.filter_by(status=DonationStatus.RECEIVED).count()

    capacity = db.session.query(
        func.sum(Hub.total_storage_capacity),
        func.sum(Hub.reserved_capacity),
        func.sum(Hub.current_occupied_capacity),
    ).first()

    inv_summary = (
        db.session.query(Resource.category, func.sum(Inventory.available_quantity))
        .join(Inventory, Inventory.resource_id == Resource.id)
        .group_by(Resource.category)
        .all()
    )

    recent_logs = (
        AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(20).all()
    )

    return success_response(
        {
            "total_donors": total_donors,
            "total_active_hubs": active_hubs,
            "pending_approvals": pending,
            "awaiting_transport": awaiting_transport,
            "in_transit": in_transit,
            "received": received,
            "capacity": {
                "total": float(capacity[0] or 0),
                "reserved": float(capacity[1] or 0),
                "occupied": float(capacity[2] or 0),
                "available": float(
                    (capacity[0] or 0) - (capacity[1] or 0) - (capacity[2] or 0)
                ),
            },
            "inventory_by_category": [
                {"category": c, "quantity": float(q or 0)} for c, q in inv_summary
            ],
            "recent_activity": [l.to_dict() for l in recent_logs],
        },
        "Global dashboard",
    )


def _hub_admin_dashboard(user: User):
    hubs = Hub.query.filter_by(admin_id=user.id).all()
    hub_ids = [h.id for h in hubs]

    pending = Donation.query.filter(
        Donation.hub_id.in_(hub_ids),
        Donation.status == DonationStatus.PENDING_APPROVAL,
    ).count()
    awaiting = Donation.query.filter(
        Donation.hub_id.in_(hub_ids),
        Donation.status.in_(
            [DonationStatus.TRANSPORT_PENDING, DonationStatus.TRANSPORT_ARRANGED]
        ),
    ).count()
    in_transit = Donation.query.filter(
        Donation.hub_id.in_(hub_ids),
        Donation.status == DonationStatus.IN_TRANSIT,
    ).count()
    received = Donation.query.filter(
        Donation.hub_id.in_(hub_ids),
        Donation.status == DonationStatus.RECEIVED,
    ).count()

    capacity_data = []
    for h in hubs:
        capacity_data.append(
            {
                "hub_id": h.id,
                "name": h.name,
                "total": h.total_storage_capacity,
                "reserved": h.reserved_capacity,
                "occupied": h.current_occupied_capacity,
                "available": h.available_capacity,
                "status": h.operating_status.value,
            }
        )

    return success_response(
        {
            "managed_hubs": len(hubs),
            "pending_approvals": pending,
            "awaiting_transport": awaiting,
            "in_transit": in_transit,
            "received": received,
            "hubs_capacity": capacity_data,
        },
        "Hub admin dashboard",
    )


@admin_bp.route("/resources", methods=["GET"])
def list_resources():
    """Public list of active resources."""
    from app.models.resource import Resource

    resources = Resource.query.filter_by(is_active=True).all()
    return success_response([r.to_dict() for r in resources], "Resources retrieved")


@admin_bp.route("/agents", methods=["GET"])
@hub_admin_required
def list_agents():
    """List active delivery agents for assignment dropdowns."""
    agents = User.query.filter_by(role=UserRole.DELIVERY_AGENT, is_active=True).all()
    return success_response(
        [
            {
                "id": u.id,
                "full_name": u.full_name,
                "email": u.email,
                "phone_number": u.phone_number,
            }
            for u in agents
        ],
        "Delivery agents retrieved",
    )

