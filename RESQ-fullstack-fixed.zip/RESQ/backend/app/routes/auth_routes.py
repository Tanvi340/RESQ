"""Authentication routes."""
from flask import Blueprint, g
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
from marshmallow import ValidationError as MarshmallowValidationError

from app.schemas.auth_schema import RegisterSchema, LoginSchema, ChangePasswordSchema
from app.services.auth_service import AuthService
from app.utils.decorators import jwt_required_custom
from app.utils.responses import success_response, error_response
from app.utils.exceptions import RESQException

auth_bp = Blueprint("auth", __name__, url_prefix="/api/v1/auth")

register_schema = RegisterSchema()
login_schema = LoginSchema()
change_pw_schema = ChangePasswordSchema()


@auth_bp.route("/register", methods=["POST"])
def register():
    try:
        data = register_schema.load(request_json())
        user = AuthService.register(**data)
        return success_response(
            user.to_dict(), "Registration successful", 201
        )
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@auth_bp.route("/login", methods=["POST"])
def login():
    try:
        data = login_schema.load(request_json())
        result = AuthService.login(data["email"], data["password"])
        return success_response(result, "Login successful")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@auth_bp.route("/refresh", methods=["POST"])
@jwt_required(refresh=True)
def refresh():
    try:
        identity = get_jwt_identity()
        result = AuthService.refresh_token(identity)
        return success_response(result, "Token refreshed")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@auth_bp.route("/logout", methods=["POST"])
@jwt_required_custom
def logout():
    # Stateless JWT – client discards token. Optional blacklist can be added later.
    return success_response(None, "Logged out successfully")


@auth_bp.route("/me", methods=["GET"])
@jwt_required_custom
def me():
    return success_response(g.current_user.to_dict(), "Current user")


@auth_bp.route("/change-password", methods=["POST"])
@jwt_required_custom
def change_password():
    try:
        data = change_pw_schema.load(request_json())
        AuthService.change_password(
            g.current_user, data["current_password"], data["new_password"]
        )
        return success_response(None, "Password changed successfully")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


def request_json():
    from flask import request
    if not request.is_json:
        return {}
    return request.get_json(silent=True) or {}
