"""Transport routes."""
from flask import Blueprint, g, request
from marshmallow import ValidationError as MarshmallowValidationError

from app.schemas.transport_schema import (
    TransportCreateSchema,
    TransportUpdateSchema,
    TransportScheduleSchema,
)
from app.services.transport_service import TransportService
from app.models.transport import TransportStatus
from app.utils.decorators import jwt_required_custom
from app.utils.responses import success_response, error_response
from app.utils.exceptions import RESQException

transport_bp = Blueprint("transport", __name__, url_prefix="/api/v1")

create_schema = TransportCreateSchema()
update_schema = TransportUpdateSchema()
schedule_schema = TransportScheduleSchema()


# Nested under donations
@transport_bp.route("/donations/<int:donation_id>/transport", methods=["POST"])
@jwt_required_custom
def create_transport(donation_id):
    try:
        data = create_schema.load(request.get_json(silent=True) or {})
        transport = TransportService.create_transport(donation_id, data, g.current_user)
        return success_response(transport.to_dict(), "Transport created", 201)
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@transport_bp.route("/donations/<int:donation_id>/transport", methods=["GET"])
@jwt_required_custom
def get_transport(donation_id):
    try:
        transport = TransportService.get_transport(donation_id)
        return success_response(transport.to_dict(), "Transport retrieved")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@transport_bp.route("/transport/<int:transport_id>", methods=["PATCH"])
@jwt_required_custom
def update_transport(transport_id):
    try:
        from app.extensions import db
        from app.models.transport import Transport

        data = update_schema.load(request.get_json(silent=True) or {})
        transport = db.session.get(Transport, transport_id)
        if not transport:
            return error_response("Transport not found", "NOT_FOUND", 404)

        for field in (
            "transport_method",
            "pickup_address",
            "destination_address",
            "scheduled_at",
            "tracking_notes",
        ):
            if field in data:
                setattr(transport, field, data[field])
        db.session.commit()
        return success_response(transport.to_dict(), "Transport updated")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@transport_bp.route("/transport/<int:transport_id>/schedule", methods=["POST"])
@jwt_required_custom
def schedule_transport(transport_id):
    try:
        data = schedule_schema.load(request.get_json(silent=True) or {})
        transport = TransportService.schedule_transport(
            transport_id, data, g.current_user
        )
        return success_response(transport.to_dict(), "Transport scheduled")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@transport_bp.route("/transport/<int:transport_id>/mark-picked-up", methods=["POST"])
@jwt_required_custom
def mark_picked_up(transport_id):
    try:
        notes = (request.get_json(silent=True) or {}).get("tracking_notes")
        transport = TransportService.mark_status(
            transport_id, TransportStatus.PICKED_UP, g.current_user, notes
        )
        return success_response(transport.to_dict(), "Marked as picked up")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@transport_bp.route("/transport/<int:transport_id>/mark-in-transit", methods=["POST"])
@jwt_required_custom
def mark_in_transit(transport_id):
    try:
        notes = (request.get_json(silent=True) or {}).get("tracking_notes")
        transport = TransportService.mark_status(
            transport_id, TransportStatus.IN_TRANSIT, g.current_user, notes
        )
        return success_response(transport.to_dict(), "Marked as in transit")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@transport_bp.route("/transport/<int:transport_id>/mark-delivered", methods=["POST"])
@jwt_required_custom
def mark_delivered(transport_id):
    try:
        notes = (request.get_json(silent=True) or {}).get("tracking_notes")
        transport = TransportService.mark_status(
            transport_id, TransportStatus.DELIVERED, g.current_user, notes
        )
        return success_response(
            transport.to_dict(),
            "Marked as delivered. Hub admin must still confirm receipt.",
        )
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)
