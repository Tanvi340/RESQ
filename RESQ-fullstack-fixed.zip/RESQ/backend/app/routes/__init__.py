"""API route blueprints."""
from app.routes.auth_routes import auth_bp
from app.routes.user_routes import user_bp
from app.routes.hub_routes import hub_bp
from app.routes.donation_routes import donation_bp
from app.routes.inventory_routes import inventory_bp
from app.routes.transport_routes import transport_bp
from app.routes.disaster_routes import disaster_bp
from app.routes.admin_routes import admin_bp

__all__ = [
    "auth_bp",
    "user_bp",
    "hub_bp",
    "donation_bp",
    "inventory_bp",
    "transport_bp",
    "disaster_bp",
    "admin_bp",
]
from app.routes.delivery_routes import delivery_bp
