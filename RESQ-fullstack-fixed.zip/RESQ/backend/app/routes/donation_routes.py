"""Donation routes."""
from flask import Blueprint, g, request
from marshmallow import ValidationError as MarshmallowValidationError

from app.schemas.donation_schema import (
    DonationCreateSchema,
    DonationRejectSchema,
    DonationApproveSchema,
)
from app.services.donation_service import DonationService
from app.models.donation import Donation, DonationStatus
from app.models.user import UserRole
from app.models.audit_log import AuditLog
from app.extensions import db
from app.utils.decorators import jwt_required_custom, hub_admin_required
from app.utils.responses import success_response, error_response
from app.utils.exceptions import RESQException

donation_bp = Blueprint("donations", __name__, url_prefix="/api/v1/donations")

create_schema = DonationCreateSchema()
reject_schema = DonationRejectSchema()
approve_schema = DonationApproveSchema()


@donation_bp.route("", methods=["POST"])
@jwt_required_custom
def create_donation():
    try:
        data = create_schema.load(request.get_json(silent=True) or {})
        donation = DonationService.create_donation(g.current_user, data)
        return success_response(
            donation.to_dict(include_relations=True), "Donation created successfully", 201
        )
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@donation_bp.route("", methods=["GET"])
@jwt_required_custom
def list_donations():
    """List donations visible to current user (admin sees hub donations, donor sees own)."""
    try:
        status = request.args.get("status")
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 20, type=int)
        user = g.current_user

        q = Donation.query
        if user.role == UserRole.DONOR:
            q = q.filter_by(donor_id=user.id)
        elif user.role == UserRole.HUB_ADMIN:
            from app.models.hub import Hub
            hub_ids = [h.id for h in Hub.query.filter_by(admin_id=user.id).all()]
            q = q.filter(Donation.hub_id.in_(hub_ids))
        # SUPER_ADMIN sees all

        if status:
            try:
                q = q.filter_by(status=DonationStatus[status])
            except KeyError:
                return error_response(f"Invalid status: {status}", "VALIDATION_ERROR", 422)

        q = q.order_by(Donation.created_at.desc())
        pagination = q.paginate(page=page, per_page=per_page, error_out=False)
        return success_response(
            [d.to_dict(include_relations=True) for d in pagination.items],
            "Donations retrieved",
            meta={
                "page": pagination.page,
                "per_page": pagination.per_page,
                "total": pagination.total,
                "pages": pagination.pages,
            },
        )
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@donation_bp.route("/my", methods=["GET"])
@jwt_required_custom
def my_donations():
    try:
        status = request.args.get("status")
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 20, type=int)
        pagination = DonationService.list_my_donations(
            g.current_user, status=status, page=page, per_page=per_page
        )
        return success_response(
            [d.to_dict(include_relations=True) for d in pagination.items],
            "My donations retrieved",
            meta={
                "page": pagination.page,
                "per_page": pagination.per_page,
                "total": pagination.total,
                "pages": pagination.pages,
            },
        )
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@donation_bp.route("/<int:donation_id>", methods=["GET"])
@jwt_required_custom
def get_donation(donation_id):
    try:
        donation = DonationService.get_donation(donation_id, g.current_user)
        return success_response(
            donation.to_dict(include_relations=True), "Donation retrieved"
        )
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)


@donation_bp.route("/<int:donation_id>/cancel", methods=["PATCH"])
@jwt_required_custom
def cancel_donation(donation_id):
    try:
        donation = DonationService.cancel_donation(donation_id, g.current_user)
        return success_response(donation.to_dict(), "Donation cancelled")
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@donation_bp.route("/<int:donation_id>/approve", methods=["POST"])
@hub_admin_required
def approve_donation(donation_id):
    try:
        data = approve_schema.load(request.get_json(silent=True) or {})
        donation = DonationService.approve_donation(
            donation_id, g.current_user, data.get("admin_notes")
        )
        return success_response(donation.to_dict(include_relations=True), "Donation approved")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@donation_bp.route("/<int:donation_id>/reject", methods=["POST"])
@hub_admin_required
def reject_donation(donation_id):
    try:
        data = reject_schema.load(request.get_json(silent=True) or {})
        donation = DonationService.reject_donation(
            donation_id,
            g.current_user,
            data["rejection_reason"],
            data.get("admin_notes"),
        )
        return success_response(donation.to_dict(), "Donation rejected")
    except MarshmallowValidationError as e:
        return error_response("Validation error", "VALIDATION_ERROR", 422, e.messages)
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@donation_bp.route("/<int:donation_id>/confirm-receipt", methods=["POST"])
@hub_admin_required
def confirm_receipt(donation_id):
    try:
        donation = DonationService.confirm_receipt(donation_id, g.current_user)
        return success_response(
            donation.to_dict(include_relations=True), "Receipt confirmed"
        )
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
    except Exception as e:
        return error_response(str(e), "SERVER_ERROR", 500)


@donation_bp.route("/<int:donation_id>/history", methods=["GET"])
@jwt_required_custom
def donation_history(donation_id):
    try:
        donation = DonationService.get_donation(donation_id, g.current_user)
        logs = (
            AuditLog.query.filter_by(entity_type="Donation", entity_id=donation_id)
            .order_by(AuditLog.timestamp.asc())
            .all()
        )
        return success_response(
            {
                "donation": donation.to_dict(include_relations=True),
                "history": [l.to_dict() for l in logs],
            },
            "Donation history retrieved",
        )
    except RESQException as e:
        return error_response(e.message, e.error_code, e.status_code)
