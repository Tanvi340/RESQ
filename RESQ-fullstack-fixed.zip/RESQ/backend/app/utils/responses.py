"""Consistent API response helpers."""
from typing import Any, Optional
from flask import jsonify


def success_response(
    data: Any = None,
    message: str = "Success",
    status_code: int = 200,
    meta: Optional[dict] = None,
):
    """Build a successful JSON response."""
    body = {
        "success": True,
        "message": message,
    }
    if data is not None:
        body["data"] = data
    if meta is not None:
        body["meta"] = meta
    return jsonify(body), status_code


def error_response(
    message: str,
    error_code: str = "ERROR",
    status_code: int = 400,
    errors: Optional[Any] = None,
):
    """Build an error JSON response."""
    body = {
        "success": False,
        "message": message,
        "error_code": error_code,
    }
    if errors is not None:
        body["errors"] = errors
    return jsonify(body), status_code
