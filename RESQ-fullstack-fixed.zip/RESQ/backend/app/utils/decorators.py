"""Custom decorators for authorization."""
from functools import wraps
from typing import Callable, List, Optional

from flask_jwt_extended import get_jwt_identity, verify_jwt_in_request
from flask import g

from app.extensions import db
from app.models.user import User, UserRole
from app.utils.exceptions import ForbiddenError, UnauthorizedError
from app.utils.responses import error_response


def jwt_required_custom(fn: Callable) -> Callable:
    """Require valid JWT access token."""

    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            verify_jwt_in_request()
            identity = get_jwt_identity()
            user = db.session.get(User, int(identity))
            if not user or not user.is_active:
                return error_response("Invalid or inactive user", "UNAUTHORIZED", 401)
            g.current_user = user
            return fn(*args, **kwargs)
        except Exception:
            return error_response("Authentication required", "UNAUTHORIZED", 401)

    return wrapper


def roles_required(*roles: str) -> Callable:
    """Require the current user to have one of the specified roles."""

    def decorator(fn: Callable) -> Callable:
        @wraps(fn)
        @jwt_required_custom
        def wrapper(*args, **kwargs):
            user: User = g.current_user
            if user.role.value not in roles and user.role != UserRole.SUPER_ADMIN:
                # Super admin can do everything
                if UserRole.SUPER_ADMIN.value not in roles and user.role != UserRole.SUPER_ADMIN:
                    return error_response(
                        "Insufficient permissions", "FORBIDDEN", 403
                    )
            return fn(*args, **kwargs)

        return wrapper

    return decorator


def hub_admin_required(fn: Callable) -> Callable:
    """Require HUB_ADMIN or SUPER_ADMIN role."""

    @wraps(fn)
    @jwt_required_custom
    def wrapper(*args, **kwargs):
        user: User = g.current_user
        if user.role not in (UserRole.HUB_ADMIN, UserRole.SUPER_ADMIN):
            return error_response("Hub administrator access required", "FORBIDDEN", 403)
        return fn(*args, **kwargs)

    return wrapper


def super_admin_required(fn: Callable) -> Callable:
    """Require SUPER_ADMIN role."""

    @wraps(fn)
    @jwt_required_custom
    def wrapper(*args, **kwargs):
        user: User = g.current_user
        if user.role != UserRole.SUPER_ADMIN:
            return error_response("Super administrator access required", "FORBIDDEN", 403)
        return fn(*args, **kwargs)

    return wrapper
