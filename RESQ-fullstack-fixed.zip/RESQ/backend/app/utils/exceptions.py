"""Custom application exceptions."""


class RESQException(Exception):
    """Base RESQ exception."""

    def __init__(self, message: str, error_code: str = "ERROR", status_code: int = 400):
        self.message = message
        self.error_code = error_code
        self.status_code = status_code
        super().__init__(self.message)


class ValidationError(RESQException):
    def __init__(self, message: str, error_code: str = "VALIDATION_ERROR"):
        super().__init__(message, error_code, 422)


class NotFoundError(RESQException):
    def __init__(self, message: str = "Resource not found", error_code: str = "NOT_FOUND"):
        super().__init__(message, error_code, 404)


class UnauthorizedError(RESQException):
    def __init__(self, message: str = "Unauthorized", error_code: str = "UNAUTHORIZED"):
        super().__init__(message, error_code, 401)


class ForbiddenError(RESQException):
    def __init__(self, message: str = "Forbidden", error_code: str = "FORBIDDEN"):
        super().__init__(message, error_code, 403)


class ConflictError(RESQException):
    def __init__(self, message: str, error_code: str = "CONFLICT"):
        super().__init__(message, error_code, 409)


class InsufficientCapacityError(RESQException):
    def __init__(self, message: str = "Insufficient available capacity"):
        super().__init__(message, "INSUFFICIENT_CAPACITY", 409)


class InvalidStateTransitionError(RESQException):
    def __init__(self, message: str = "Invalid state transition"):
        super().__init__(message, "INVALID_STATE_TRANSITION", 409)
