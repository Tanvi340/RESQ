"""Application configuration."""
import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Base configuration."""

    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key-change-in-production")
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "dev-jwt-secret-key-change-in-production")

    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", "sqlite:///resq.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
    }

    JWT_ACCESS_TOKEN_EXPIRES = timedelta(
        seconds=int(os.getenv("JWT_ACCESS_TOKEN_EXPIRES", 3600))
    )
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(
        seconds=int(os.getenv("JWT_REFRESH_TOKEN_EXPIRES", 2592000))
    )
    JWT_TOKEN_LOCATION = ["headers"]
    JWT_HEADER_NAME = "Authorization"
    JWT_HEADER_TYPE = "Bearer"

    # "*" allows all origins (needed for Flutter web on random ports during local dev)
    _cors = os.getenv("CORS_ORIGINS", "*")
    CORS_ORIGINS = (
        "*"
        if _cors.strip() == "*"
        else [origin.strip() for origin in _cors.split(",") if origin.strip()]
    )

    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "uploads")
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_LENGTH", 10 * 1024 * 1024))
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "pdf", "webp"}

    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

    # Capacity: default volume estimates per unit by category (liters equivalent)
    # Used when explicit volume is not provided
    CATEGORY_VOLUME_ESTIMATES = {
        "Clothing": 5.0,
        "Blankets": 8.0,
        "Food": 2.0,
        "Drinking Water": 1.0,  # per liter/bottle
        "Hygiene Kits": 3.0,
        "Medical Supplies": 1.5,
        "Shelter Materials": 20.0,
        "Baby Supplies": 2.5,
        "Other Essentials": 3.0,
    }

    # Recommendation weights
    REC_WEIGHT_DISTANCE = 0.40
    REC_WEIGHT_CAPACITY = 0.30
    REC_WEIGHT_COMPATIBILITY = 0.20
    REC_WEIGHT_STATUS = 0.10


class DevelopmentConfig(Config):
    DEBUG = True
    TESTING = False


class TestingConfig(Config):
    DEBUG = True
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(seconds=300)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(seconds=600)


class ProductionConfig(Config):
    DEBUG = False
    TESTING = False

    def __init__(self):
        super().__init__()
        if self.SECRET_KEY in (
            "dev-secret-key-change-in-production",
            "replace-with-a-random-secret-key-at-least-32-chars",
        ):
            raise ValueError("Production SECRET_KEY must be set to a secure random value")
        if self.JWT_SECRET_KEY in (
            "dev-jwt-secret-key-change-in-production",
            "replace-with-another-random-secret-key-at-least-32-chars",
        ):
            raise ValueError("Production JWT_SECRET_KEY must be set to a secure random value")


config_by_name = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}


def get_config():
    env = os.getenv("FLASK_ENV", "development")
    return config_by_name.get(env, DevelopmentConfig)
