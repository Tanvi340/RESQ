"""Inventory management service."""
from datetime import datetime, timezone

from app.extensions import db
from app.models.user import User, UserRole
from app.models.hub import Hub
from app.models.resource import Resource
from app.models.inventory import Inventory
from app.models.audit_log import AuditLog
from app.utils.exceptions import NotFoundError, ForbiddenError, ValidationError, ConflictError


class InventoryService:
    @staticmethod
    def get_hub_inventory(hub_id: int, user: User = None) -> list:
        hub = db.session.get(Hub, hub_id)
        if not hub:
            raise NotFoundError("Hub not found")

        items = Inventory.query.filter_by(hub_id=hub_id).all()
        return [i.to_dict(include_relations=True) for i in items]

    @staticmethod
    def get_item(hub_id: int, resource_id: int) -> Inventory:
        inv = Inventory.query.filter_by(hub_id=hub_id, resource_id=resource_id).first()
        if not inv:
            raise NotFoundError("Inventory item not found")
        return inv

    @staticmethod
    def adjust_inventory(data: dict, user: User) -> Inventory:
        hub = db.session.get(Hub, data["hub_id"])
        if not hub:
            raise NotFoundError("Hub not found")

        if user.role != UserRole.SUPER_ADMIN and hub.admin_id != user.id:
            raise ForbiddenError("Not authorized to adjust inventory for this hub")

        resource = db.session.get(Resource, data["resource_id"])
        if not resource:
            raise NotFoundError("Resource not found")

        inv = Inventory.query.filter_by(
            hub_id=hub.id, resource_id=resource.id
        ).first()
        if not inv:
            inv = Inventory(
                hub_id=hub.id,
                resource_id=resource.id,
                available_quantity=0.0,
                reserved_quantity=0.0,
                unit=data.get("unit") or resource.default_unit,
            )
            db.session.add(inv)
            db.session.flush()

        change = data["quantity_change"]
        new_qty = inv.available_quantity + change
        if new_qty < 0:
            raise ConflictError(
                f"Adjustment would result in negative inventory ({new_qty})",
                "NEGATIVE_INVENTORY",
            )

        prev_qty = inv.available_quantity
        inv.available_quantity = new_qty
        inv.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action="INVENTORY_ADJUSTED",
            entity_type="Inventory",
            entity_id=inv.id,
        )
        log.set_previous_state({"available_quantity": prev_qty})
        log.set_new_state({"available_quantity": new_qty})
        log.set_extra({"reason": data["reason"], "change": change})
        db.session.add(log)
        db.session.commit()
        return inv
