"""Transport coordination service."""
from datetime import datetime, timezone

from app.extensions import db
from app.models.user import User, UserRole
from app.models.donation import Donation, DonationStatus
from app.models.transport import (
    Transport,
    TransportStatus,
    TransportResponsibleParty,
)
from app.models.audit_log import AuditLog
from app.services.notification_service import NotificationService
from app.utils.exceptions import (
    NotFoundError,
    ForbiddenError,
    ConflictError,
    ValidationError,
    InvalidStateTransitionError,
)


class TransportService:
    @staticmethod
    def create_transport(donation_id: int, data: dict, user: User) -> Transport:
        donation = db.session.get(Donation, donation_id)
        if not donation:
            raise NotFoundError("Donation not found")

        if donation.transport:
            raise ConflictError("Transport already exists for this donation")

        # Authorization
        is_donor = donation.donor_id == user.id
        is_hub_admin = (
            user.role == UserRole.HUB_ADMIN and donation.hub.admin_id == user.id
        )
        is_super = user.role == UserRole.SUPER_ADMIN
        if not (is_donor or is_hub_admin or is_super):
            raise ForbiddenError("Not authorized")

        if donation.status not in (
            DonationStatus.APPROVED,
            DonationStatus.TRANSPORT_PENDING,
        ):
            raise InvalidStateTransitionError(
                f"Cannot arrange transport for status {donation.status.value}"
            )

        party = TransportResponsibleParty[data["responsible_party"]]
        transport = Transport(
            donation_id=donation.id,
            responsible_party=party,
            transport_method=data.get("transport_method"),
            pickup_address=data.get("pickup_address") or donation.donor_address,
            destination_address=data.get("destination_address") or donation.hub.address,
            scheduled_at=data.get("scheduled_at"),
            tracking_notes=data.get("tracking_notes"),
            status=(
                TransportStatus.SCHEDULED
                if data.get("scheduled_at")
                else TransportStatus.NOT_ARRANGED
            ),
        )
        db.session.add(transport)

        if transport.status == TransportStatus.SCHEDULED:
            donation.status = DonationStatus.TRANSPORT_ARRANGED
        else:
            donation.status = DonationStatus.TRANSPORT_PENDING
        donation.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action="TRANSPORT_CREATED",
            entity_type="Transport",
            entity_id=None,
        )
        log.set_new_state(transport.to_dict())
        db.session.add(log)
        db.session.commit()

        if transport.status == TransportStatus.SCHEDULED:
            NotificationService.notify_transport_scheduled(donation, transport)
        return transport

    @staticmethod
    def schedule_transport(transport_id: int, data: dict, user: User) -> Transport:
        transport = db.session.get(Transport, transport_id)
        if not transport:
            raise NotFoundError("Transport not found")

        donation = transport.donation
        is_donor = donation.donor_id == user.id
        is_hub_admin = (
            user.role == UserRole.HUB_ADMIN and donation.hub.admin_id == user.id
        )
        is_super = user.role == UserRole.SUPER_ADMIN
        if not (is_donor or is_hub_admin or is_super):
            raise ForbiddenError("Not authorized")

        if not transport.can_transition_to(TransportStatus.SCHEDULED):
            raise InvalidStateTransitionError(
                f"Cannot schedule from status {transport.status.value}"
            )

        transport.scheduled_at = data["scheduled_at"]
        if data.get("transport_method"):
            transport.transport_method = data["transport_method"]
        if data.get("pickup_address"):
            transport.pickup_address = data["pickup_address"]
        if data.get("destination_address"):
            transport.destination_address = data["destination_address"]
        if data.get("tracking_notes"):
            transport.tracking_notes = data["tracking_notes"]
        transport.status = TransportStatus.SCHEDULED
        transport.updated_at = datetime.now(timezone.utc)

        donation.status = DonationStatus.TRANSPORT_ARRANGED
        donation.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action="TRANSPORT_SCHEDULED",
            entity_type="Transport",
            entity_id=transport.id,
        )
        db.session.add(log)
        db.session.commit()

        NotificationService.notify_transport_scheduled(donation, transport)
        return transport

    @staticmethod
    def mark_status(
        transport_id: int, new_status: TransportStatus, user: User, notes: str = None
    ) -> Transport:
        transport = db.session.get(Transport, transport_id)
        if not transport:
            raise NotFoundError("Transport not found")

        donation = transport.donation
        is_donor = donation.donor_id == user.id
        is_hub_admin = (
            user.role == UserRole.HUB_ADMIN and donation.hub.admin_id == user.id
        )
        is_super = user.role == UserRole.SUPER_ADMIN
        if not (is_donor or is_hub_admin or is_super):
            raise ForbiddenError("Not authorized")

        if not transport.can_transition_to(new_status):
            raise InvalidStateTransitionError(
                f"Cannot transition from {transport.status.value} to {new_status.value}"
            )

        prev = transport.status.value
        transport.status = new_status
        if notes:
            transport.tracking_notes = (
                (transport.tracking_notes or "") + f"\n{notes}"
            ).strip()
        transport.updated_at = datetime.now(timezone.utc)

        # Sync donation status
        if new_status == TransportStatus.IN_TRANSIT:
            donation.status = DonationStatus.IN_TRANSIT
            NotificationService.notify_in_transit(donation)
        elif new_status == TransportStatus.DELIVERED:
            # Delivery does NOT auto-confirm receipt; hub admin must confirm
            pass
        elif new_status == TransportStatus.CANCELLED:
            pass

        donation.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action=f"TRANSPORT_{new_status.value}",
            entity_type="Transport",
            entity_id=transport.id,
        )
        log.set_previous_state({"status": prev})
        log.set_new_state({"status": new_status.value})
        db.session.add(log)
        db.session.commit()
        return transport

    @staticmethod
    def get_transport(donation_id: int) -> Transport:
        donation = db.session.get(Donation, donation_id)
        if not donation:
            raise NotFoundError("Donation not found")
        if not donation.transport:
            raise NotFoundError("Transport not found for this donation")
        return donation.transport
