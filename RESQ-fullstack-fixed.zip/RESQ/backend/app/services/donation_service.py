"""Donation lifecycle service."""
from datetime import datetime, timezone

from app.extensions import db
from app.models.user import User, UserRole
from app.models.hub import Hub, HubStatus
from app.models.resource import Resource
from app.models.donation import Donation, DonationStatus
from app.models.inventory import Inventory
from app.models.audit_log import AuditLog
from app.services.capacity_service import CapacityService
from app.services.notification_service import NotificationService
from app.utils.exceptions import (
    NotFoundError,
    ForbiddenError,
    ConflictError,
    ValidationError,
    InsufficientCapacityError,
    InvalidStateTransitionError,
)


class DonationService:
    @staticmethod
    def create_donation(donor: User, data: dict) -> Donation:
        hub = db.session.get(Hub, data["hub_id"])
        if not hub:
            raise NotFoundError("Hub not found")
        if hub.operating_status != HubStatus.ACTIVE:
            raise ConflictError("Selected hub is not active", "HUB_NOT_ACTIVE")

        resource = db.session.get(Resource, data["resource_id"])
        if not resource or not resource.is_active:
            raise NotFoundError("Resource not found or inactive")

        if not hub.accepts_category(resource.category):
            raise ValidationError(
                f"Hub does not accept resource category: {resource.category}"
            )

        quantity = data["quantity"]
        estimated_volume = data.get("estimated_volume")
        if estimated_volume is None:
            estimated_volume = resource.volume_per_unit * quantity

        donation = Donation(
            donor_id=donor.id,
            hub_id=hub.id,
            resource_id=resource.id,
            disaster_id=data.get("disaster_id"),
            quantity=quantity,
            unit=data["unit"],
            condition=data.get("condition", "Good"),
            description=data.get("description"),
            estimated_volume=estimated_volume,
            status=DonationStatus.PENDING_APPROVAL,
            donor_latitude=data.get("donor_latitude"),
            donor_longitude=data.get("donor_longitude"),
            donor_address=data.get("donor_address"),
            pickup_required=data.get("pickup_required", False),
            preferred_delivery_date=data.get("preferred_delivery_date"),
        )
        db.session.add(donation)
        db.session.flush()

        log = AuditLog(
            actor_id=donor.id,
            action="DONATION_CREATED",
            entity_type="Donation",
            entity_id=donation.id,
        )
        log.set_new_state(donation.to_dict())
        db.session.add(log)
        db.session.commit()

        # Notify hub admin
        NotificationService.notify_donation_submitted(donation)
        return donation

    @staticmethod
    def approve_donation(
        donation_id: int, admin: User, admin_notes: str = None
    ) -> Donation:
        donation = db.session.get(Donation, donation_id)
        if not donation:
            raise NotFoundError("Donation not found")

        # Authorization: must manage this hub (or be super admin)
        if admin.role != UserRole.SUPER_ADMIN:
            if admin.role != UserRole.HUB_ADMIN or donation.hub.admin_id != admin.id:
                raise ForbiddenError("You are not authorized to approve this donation")

        if donation.status != DonationStatus.PENDING_APPROVAL:
            raise InvalidStateTransitionError(
                f"Cannot approve donation in status {donation.status.value}"
            )

        # Donor cannot approve own donation
        if donation.donor_id == admin.id:
            raise ForbiddenError("Cannot approve your own donation")

        hub = donation.hub
        volume = donation.estimated_volume

        try:
            CapacityService.reserve_capacity(hub, volume, actor_id=admin.id)
        except InsufficientCapacityError:
            raise

        prev_status = donation.status.value
        donation.status = DonationStatus.APPROVED
        donation.approved_at = datetime.now(timezone.utc)
        donation.admin_notes = admin_notes
        donation.updated_at = datetime.now(timezone.utc)

        # Also move to TRANSPORT_PENDING as next logical step
        donation.status = DonationStatus.TRANSPORT_PENDING

        log = AuditLog(
            actor_id=admin.id,
            action="DONATION_APPROVED",
            entity_type="Donation",
            entity_id=donation.id,
        )
        log.set_previous_state({"status": prev_status})
        log.set_new_state({"status": donation.status.value})
        db.session.add(log)
        db.session.commit()

        NotificationService.notify_donation_approved(donation)
        return donation

    @staticmethod
    def reject_donation(
        donation_id: int, admin: User, rejection_reason: str, admin_notes: str = None
    ) -> Donation:
        donation = db.session.get(Donation, donation_id)
        if not donation:
            raise NotFoundError("Donation not found")

        if admin.role != UserRole.SUPER_ADMIN:
            if admin.role != UserRole.HUB_ADMIN or donation.hub.admin_id != admin.id:
                raise ForbiddenError("You are not authorized to reject this donation")

        if donation.status != DonationStatus.PENDING_APPROVAL:
            raise InvalidStateTransitionError(
                f"Cannot reject donation in status {donation.status.value}"
            )

        prev = donation.status.value
        donation.status = DonationStatus.REJECTED
        donation.rejection_reason = rejection_reason
        donation.admin_notes = admin_notes
        donation.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=admin.id,
            action="DONATION_REJECTED",
            entity_type="Donation",
            entity_id=donation.id,
        )
        log.set_previous_state({"status": prev})
        log.set_new_state({"status": "REJECTED", "reason": rejection_reason})
        db.session.add(log)
        db.session.commit()

        NotificationService.notify_donation_rejected(donation)
        return donation

    @staticmethod
    def cancel_donation(donation_id: int, user: User) -> Donation:
        donation = db.session.get(Donation, donation_id)
        if not donation:
            raise NotFoundError("Donation not found")

        # Donor can cancel own; hub admin / super can cancel
        is_owner = donation.donor_id == user.id
        is_hub_admin = (
            user.role == UserRole.HUB_ADMIN and donation.hub.admin_id == user.id
        )
        is_super = user.role == UserRole.SUPER_ADMIN
        if not (is_owner or is_hub_admin or is_super):
            raise ForbiddenError("Not authorized to cancel this donation")

        if not donation.can_transition_to(DonationStatus.CANCELLED):
            raise InvalidStateTransitionError(
                f"Cannot cancel donation in status {donation.status.value}"
            )

        # Release reservation if was approved
        if donation.status in (
            DonationStatus.APPROVED,
            DonationStatus.TRANSPORT_PENDING,
            DonationStatus.TRANSPORT_ARRANGED,
            DonationStatus.IN_TRANSIT,
        ):
            CapacityService.release_reservation(
                donation.hub, donation.estimated_volume, actor_id=user.id
            )

        prev = donation.status.value
        donation.status = DonationStatus.CANCELLED
        donation.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action="DONATION_CANCELLED",
            entity_type="Donation",
            entity_id=donation.id,
        )
        log.set_previous_state({"status": prev})
        log.set_new_state({"status": "CANCELLED"})
        db.session.add(log)
        db.session.commit()
        return donation

    @staticmethod
    def confirm_receipt(donation_id: int, admin: User) -> Donation:
        """
        Confirm receipt: release reservation, occupy capacity, update inventory.
        All in one transaction.
        """
        donation = db.session.get(Donation, donation_id)
        if not donation:
            raise NotFoundError("Donation not found")

        if admin.role != UserRole.SUPER_ADMIN:
            if admin.role != UserRole.HUB_ADMIN or donation.hub.admin_id != admin.id:
                raise ForbiddenError("Not authorized to confirm receipt for this hub")

        if donation.status == DonationStatus.RECEIVED:
            raise ConflictError("Donation already received", "ALREADY_RECEIVED")

        if donation.status not in (
            DonationStatus.IN_TRANSIT,
            DonationStatus.TRANSPORT_ARRANGED,
            DonationStatus.APPROVED,
            DonationStatus.TRANSPORT_PENDING,
        ):
            raise InvalidStateTransitionError(
                f"Cannot confirm receipt for status {donation.status.value}"
            )

        hub = donation.hub
        resource = donation.resource
        volume = donation.estimated_volume

        # Occupy capacity (releases reservation + adds to occupied)
        CapacityService.occupy_capacity(hub, volume, actor_id=admin.id)

        # Update inventory
        inv = Inventory.query.filter_by(
            hub_id=hub.id, resource_id=resource.id
        ).first()
        if not inv:
            inv = Inventory(
                hub_id=hub.id,
                resource_id=resource.id,
                available_quantity=0.0,
                reserved_quantity=0.0,
                unit=donation.unit,
            )
            db.session.add(inv)
            db.session.flush()

        inv.available_quantity = inv.available_quantity + donation.quantity
        inv.updated_at = datetime.now(timezone.utc)

        prev = donation.status.value
        donation.status = DonationStatus.RECEIVED
        donation.received_at = datetime.now(timezone.utc)
        donation.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=admin.id,
            action="DONATION_RECEIVED",
            entity_type="Donation",
            entity_id=donation.id,
        )
        log.set_previous_state({"status": prev})
        log.set_new_state(
            {
                "status": "RECEIVED",
                "quantity": donation.quantity,
                "volume": volume,
            }
        )
        db.session.add(log)
        db.session.commit()

        NotificationService.notify_donation_received(donation)
        return donation

    @staticmethod
    def get_donation(donation_id: int, user: User = None) -> Donation:
        donation = db.session.get(Donation, donation_id)
        if not donation:
            raise NotFoundError("Donation not found")
        if user:
            # Access control: owner, hub admin, or super
            if (
                user.role != UserRole.SUPER_ADMIN
                and donation.donor_id != user.id
                and not (
                    user.role == UserRole.HUB_ADMIN
                    and donation.hub.admin_id == user.id
                )
            ):
                raise ForbiddenError("Not authorized to view this donation")
        return donation

    @staticmethod
    def list_my_donations(donor: User, status: str = None, page: int = 1, per_page: int = 20):
        q = Donation.query.filter_by(donor_id=donor.id)
        if status:
            try:
                q = q.filter_by(status=DonationStatus[status])
            except KeyError:
                raise ValidationError(f"Invalid status: {status}")
        q = q.order_by(Donation.created_at.desc())
        pagination = q.paginate(page=page, per_page=per_page, error_out=False)
        return pagination
