"""Hub management service."""
from datetime import datetime, timezone

from app.extensions import db
from app.models.user import User, UserRole
from app.models.hub import Hub, HubStatus
from app.models.audit_log import AuditLog
from app.utils.exceptions import NotFoundError, ForbiddenError, ValidationError, ConflictError
from app.utils.distance import validate_coordinates


class HubService:
    @staticmethod
    def create_hub(data: dict, creator: User) -> Hub:
        ok, err = validate_coordinates(data["latitude"], data["longitude"])
        if not ok:
            raise ValidationError(err)

        admin_id = data.get("admin_id") or creator.id
        if creator.role == UserRole.SUPER_ADMIN and data.get("admin_id"):
            admin = db.session.get(User, data["admin_id"])
            if not admin or admin.role not in (UserRole.HUB_ADMIN, UserRole.SUPER_ADMIN):
                raise ValidationError("admin_id must be a HUB_ADMIN or SUPER_ADMIN user")
            admin_id = admin.id
        elif creator.role == UserRole.HUB_ADMIN:
            admin_id = creator.id
        elif creator.role != UserRole.SUPER_ADMIN:
            raise ForbiddenError("Only hub admins or super admins can create hubs")

        hub = Hub(
            name=data["name"],
            description=data.get("description"),
            address=data["address"],
            city=data["city"],
            state=data["state"],
            pincode=data.get("pincode"),
            latitude=data["latitude"],
            longitude=data["longitude"],
            admin_id=admin_id,
            total_storage_capacity=data["total_storage_capacity"],
            reserved_capacity=0.0,
            current_occupied_capacity=0.0,
            contact_phone=data.get("contact_phone"),
            contact_email=data.get("contact_email"),
            operating_status=HubStatus.ACTIVE,
        )
        hub.set_accepted_categories(data["accepted_resource_categories"])
        db.session.add(hub)
        db.session.flush()

        log = AuditLog(
            actor_id=creator.id,
            action="HUB_CREATED",
            entity_type="Hub",
            entity_id=hub.id,
        )
        log.set_new_state(hub.to_dict(include_admin=True))
        db.session.add(log)
        db.session.commit()
        return hub

    @staticmethod
    def update_hub(hub_id: int, data: dict, user: User) -> Hub:
        hub = db.session.get(Hub, hub_id)
        if not hub:
            raise NotFoundError("Hub not found")

        if user.role != UserRole.SUPER_ADMIN and hub.admin_id != user.id:
            raise ForbiddenError("Not authorized to update this hub")

        if "latitude" in data or "longitude" in data:
            lat = data.get("latitude", hub.latitude)
            lon = data.get("longitude", hub.longitude)
            ok, err = validate_coordinates(lat, lon)
            if not ok:
                raise ValidationError(err)

        for field in (
            "name",
            "description",
            "address",
            "city",
            "state",
            "pincode",
            "latitude",
            "longitude",
            "contact_phone",
            "contact_email",
        ):
            if field in data:
                setattr(hub, field, data[field])

        if "total_storage_capacity" in data:
            new_total = data["total_storage_capacity"]
            used = hub.reserved_capacity + hub.current_occupied_capacity
            if new_total < used:
                raise ConflictError(
                    f"Cannot reduce capacity below currently used ({used})",
                    "CAPACITY_TOO_LOW",
                )
            hub.total_storage_capacity = new_total

        if "accepted_resource_categories" in data:
            hub.set_accepted_categories(data["accepted_resource_categories"])

        hub.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action="HUB_UPDATED",
            entity_type="Hub",
            entity_id=hub.id,
        )
        log.set_new_state(hub.to_dict(include_admin=True))
        db.session.add(log)
        db.session.commit()
        return hub

    @staticmethod
    def update_status(hub_id: int, status: str, user: User) -> Hub:
        hub = db.session.get(Hub, hub_id)
        if not hub:
            raise NotFoundError("Hub not found")
        if user.role != UserRole.SUPER_ADMIN and hub.admin_id != user.id:
            raise ForbiddenError("Not authorized")

        try:
            new_status = HubStatus[status]
        except KeyError:
            raise ValidationError(f"Invalid status: {status}")

        prev = hub.operating_status.value
        hub.operating_status = new_status
        hub.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action="HUB_STATUS_CHANGED",
            entity_type="Hub",
            entity_id=hub.id,
        )
        log.set_previous_state({"operating_status": prev})
        log.set_new_state({"operating_status": status})
        db.session.add(log)
        db.session.commit()
        return hub

    @staticmethod
    def get_hub(hub_id: int) -> Hub:
        hub = db.session.get(Hub, hub_id)
        if not hub:
            raise NotFoundError("Hub not found")
        return hub

    @staticmethod
    def list_hubs(
        city: str = None,
        status: str = None,
        page: int = 1,
        per_page: int = 20,
    ):
        q = Hub.query
        if city:
            q = q.filter(Hub.city.ilike(f"%{city}%"))
        if status:
            try:
                q = q.filter(Hub.operating_status == HubStatus[status])
            except KeyError:
                raise ValidationError(f"Invalid status: {status}")
        else:
            # Public listing defaults to active
            q = q.filter(Hub.operating_status == HubStatus.ACTIVE)
        q = q.order_by(Hub.name)
        return q.paginate(page=page, per_page=per_page, error_out=False)
