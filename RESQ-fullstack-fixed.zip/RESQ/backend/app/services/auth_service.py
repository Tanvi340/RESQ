"""Authentication service."""
from datetime import datetime, timezone

from flask_jwt_extended import create_access_token, create_refresh_token, get_jwt

from app.extensions import db
from app.models.user import User, UserRole
from app.models.audit_log import AuditLog
from app.utils.exceptions import (
    ValidationError,
    ConflictError,
    UnauthorizedError,
    NotFoundError,
)
from app.utils.validators import is_valid_email, is_strong_password, is_valid_phone


class AuthService:
    @staticmethod
    def register(
        full_name: str,
        email: str,
        password: str,
        phone_number: str = None,
        role: str = "DONOR",
    ) -> User:
        email = email.strip().lower()
        if not is_valid_email(email):
            raise ValidationError("Invalid email address")
        ok, msg = is_strong_password(password)
        if not ok:
            raise ValidationError(msg)
        if not is_valid_phone(phone_number):
            raise ValidationError("Invalid phone number format")

        # Public registration cannot create SUPER_ADMIN
        if role == "SUPER_ADMIN":
            raise ValidationError("Cannot self-assign SUPER_ADMIN role")
        if role not in ("DONOR", "HUB_ADMIN"):
            raise ValidationError("Invalid role. Allowed: DONOR, HUB_ADMIN")

        existing = User.query.filter_by(email=email).first()
        if existing:
            raise ConflictError("Email already registered", "EMAIL_EXISTS")

        user = User(
            full_name=full_name.strip(),
            email=email,
            phone_number=phone_number,
            role=UserRole[role],
        )
        user.set_password(password)
        db.session.add(user)
        db.session.flush()

        log = AuditLog(
            actor_id=user.id,
            action="USER_REGISTERED",
            entity_type="User",
            entity_id=user.id,
        )
        log.set_new_state({"email": email, "role": role})
        db.session.add(log)
        db.session.commit()
        return user

    @staticmethod
    def login(email: str, password: str) -> dict:
        email = email.strip().lower()
        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            raise UnauthorizedError("Invalid email or password")
        if not user.is_active:
            raise UnauthorizedError("Account is deactivated")

        access_token = create_access_token(identity=str(user.id))
        refresh_token = create_refresh_token(identity=str(user.id))
        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "user": user.to_dict(),
        }

    @staticmethod
    def refresh_token(identity: str) -> dict:
        user = db.session.get(User, int(identity))
        if not user or not user.is_active:
            raise UnauthorizedError("Invalid or inactive user")
        access_token = create_access_token(identity=str(user.id))
        return {"access_token": access_token}

    @staticmethod
    def change_password(user: User, current_password: str, new_password: str) -> None:
        if not user.check_password(current_password):
            raise UnauthorizedError("Current password is incorrect")
        ok, msg = is_strong_password(new_password)
        if not ok:
            raise ValidationError(msg)
        user.set_password(new_password)
        user.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action="PASSWORD_CHANGED",
            entity_type="User",
            entity_id=user.id,
        )
        db.session.add(log)
        db.session.commit()

    @staticmethod
    def get_user_by_id(user_id: int) -> User:
        user = db.session.get(User, user_id)
        if not user:
            raise NotFoundError("User not found")
        return user
