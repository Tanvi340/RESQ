"""Intelligent hub recommendation engine (rule-based)."""
from typing import List, Optional

from app.extensions import db
from app.models.hub import Hub, HubStatus
from app.models.resource import Resource
from app.utils.distance import haversine_distance, validate_coordinates
from app.utils.exceptions import ValidationError
from flask import current_app


class RecommendationService:
    @staticmethod
    def recommend_hubs(
        latitude: float,
        longitude: float,
        radius_km: float = 50.0,
        resource_id: Optional[int] = None,
        resource_category: Optional[str] = None,
        required_capacity: float = 0.0,
        quantity: Optional[float] = None,
    ) -> List[dict]:
        """
        Find and rank nearby hubs that can accept the proposed donation.
        Ranking uses weighted score: distance, capacity, compatibility, status.
        """
        ok, err = validate_coordinates(latitude, longitude)
        if not ok:
            raise ValidationError(err)

        if radius_km <= 0 or radius_km > 500:
            raise ValidationError("radius_km must be between 0.1 and 500")

        # Resolve category and volume
        category = resource_category
        volume_needed = required_capacity

        if resource_id:
            resource = db.session.get(Resource, resource_id)
            if not resource or not resource.is_active:
                raise ValidationError("Invalid or inactive resource")
            category = resource.category
            if quantity and volume_needed <= 0:
                volume_needed = resource.volume_per_unit * quantity

        # Fetch active hubs (we filter by distance in Python for SQLite compatibility)
        hubs = Hub.query.filter(Hub.operating_status == HubStatus.ACTIVE).all()

        results = []
        for hub in hubs:
            dist = haversine_distance(latitude, longitude, hub.latitude, hub.longitude)
            if dist > radius_km:
                continue

            accepts = True
            if category:
                accepts = hub.accepts_category(category)

            can_accept = accepts and hub.can_accept_volume(volume_needed)

            reasons = []
            if dist <= radius_km:
                reasons.append("Within the selected radius")
            if accepts:
                reasons.append("Accepts the requested resource category")
            else:
                reasons.append("Does not accept the requested resource category")
            if hub.available_capacity >= volume_needed:
                reasons.append("Sufficient unreserved storage capacity")
            else:
                reasons.append(
                    f"Insufficient capacity (available: {hub.available_capacity:.1f})"
                )
            if hub.operating_status == HubStatus.ACTIVE:
                reasons.append("Hub is operational")

            # Score (higher is better)
            # Distance score: closer = higher (max 1 at 0 km, 0 at radius)
            dist_score = max(0.0, 1.0 - (dist / radius_km)) if radius_km > 0 else 0
            # Capacity score: more free capacity relative to need
            if volume_needed > 0:
                cap_score = min(1.0, hub.available_capacity / max(volume_needed, 1))
            else:
                cap_score = min(1.0, hub.available_capacity / max(hub.total_storage_capacity, 1))
            compat_score = 1.0 if accepts else 0.0
            status_score = 1.0 if hub.operating_status == HubStatus.ACTIVE else 0.0

            weights = current_app.config
            score = (
                weights.get("REC_WEIGHT_DISTANCE", 0.40) * dist_score
                + weights.get("REC_WEIGHT_CAPACITY", 0.30) * cap_score
                + weights.get("REC_WEIGHT_COMPATIBILITY", 0.20) * compat_score
                + weights.get("REC_WEIGHT_STATUS", 0.10) * status_score
            )

            results.append(
                {
                    "id": hub.id,
                    "hub_id": hub.id,
                    "name": hub.name,
                    "distance_km": round(dist, 2),
                    "address": hub.address,
                    "city": hub.city,
                    "state": hub.state,
                    "latitude": hub.latitude,
                    "longitude": hub.longitude,
                    "available_capacity": round(hub.available_capacity, 2),
                    "total_storage_capacity": hub.total_storage_capacity,
                    "accepted_resource_categories": hub.get_accepted_categories(),
                    "accepts_resource": accepts,
                    "can_accept_donation": can_accept,
                    "operating_status": hub.operating_status.value,
                    "score": round(score, 4),
                    "recommendation_reasons": reasons,
                    "contact_phone": hub.contact_phone,
                }
            )

        # Sort: prefer can_accept first, then by score descending
        results.sort(key=lambda x: (not x["can_accept_donation"], -x["score"]))
        return results
