"""Capacity reservation and management service."""
from app.extensions import db
from app.models.hub import Hub, HubStatus
from app.models.donation import Donation
from app.models.audit_log import AuditLog
from app.utils.exceptions import (
    InsufficientCapacityError,
    ConflictError,
    NotFoundError,
)


class CapacityService:
    @staticmethod
    def reserve_capacity(hub: Hub, volume: float, actor_id: int = None) -> None:
        """
        Atomically reserve capacity on a hub.
        Uses SELECT FOR UPDATE where supported (PostgreSQL).
        For SQLite, relies on transaction + re-check.
        """
        if volume <= 0:
            return

        # Re-fetch with lock if possible
        locked_hub = (
            db.session.query(Hub)
            .filter(Hub.id == hub.id)
            .with_for_update()
            .first()
        )
        if not locked_hub:
            raise NotFoundError("Hub not found")

        available = locked_hub.available_capacity
        if available < volume:
            raise InsufficientCapacityError(
                f"Insufficient capacity. Available: {available:.2f}, required: {volume:.2f}"
            )

        if locked_hub.operating_status != HubStatus.ACTIVE:
            raise ConflictError("Hub is not active", "HUB_NOT_ACTIVE")

        locked_hub.reserved_capacity = locked_hub.reserved_capacity + volume

        # Mark FULL if no more capacity
        if locked_hub.available_capacity <= 0:
            locked_hub.operating_status = HubStatus.FULL

        log = AuditLog(
            actor_id=actor_id,
            action="CAPACITY_RESERVED",
            entity_type="Hub",
            entity_id=locked_hub.id,
        )
        log.set_extra({"volume": volume, "new_reserved": locked_hub.reserved_capacity})
        db.session.add(log)
        # Caller is responsible for commit

    @staticmethod
    def release_reservation(hub: Hub, volume: float, actor_id: int = None) -> None:
        """Release previously reserved capacity."""
        if volume <= 0:
            return

        locked_hub = (
            db.session.query(Hub)
            .filter(Hub.id == hub.id)
            .with_for_update()
            .first()
        )
        if not locked_hub:
            raise NotFoundError("Hub not found")

        locked_hub.reserved_capacity = max(0.0, locked_hub.reserved_capacity - volume)

        # Restore ACTIVE if was FULL and now has space
        if (
            locked_hub.operating_status == HubStatus.FULL
            and locked_hub.available_capacity > 0
        ):
            locked_hub.operating_status = HubStatus.ACTIVE

        log = AuditLog(
            actor_id=actor_id,
            action="CAPACITY_RELEASED",
            entity_type="Hub",
            entity_id=locked_hub.id,
        )
        log.set_extra({"volume": volume, "new_reserved": locked_hub.reserved_capacity})
        db.session.add(log)

    @staticmethod
    def occupy_capacity(hub: Hub, volume: float, actor_id: int = None) -> None:
        """
        Convert reserved capacity to occupied (on receipt).
        Decreases reserved, increases occupied.
        """
        if volume <= 0:
            return

        locked_hub = (
            db.session.query(Hub)
            .filter(Hub.id == hub.id)
            .with_for_update()
            .first()
        )
        if not locked_hub:
            raise NotFoundError("Hub not found")

        # Release reservation and occupy
        locked_hub.reserved_capacity = max(0.0, locked_hub.reserved_capacity - volume)
        locked_hub.current_occupied_capacity = (
            locked_hub.current_occupied_capacity + volume
        )

        if locked_hub.available_capacity <= 0:
            locked_hub.operating_status = HubStatus.FULL
        elif locked_hub.operating_status == HubStatus.FULL:
            locked_hub.operating_status = HubStatus.ACTIVE

        log = AuditLog(
            actor_id=actor_id,
            action="CAPACITY_OCCUPIED",
            entity_type="Hub",
            entity_id=locked_hub.id,
        )
        log.set_extra(
            {
                "volume": volume,
                "new_reserved": locked_hub.reserved_capacity,
                "new_occupied": locked_hub.current_occupied_capacity,
            }
        )
        db.session.add(log)

    @staticmethod
    def get_capacity_summary(hub: Hub) -> dict:
        return {
            "hub_id": hub.id,
            "total_storage_capacity": hub.total_storage_capacity,
            "reserved_capacity": hub.reserved_capacity,
            "current_occupied_capacity": hub.current_occupied_capacity,
            "available_capacity": hub.available_capacity,
            "operating_status": hub.operating_status.value,
            "utilization_percent": round(
                (
                    (hub.reserved_capacity + hub.current_occupied_capacity)
                    / hub.total_storage_capacity
                    * 100
                )
                if hub.total_storage_capacity > 0
                else 0,
                2,
            ),
        }
