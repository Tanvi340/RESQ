"""Notification service – DB storage + logging fallback."""
import logging

from app.extensions import db
from app.models.notification import Notification, NotificationType
from app.models.donation import Donation
from app.models.transport import Transport
from app.models.hub import Hub

logger = logging.getLogger("resq.notifications")


class NotificationService:
    @staticmethod
    def _create(
        user_id: int,
        ntype: NotificationType,
        title: str,
        message: str,
        entity_type: str = None,
        entity_id: int = None,
    ) -> Notification:
        notif = Notification(
            user_id=user_id,
            notification_type=ntype,
            title=title,
            message=message,
            related_entity_type=entity_type,
            related_entity_id=entity_id,
        )
        db.session.add(notif)
        # Caller may commit; we flush so ID is available
        try:
            db.session.flush()
        except Exception:
            pass
        logger.info(
            "Notification [%s] to user %s: %s – %s",
            ntype.value,
            user_id,
            title,
            message,
        )
        return notif

    @staticmethod
    def notify_donation_submitted(donation: Donation) -> None:
        # Notify hub admin
        admin_id = donation.hub.admin_id
        NotificationService._create(
            admin_id,
            NotificationType.DONATION_SUBMITTED,
            "New donation request",
            f"Donation #{donation.id} submitted for hub {donation.hub.name}. "
            f"Quantity: {donation.quantity} {donation.unit}.",
            "Donation",
            donation.id,
        )
        # Notify donor confirmation
        NotificationService._create(
            donation.donor_id,
            NotificationType.DONATION_SUBMITTED,
            "Donation submitted",
            f"Your donation #{donation.id} has been submitted and is pending approval.",
            "Donation",
            donation.id,
        )

    @staticmethod
    def notify_donation_approved(donation: Donation) -> None:
        NotificationService._create(
            donation.donor_id,
            NotificationType.DONATION_APPROVED,
            "Donation approved",
            f"Your donation #{donation.id} has been approved by {donation.hub.name}. "
            "Please arrange transport.",
            "Donation",
            donation.id,
        )

    @staticmethod
    def notify_donation_rejected(donation: Donation) -> None:
        NotificationService._create(
            donation.donor_id,
            NotificationType.DONATION_REJECTED,
            "Donation rejected",
            f"Your donation #{donation.id} was rejected. "
            f"Reason: {donation.rejection_reason or 'Not specified'}.",
            "Donation",
            donation.id,
        )

    @staticmethod
    def notify_transport_scheduled(donation: Donation, transport: Transport) -> None:
        NotificationService._create(
            donation.donor_id,
            NotificationType.TRANSPORT_SCHEDULED,
            "Transport scheduled",
            f"Transport for donation #{donation.id} scheduled at "
            f"{transport.scheduled_at}.",
            "Transport",
            transport.id,
        )
        NotificationService._create(
            donation.hub.admin_id,
            NotificationType.TRANSPORT_SCHEDULED,
            "Transport scheduled",
            f"Transport for donation #{donation.id} scheduled at "
            f"{transport.scheduled_at}.",
            "Transport",
            transport.id,
        )

    @staticmethod
    def notify_in_transit(donation: Donation) -> None:
        NotificationService._create(
            donation.donor_id,
            NotificationType.DONATION_IN_TRANSIT,
            "Donation in transit",
            f"Donation #{donation.id} is now in transit to {donation.hub.name}.",
            "Donation",
            donation.id,
        )
        NotificationService._create(
            donation.hub.admin_id,
            NotificationType.DONATION_IN_TRANSIT,
            "Donation in transit",
            f"Donation #{donation.id} is in transit to your hub.",
            "Donation",
            donation.id,
        )

    @staticmethod
    def notify_donation_received(donation: Donation) -> None:
        NotificationService._create(
            donation.donor_id,
            NotificationType.DONATION_RECEIVED,
            "Donation received",
            f"Your donation #{donation.id} has been received by {donation.hub.name}. "
            "Thank you for your contribution!",
            "Donation",
            donation.id,
        )
