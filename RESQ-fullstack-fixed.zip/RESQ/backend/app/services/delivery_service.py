"""Relief delivery and GPS tracking service."""
from datetime import datetime, timezone, timedelta
from typing import Optional, List

from app.extensions import db
from app.models.user import User, UserRole
from app.models.hub import Hub
from app.models.resource import Resource
from app.models.inventory import Inventory
from app.models.donation import Donation, DonationStatus
from app.models.delivery import (
    Delivery,
    DeliveryItem,
    DeliveryLocation,
    DonationDeliveryAllocation,
    DeliveryStatus,
)
from app.models.audit_log import AuditLog
from app.services.notification_service import NotificationService
from app.utils.exceptions import (
    NotFoundError,
    ForbiddenError,
    ConflictError,
    ValidationError,
    InvalidStateTransitionError,
)
from app.utils.distance import validate_coordinates


class DeliveryService:
    STALE_THRESHOLD_SECONDS = 60

    @staticmethod
    def create_delivery(admin: User, data: dict) -> Delivery:
        hub = db.session.get(Hub, data["source_hub_id"])
        if not hub:
            raise NotFoundError("Source hub not found")
        if admin.role != UserRole.SUPER_ADMIN and hub.admin_id != admin.id:
            raise ForbiddenError("Not authorized for this hub")

        ok, err = validate_coordinates(
            data["destination_latitude"], data["destination_longitude"]
        )
        if not ok:
            raise ValidationError(err)

        items_data = data.get("items") or []
        if not items_data:
            raise ValidationError("At least one delivery item is required")

        # Validate inventory availability
        for item in items_data:
            inv = Inventory.query.filter_by(
                hub_id=hub.id, resource_id=item["resource_id"]
            ).first()
            if not inv or inv.available_quantity < item["quantity"]:
                res = db.session.get(Resource, item["resource_id"])
                name = res.name if res else item["resource_id"]
                avail = inv.available_quantity if inv else 0
                raise ConflictError(
                    f"Insufficient inventory for {name}: available {avail}, requested {item['quantity']}",
                    "INSUFFICIENT_INVENTORY",
                )

        agent_id = data.get("assigned_agent_id")
        if agent_id:
            agent = db.session.get(User, agent_id)
            if not agent or agent.role != UserRole.DELIVERY_AGENT or not agent.is_active:
                raise ValidationError("Invalid or inactive delivery agent")

        status = DeliveryStatus.ASSIGNED if agent_id else DeliveryStatus.PLANNED

        delivery = Delivery(
            source_hub_id=hub.id,
            disaster_id=data.get("disaster_id"),
            destination_name=data["destination_name"],
            destination_address=data.get("destination_address"),
            destination_latitude=data["destination_latitude"],
            destination_longitude=data["destination_longitude"],
            assigned_agent_id=agent_id,
            status=status,
            notes=data.get("notes"),
            created_by=admin.id,
        )
        db.session.add(delivery)
        db.session.flush()

        for item in items_data:
            resource = db.session.get(Resource, item["resource_id"])
            di = DeliveryItem(
                delivery_id=delivery.id,
                resource_id=item["resource_id"],
                quantity=item["quantity"],
                unit=item.get("unit") or (resource.default_unit if resource else "units"),
            )
            db.session.add(di)

            # Reserve inventory (available → reserved)
            inv = Inventory.query.filter_by(
                hub_id=hub.id, resource_id=item["resource_id"]
            ).with_for_update().first()
            inv.available_quantity -= item["quantity"]
            inv.reserved_quantity += item["quantity"]

        # Optional donation allocations
        for alloc in data.get("allocations") or []:
            donation = db.session.get(Donation, alloc["donation_id"])
            if not donation or donation.status != DonationStatus.RECEIVED:
                raise ValidationError(
                    f"Donation {alloc['donation_id']} is not eligible for allocation"
                )
            da = DonationDeliveryAllocation(
                donation_id=alloc["donation_id"],
                delivery_id=delivery.id,
                resource_id=alloc["resource_id"],
                allocated_quantity=alloc["allocated_quantity"],
            )
            db.session.add(da)

        log = AuditLog(
            actor_id=admin.id,
            action="DELIVERY_CREATED",
            entity_type="Delivery",
            entity_id=delivery.id,
        )
        log.set_new_state(delivery.to_dict())
        db.session.add(log)
        db.session.commit()
        return delivery

    @staticmethod
    def assign_agent(delivery_id: int, agent_id: int, admin: User) -> Delivery:
        delivery = db.session.get(Delivery, delivery_id)
        if not delivery:
            raise NotFoundError("Delivery not found")
        DeliveryService._assert_hub_admin(delivery, admin)

        agent = db.session.get(User, agent_id)
        if not agent or agent.role != UserRole.DELIVERY_AGENT or not agent.is_active:
            raise ValidationError("Invalid delivery agent")

        if delivery.status not in (
            DeliveryStatus.PLANNED,
            DeliveryStatus.ASSIGNED,
        ):
            raise InvalidStateTransitionError(
                f"Cannot assign agent in status {delivery.status.value}"
            )

        delivery.assigned_agent_id = agent_id
        delivery.status = DeliveryStatus.ASSIGNED
        delivery.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        return delivery

    @staticmethod
    def dispatch(delivery_id: int, user: User) -> Delivery:
        delivery = db.session.get(Delivery, delivery_id)
        if not delivery:
            raise NotFoundError("Delivery not found")

        is_admin = (
            user.role == UserRole.SUPER_ADMIN
            or (
                user.role == UserRole.HUB_ADMIN
                and delivery.source_hub.admin_id == user.id
            )
        )
        is_agent = (
            user.role == UserRole.DELIVERY_AGENT
            and delivery.assigned_agent_id == user.id
        )
        if not (is_admin or is_agent):
            raise ForbiddenError("Not authorized to dispatch this delivery")

        if not delivery.can_transition_to(DeliveryStatus.IN_TRANSIT):
            raise InvalidStateTransitionError(
                f"Cannot dispatch from {delivery.status.value}"
            )
        if not delivery.assigned_agent_id:
            raise ConflictError("No agent assigned", "NO_AGENT")

        # Deduct reserved inventory
        for item in delivery.items:
            inv = Inventory.query.filter_by(
                hub_id=delivery.source_hub_id, resource_id=item.resource_id
            ).with_for_update().first()
            if inv:
                inv.reserved_quantity = max(0.0, inv.reserved_quantity - item.quantity)

        delivery.status = DeliveryStatus.IN_TRANSIT
        delivery.dispatched_at = datetime.now(timezone.utc)
        delivery.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action="DELIVERY_DISPATCHED",
            entity_type="Delivery",
            entity_id=delivery.id,
        )
        db.session.add(log)
        db.session.commit()
        return delivery

    @staticmethod
    def mark_arrived(delivery_id: int, user: User) -> Delivery:
        delivery = db.session.get(Delivery, delivery_id)
        if not delivery:
            raise NotFoundError("Delivery not found")
        DeliveryService._assert_agent_or_admin(delivery, user)

        if not delivery.can_transition_to(DeliveryStatus.ARRIVED):
            raise InvalidStateTransitionError(
                f"Cannot mark arrived from {delivery.status.value}"
            )

        delivery.status = DeliveryStatus.ARRIVED
        delivery.arrived_at = datetime.now(timezone.utc)
        delivery.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        return delivery

    @staticmethod
    def complete(delivery_id: int, user: User) -> Delivery:
        delivery = db.session.get(Delivery, delivery_id)
        if not delivery:
            raise NotFoundError("Delivery not found")
        DeliveryService._assert_agent_or_admin(delivery, user)

        if not delivery.can_transition_to(DeliveryStatus.COMPLETED):
            # Allow complete from IN_TRANSIT as well for demo flexibility
            if delivery.status != DeliveryStatus.IN_TRANSIT:
                raise InvalidStateTransitionError(
                    f"Cannot complete from {delivery.status.value}"
                )

        delivery.status = DeliveryStatus.COMPLETED
        delivery.completed_at = datetime.now(timezone.utc)
        if not delivery.arrived_at:
            delivery.arrived_at = delivery.completed_at
        delivery.updated_at = datetime.now(timezone.utc)

        log = AuditLog(
            actor_id=user.id,
            action="DELIVERY_COMPLETED",
            entity_type="Delivery",
            entity_id=delivery.id,
        )
        db.session.add(log)
        db.session.commit()
        return delivery

    @staticmethod
    def cancel(delivery_id: int, user: User) -> Delivery:
        delivery = db.session.get(Delivery, delivery_id)
        if not delivery:
            raise NotFoundError("Delivery not found")
        DeliveryService._assert_hub_admin(delivery, user)

        if not delivery.can_transition_to(DeliveryStatus.CANCELLED):
            raise InvalidStateTransitionError(
                f"Cannot cancel from {delivery.status.value}"
            )

        # Release reserved inventory if not yet dispatched
        if delivery.status in (
            DeliveryStatus.PLANNED,
            DeliveryStatus.ASSIGNED,
            DeliveryStatus.READY_FOR_DISPATCH,
        ):
            for item in delivery.items:
                inv = Inventory.query.filter_by(
                    hub_id=delivery.source_hub_id, resource_id=item.resource_id
                ).with_for_update().first()
                if inv:
                    inv.reserved_quantity = max(0.0, inv.reserved_quantity - item.quantity)
                    inv.available_quantity += item.quantity

        delivery.status = DeliveryStatus.CANCELLED
        delivery.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        return delivery

    @staticmethod
    def submit_location(
        delivery_id: int,
        agent: User,
        latitude: float,
        longitude: float,
        accuracy_m: float = None,
        recorded_at: datetime = None,
        is_simulated: bool = False,
    ) -> DeliveryLocation:
        delivery = db.session.get(Delivery, delivery_id)
        if not delivery:
            raise NotFoundError("Delivery not found")

        if agent.role == UserRole.SUPER_ADMIN:
            pass
        elif agent.role == UserRole.DELIVERY_AGENT:
            if delivery.assigned_agent_id != agent.id:
                raise ForbiddenError("You are not assigned to this delivery")
        elif agent.role == UserRole.HUB_ADMIN:
            if delivery.source_hub.admin_id != agent.id:
                raise ForbiddenError("Not authorized")
        else:
            raise ForbiddenError("Only assigned agents can submit locations")

        if delivery.status not in (
            DeliveryStatus.IN_TRANSIT,
            DeliveryStatus.ASSIGNED,
            DeliveryStatus.READY_FOR_DISPATCH,
            DeliveryStatus.ARRIVED,
        ):
            raise ConflictError(
                f"Cannot track delivery in status {delivery.status.value}",
                "TRACKING_NOT_ALLOWED",
            )

        ok, err = validate_coordinates(latitude, longitude)
        if not ok:
            raise ValidationError(err)

        if recorded_at is None:
            recorded_at = datetime.now(timezone.utc)

        loc = DeliveryLocation(
            delivery_id=delivery.id,
            agent_id=agent.id,
            latitude=latitude,
            longitude=longitude,
            accuracy_m=accuracy_m,
            recorded_at=recorded_at,
            is_simulated=is_simulated,
        )
        db.session.add(loc)

        delivery.last_latitude = latitude
        delivery.last_longitude = longitude
        delivery.last_location_at = recorded_at
        delivery.last_accuracy_m = accuracy_m
        delivery.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        return loc

    @staticmethod
    def get_latest_location(delivery_id: int, user: User) -> dict:
        delivery = DeliveryService.get_delivery(delivery_id, user)
        freshness = "LOCATION_UNAVAILABLE"
        age_seconds = None
        if delivery.last_location_at:
            age = datetime.now(timezone.utc) - delivery.last_location_at.replace(
                tzinfo=timezone.utc
            )
            age_seconds = int(age.total_seconds())
            if age_seconds <= DeliveryService.STALE_THRESHOLD_SECONDS:
                freshness = "LIVE"
            else:
                freshness = "STALE"
        if delivery.status == DeliveryStatus.COMPLETED:
            freshness = "COMPLETED"

        return {
            "delivery_id": delivery.id,
            "latitude": delivery.last_latitude,
            "longitude": delivery.last_longitude,
            "accuracy_m": delivery.last_accuracy_m,
            "recorded_at": (
                delivery.last_location_at.isoformat()
                if delivery.last_location_at
                else None
            ),
            "freshness": freshness,
            "age_seconds": age_seconds,
            "status": delivery.status.value,
        }

    @staticmethod
    def get_location_history(
        delivery_id: int, user: User, limit: int = 100
    ) -> List[dict]:
        delivery = DeliveryService.get_delivery(delivery_id, user)
        locs = (
            DeliveryLocation.query.filter_by(delivery_id=delivery.id)
            .order_by(DeliveryLocation.recorded_at.asc())
            .limit(limit)
            .all()
        )
        return [l.to_dict() for l in locs]

    @staticmethod
    def get_delivery(delivery_id: int, user: User) -> Delivery:
        delivery = db.session.get(Delivery, delivery_id)
        if not delivery:
            raise NotFoundError("Delivery not found")

        if user.role == UserRole.SUPER_ADMIN:
            return delivery
        if user.role == UserRole.HUB_ADMIN and delivery.source_hub.admin_id == user.id:
            return delivery
        if user.role == UserRole.DELIVERY_AGENT and delivery.assigned_agent_id == user.id:
            return delivery
        if user.role == UserRole.DONOR:
            # Donor can see if their donation is allocated
            alloc = DonationDeliveryAllocation.query.filter_by(
                delivery_id=delivery.id
            ).join(Donation).filter(Donation.donor_id == user.id).first()
            if alloc:
                return delivery
            raise ForbiddenError("Not authorized to view this delivery")
        raise ForbiddenError("Not authorized")

    @staticmethod
    def list_deliveries(user: User, status: str = None, page: int = 1, per_page: int = 20):
        q = Delivery.query
        if user.role == UserRole.HUB_ADMIN:
            from app.models.hub import Hub
            hub_ids = [h.id for h in Hub.query.filter_by(admin_id=user.id).all()]
            q = q.filter(Delivery.source_hub_id.in_(hub_ids))
        elif user.role == UserRole.DELIVERY_AGENT:
            q = q.filter_by(assigned_agent_id=user.id)
        elif user.role == UserRole.DONOR:
            from app.models.donation import Donation
            delivery_ids = [
                a.delivery_id
                for a in DonationDeliveryAllocation.query.join(Donation)
                .filter(Donation.donor_id == user.id)
                .all()
            ]
            q = q.filter(Delivery.id.in_(delivery_ids or [-1]))
        # SUPER_ADMIN sees all

        if status:
            try:
                q = q.filter_by(status=DeliveryStatus[status])
            except KeyError:
                raise ValidationError(f"Invalid status: {status}")

        q = q.order_by(Delivery.created_at.desc())
        return q.paginate(page=page, per_page=per_page, error_out=False)

    @staticmethod
    def _assert_hub_admin(delivery: Delivery, user: User):
        if user.role == UserRole.SUPER_ADMIN:
            return
        if user.role != UserRole.HUB_ADMIN or delivery.source_hub.admin_id != user.id:
            raise ForbiddenError("Not authorized for this hub")

    @staticmethod
    def _assert_agent_or_admin(delivery: Delivery, user: User):
        if user.role == UserRole.SUPER_ADMIN:
            return
        if user.role == UserRole.DELIVERY_AGENT and delivery.assigned_agent_id == user.id:
            return
        if user.role == UserRole.HUB_ADMIN and delivery.source_hub.admin_id == user.id:
            return
        raise ForbiddenError("Not authorized")
