"""Donation model."""
from datetime import datetime, timezone
import enum

from app.extensions import db


class DonationStatus(enum.Enum):
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    TRANSPORT_PENDING = "TRANSPORT_PENDING"
    TRANSPORT_ARRANGED = "TRANSPORT_ARRANGED"
    IN_TRANSIT = "IN_TRANSIT"
    RECEIVED = "RECEIVED"
    CANCELLED = "CANCELLED"


# Valid state transitions
DONATION_TRANSITIONS = {
    DonationStatus.PENDING_APPROVAL: {
        DonationStatus.APPROVED,
        DonationStatus.REJECTED,
        DonationStatus.CANCELLED,
    },
    DonationStatus.APPROVED: {
        DonationStatus.TRANSPORT_PENDING,
        DonationStatus.TRANSPORT_ARRANGED,
        DonationStatus.CANCELLED,
    },
    DonationStatus.REJECTED: set(),  # terminal
    DonationStatus.TRANSPORT_PENDING: {
        DonationStatus.TRANSPORT_ARRANGED,
        DonationStatus.CANCELLED,
    },
    DonationStatus.TRANSPORT_ARRANGED: {
        DonationStatus.IN_TRANSIT,
        DonationStatus.CANCELLED,
    },
    DonationStatus.IN_TRANSIT: {
        DonationStatus.RECEIVED,
        DonationStatus.CANCELLED,
    },
    DonationStatus.RECEIVED: set(),  # terminal
    DonationStatus.CANCELLED: set(),  # terminal
}


class Donation(db.Model):
    __tablename__ = "donations"

    id = db.Column(db.Integer, primary_key=True)
    donor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    hub_id = db.Column(db.Integer, db.ForeignKey("hubs.id"), nullable=False, index=True)
    resource_id = db.Column(
        db.Integer, db.ForeignKey("resources.id"), nullable=False, index=True
    )
    disaster_id = db.Column(
        db.Integer, db.ForeignKey("disasters.id"), nullable=True, index=True
    )

    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(50), nullable=False)
    condition = db.Column(db.String(100), nullable=True, default="Good")
    description = db.Column(db.Text, nullable=True)

    # Estimated storage volume in liters for capacity reservation
    estimated_volume = db.Column(db.Float, nullable=False, default=0.0)

    status = db.Column(
        db.Enum(DonationStatus),
        nullable=False,
        default=DonationStatus.PENDING_APPROVAL,
        index=True,
    )

    donor_latitude = db.Column(db.Float, nullable=True)
    donor_longitude = db.Column(db.Float, nullable=True)
    donor_address = db.Column(db.String(500), nullable=True)
    pickup_required = db.Column(db.Boolean, default=False, nullable=False)
    preferred_delivery_date = db.Column(db.DateTime, nullable=True)

    admin_notes = db.Column(db.Text, nullable=True)
    rejection_reason = db.Column(db.Text, nullable=True)

    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
    approved_at = db.Column(db.DateTime, nullable=True)
    received_at = db.Column(db.DateTime, nullable=True)

    # Relationships
    donor = db.relationship("User", back_populates="donations")
    hub = db.relationship("Hub", back_populates="donations")
    resource = db.relationship("Resource", back_populates="donations")
    disaster = db.relationship("Disaster", back_populates="donations")
    transport = db.relationship(
        "Transport",
        back_populates="donation",
        uselist=False,
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        db.CheckConstraint("quantity > 0", name="ck_donation_quantity_positive"),
        db.CheckConstraint("estimated_volume >= 0", name="ck_donation_volume_nonneg"),
    )

    def can_transition_to(self, new_status: DonationStatus) -> bool:
        allowed = DONATION_TRANSITIONS.get(self.status, set())
        return new_status in allowed

    def to_dict(self, include_relations: bool = False) -> dict:
        data = {
            "id": self.id,
            "donor_id": self.donor_id,
            "hub_id": self.hub_id,
            "resource_id": self.resource_id,
            "disaster_id": self.disaster_id,
            "quantity": self.quantity,
            "unit": self.unit,
            "condition": self.condition,
            "description": self.description,
            "estimated_volume": self.estimated_volume,
            "status": self.status.value,
            "donor_latitude": self.donor_latitude,
            "donor_longitude": self.donor_longitude,
            "donor_address": self.donor_address,
            "pickup_required": self.pickup_required,
            "preferred_delivery_date": (
                self.preferred_delivery_date.isoformat()
                if self.preferred_delivery_date
                else None
            ),
            "admin_notes": self.admin_notes,
            "rejection_reason": self.rejection_reason,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "approved_at": self.approved_at.isoformat() if self.approved_at else None,
            "received_at": self.received_at.isoformat() if self.received_at else None,
        }
        if include_relations:
            if self.resource:
                data["resource"] = self.resource.to_dict()
            if self.hub:
                data["hub"] = {
                    "id": self.hub.id,
                    "name": self.hub.name,
                    "address": self.hub.address,
                    "city": self.hub.city,
                }
            if self.donor:
                data["donor"] = {
                    "id": self.donor.id,
                    "full_name": self.donor.full_name,
                    "email": self.donor.email,
                }
            if self.transport:
                data["transport"] = self.transport.to_dict()
        return data

    def __repr__(self) -> str:
        return f"<Donation {self.id} status={self.status.value}>"
