"""Relief delivery models (hub → disaster-affected area)."""
from datetime import datetime, timezone
import enum

from app.extensions import db


class DeliveryStatus(enum.Enum):
    PLANNED = "PLANNED"
    ASSIGNED = "ASSIGNED"
    READY_FOR_DISPATCH = "READY_FOR_DISPATCH"
    IN_TRANSIT = "IN_TRANSIT"
    ARRIVED = "ARRIVED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


DELIVERY_TRANSITIONS = {
    DeliveryStatus.PLANNED: {DeliveryStatus.ASSIGNED, DeliveryStatus.CANCELLED},
    DeliveryStatus.ASSIGNED: {
        DeliveryStatus.READY_FOR_DISPATCH,
        DeliveryStatus.IN_TRANSIT,
        DeliveryStatus.CANCELLED,
    },
    DeliveryStatus.READY_FOR_DISPATCH: {
        DeliveryStatus.IN_TRANSIT,
        DeliveryStatus.CANCELLED,
    },
    DeliveryStatus.IN_TRANSIT: {
        DeliveryStatus.ARRIVED,
        DeliveryStatus.CANCELLED,
    },
    DeliveryStatus.ARRIVED: {DeliveryStatus.COMPLETED, DeliveryStatus.CANCELLED},
    DeliveryStatus.COMPLETED: set(),
    DeliveryStatus.CANCELLED: set(),
}


class Delivery(db.Model):
    __tablename__ = "deliveries"

    id = db.Column(db.Integer, primary_key=True)
    source_hub_id = db.Column(db.Integer, db.ForeignKey("hubs.id"), nullable=False, index=True)
    disaster_id = db.Column(db.Integer, db.ForeignKey("disasters.id"), nullable=True, index=True)
    destination_name = db.Column(db.String(255), nullable=False)
    destination_address = db.Column(db.String(500), nullable=True)
    destination_latitude = db.Column(db.Float, nullable=False)
    destination_longitude = db.Column(db.Float, nullable=False)
    assigned_agent_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    status = db.Column(
        db.Enum(DeliveryStatus),
        nullable=False,
        default=DeliveryStatus.PLANNED,
        index=True,
    )
    notes = db.Column(db.Text, nullable=True)
    dispatched_at = db.Column(db.DateTime, nullable=True)
    arrived_at = db.Column(db.DateTime, nullable=True)
    completed_at = db.Column(db.DateTime, nullable=True)
    created_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    # Latest known location (denormalized for fast reads)
    last_latitude = db.Column(db.Float, nullable=True)
    last_longitude = db.Column(db.Float, nullable=True)
    last_location_at = db.Column(db.DateTime, nullable=True)
    last_accuracy_m = db.Column(db.Float, nullable=True)
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    source_hub = db.relationship("Hub", foreign_keys=[source_hub_id])
    disaster = db.relationship("Disaster", foreign_keys=[disaster_id])
    assigned_agent = db.relationship("User", foreign_keys=[assigned_agent_id])
    creator = db.relationship("User", foreign_keys=[created_by])
    items = db.relationship(
        "DeliveryItem", back_populates="delivery", cascade="all, delete-orphan", lazy="joined"
    )
    locations = db.relationship(
        "DeliveryLocation",
        back_populates="delivery",
        cascade="all, delete-orphan",
        lazy="dynamic",
        order_by="DeliveryLocation.recorded_at",
    )
    allocations = db.relationship(
        "DonationDeliveryAllocation",
        back_populates="delivery",
        cascade="all, delete-orphan",
        lazy="dynamic",
    )

    def can_transition_to(self, new_status: DeliveryStatus) -> bool:
        return new_status in DELIVERY_TRANSITIONS.get(self.status, set())

    def to_dict(self, include_items: bool = True, include_agent: bool = True) -> dict:
        data = {
            "id": self.id,
            "source_hub_id": self.source_hub_id,
            "disaster_id": self.disaster_id,
            "destination_name": self.destination_name,
            "destination_address": self.destination_address,
            "destination_latitude": self.destination_latitude,
            "destination_longitude": self.destination_longitude,
            "assigned_agent_id": self.assigned_agent_id,
            "status": self.status.value,
            "notes": self.notes,
            "dispatched_at": self.dispatched_at.isoformat() if self.dispatched_at else None,
            "arrived_at": self.arrived_at.isoformat() if self.arrived_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "created_by": self.created_by,
            "last_latitude": self.last_latitude,
            "last_longitude": self.last_longitude,
            "last_location_at": self.last_location_at.isoformat() if self.last_location_at else None,
            "last_accuracy_m": self.last_accuracy_m,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
        if self.source_hub:
            data["source_hub"] = {
                "id": self.source_hub.id,
                "name": self.source_hub.name,
                "latitude": self.source_hub.latitude,
                "longitude": self.source_hub.longitude,
                "address": self.source_hub.address,
            }
        if self.disaster:
            data["disaster"] = {
                "id": self.disaster.id,
                "title": self.disaster.title,
                "disaster_type": self.disaster.disaster_type.value,
            }
        if include_agent and self.assigned_agent:
            data["assigned_agent"] = {
                "id": self.assigned_agent.id,
                "full_name": self.assigned_agent.full_name,
                "phone_number": self.assigned_agent.phone_number,
            }
        if include_items:
            data["items"] = [i.to_dict() for i in self.items]
        return data

    def __repr__(self) -> str:
        return f"<Delivery {self.id} status={self.status.value}>"


class DeliveryItem(db.Model):
    __tablename__ = "delivery_items"

    id = db.Column(db.Integer, primary_key=True)
    delivery_id = db.Column(db.Integer, db.ForeignKey("deliveries.id"), nullable=False, index=True)
    resource_id = db.Column(db.Integer, db.ForeignKey("resources.id"), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(50), nullable=False)
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )

    delivery = db.relationship("Delivery", back_populates="items")
    resource = db.relationship("Resource")

    __table_args__ = (
        db.CheckConstraint("quantity > 0", name="ck_delivery_item_qty_positive"),
    )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "delivery_id": self.delivery_id,
            "resource_id": self.resource_id,
            "quantity": self.quantity,
            "unit": self.unit,
            "resource": self.resource.to_dict() if self.resource else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class DonationDeliveryAllocation(db.Model):
    """Links donor contributions to relief deliveries."""
    __tablename__ = "donation_delivery_allocations"

    id = db.Column(db.Integer, primary_key=True)
    donation_id = db.Column(db.Integer, db.ForeignKey("donations.id"), nullable=False, index=True)
    delivery_id = db.Column(db.Integer, db.ForeignKey("deliveries.id"), nullable=False, index=True)
    resource_id = db.Column(db.Integer, db.ForeignKey("resources.id"), nullable=False)
    allocated_quantity = db.Column(db.Float, nullable=False)
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )

    donation = db.relationship("Donation")
    delivery = db.relationship("Delivery", back_populates="allocations")
    resource = db.relationship("Resource")

    __table_args__ = (
        db.CheckConstraint("allocated_quantity > 0", name="ck_allocation_qty_positive"),
    )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "donation_id": self.donation_id,
            "delivery_id": self.delivery_id,
            "resource_id": self.resource_id,
            "allocated_quantity": self.allocated_quantity,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class DeliveryLocation(db.Model):
    """GPS location history for a delivery."""
    __tablename__ = "delivery_locations"

    id = db.Column(db.Integer, primary_key=True)
    delivery_id = db.Column(db.Integer, db.ForeignKey("deliveries.id"), nullable=False, index=True)
    agent_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    accuracy_m = db.Column(db.Float, nullable=True)
    recorded_at = db.Column(db.DateTime, nullable=False, index=True)
    received_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    is_simulated = db.Column(db.Boolean, default=False, nullable=False)

    delivery = db.relationship("Delivery", back_populates="locations")
    agent = db.relationship("User")

    __table_args__ = (
        db.Index("ix_delivery_locations_delivery_recorded", "delivery_id", "recorded_at"),
        db.CheckConstraint("latitude >= -90 AND latitude <= 90", name="ck_loc_lat"),
        db.CheckConstraint("longitude >= -180 AND longitude <= 180", name="ck_loc_lon"),
    )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "delivery_id": self.delivery_id,
            "agent_id": self.agent_id,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "accuracy_m": self.accuracy_m,
            "recorded_at": self.recorded_at.isoformat() if self.recorded_at else None,
            "received_at": self.received_at.isoformat() if self.received_at else None,
            "is_simulated": self.is_simulated,
        }
