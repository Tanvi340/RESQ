"""Hub model."""
from datetime import datetime, timezone
import enum
import json

from app.extensions import db


class HubStatus(enum.Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    FULL = "FULL"


class Hub(db.Model):
    __tablename__ = "hubs"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    address = db.Column(db.String(500), nullable=False)
    city = db.Column(db.String(100), nullable=False, index=True)
    state = db.Column(db.String(100), nullable=False)
    pincode = db.Column(db.String(20), nullable=True)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)

    # Capacity in liters (normalized volume unit)
    total_storage_capacity = db.Column(db.Float, nullable=False, default=0.0)
    reserved_capacity = db.Column(db.Float, nullable=False, default=0.0)
    current_occupied_capacity = db.Column(db.Float, nullable=False, default=0.0)

    # JSON list of accepted category names
    accepted_resource_categories = db.Column(db.Text, nullable=False, default="[]")

    operating_status = db.Column(
        db.Enum(HubStatus), nullable=False, default=HubStatus.ACTIVE, index=True
    )
    contact_phone = db.Column(db.String(20), nullable=True)
    contact_email = db.Column(db.String(255), nullable=True)

    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Relationships
    admin = db.relationship("User", back_populates="hubs")
    donations = db.relationship("Donation", back_populates="hub", lazy="dynamic")
    inventory_items = db.relationship(
        "Inventory", back_populates="hub", lazy="dynamic", cascade="all, delete-orphan"
    )

    __table_args__ = (
        db.CheckConstraint(
            "total_storage_capacity >= 0", name="ck_hub_total_capacity_nonneg"
        ),
        db.CheckConstraint(
            "reserved_capacity >= 0", name="ck_hub_reserved_capacity_nonneg"
        ),
        db.CheckConstraint(
            "current_occupied_capacity >= 0", name="ck_hub_occupied_capacity_nonneg"
        ),
        db.CheckConstraint(
            "reserved_capacity + current_occupied_capacity <= total_storage_capacity",
            name="ck_hub_capacity_not_exceed",
        ),
        db.Index("ix_hubs_location", "latitude", "longitude"),
    )

    @property
    def available_capacity(self) -> float:
        """Unreserved physical capacity available for new approvals."""
        return max(
            0.0,
            self.total_storage_capacity
            - self.reserved_capacity
            - self.current_occupied_capacity,
        )

    def get_accepted_categories(self) -> list:
        try:
            return json.loads(self.accepted_resource_categories or "[]")
        except (json.JSONDecodeError, TypeError):
            return []

    def set_accepted_categories(self, categories: list) -> None:
        self.accepted_resource_categories = json.dumps(categories)

    def accepts_category(self, category: str) -> bool:
        cats = self.get_accepted_categories()
        return category in cats or "Other Essentials" in cats

    def can_accept_volume(self, volume: float) -> bool:
        return (
            self.operating_status == HubStatus.ACTIVE
            and self.available_capacity >= volume
        )

    def to_dict(self, include_admin: bool = False, distance_km: float = None) -> dict:
        data = {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "address": self.address,
            "city": self.city,
            "state": self.state,
            "pincode": self.pincode,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "total_storage_capacity": self.total_storage_capacity,
            "reserved_capacity": self.reserved_capacity,
            "current_occupied_capacity": self.current_occupied_capacity,
            "available_capacity": self.available_capacity,
            "accepted_resource_categories": self.get_accepted_categories(),
            "operating_status": self.operating_status.value,
            "contact_phone": self.contact_phone,
            "contact_email": self.contact_email,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
        if distance_km is not None:
            data["distance_km"] = round(distance_km, 2)
        if include_admin:
            data["admin_id"] = self.admin_id
            if self.admin:
                data["admin_name"] = self.admin.full_name
        return data

    def __repr__(self) -> str:
        return f"<Hub {self.name} ({self.operating_status.value})>"
