"""Transport model."""
from datetime import datetime, timezone
import enum

from app.extensions import db


class TransportResponsibleParty(enum.Enum):
    DONOR = "DONOR"
    HUB_ADMIN = "HUB_ADMIN"


class TransportStatus(enum.Enum):
    NOT_ARRANGED = "NOT_ARRANGED"
    SCHEDULED = "SCHEDULED"
    PICKED_UP = "PICKED_UP"
    IN_TRANSIT = "IN_TRANSIT"
    DELIVERED = "DELIVERED"
    CANCELLED = "CANCELLED"


TRANSPORT_TRANSITIONS = {
    TransportStatus.NOT_ARRANGED: {
        TransportStatus.SCHEDULED,
        TransportStatus.CANCELLED,
    },
    TransportStatus.SCHEDULED: {
        TransportStatus.PICKED_UP,
        TransportStatus.CANCELLED,
    },
    TransportStatus.PICKED_UP: {
        TransportStatus.IN_TRANSIT,
        TransportStatus.CANCELLED,
    },
    TransportStatus.IN_TRANSIT: {
        TransportStatus.DELIVERED,
        TransportStatus.CANCELLED,
    },
    TransportStatus.DELIVERED: set(),
    TransportStatus.CANCELLED: set(),
}


class Transport(db.Model):
    __tablename__ = "transports"

    id = db.Column(db.Integer, primary_key=True)
    donation_id = db.Column(
        db.Integer, db.ForeignKey("donations.id"), unique=True, nullable=False, index=True
    )
    responsible_party = db.Column(
        db.Enum(TransportResponsibleParty), nullable=False
    )
    transport_method = db.Column(db.String(100), nullable=True)
    pickup_address = db.Column(db.String(500), nullable=True)
    destination_address = db.Column(db.String(500), nullable=True)
    scheduled_at = db.Column(db.DateTime, nullable=True)
    status = db.Column(
        db.Enum(TransportStatus),
        nullable=False,
        default=TransportStatus.NOT_ARRANGED,
        index=True,
    )
    tracking_notes = db.Column(db.Text, nullable=True)

    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Relationships
    donation = db.relationship("Donation", back_populates="transport")

    def can_transition_to(self, new_status: TransportStatus) -> bool:
        allowed = TRANSPORT_TRANSITIONS.get(self.status, set())
        return new_status in allowed

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "donation_id": self.donation_id,
            "responsible_party": self.responsible_party.value,
            "transport_method": self.transport_method,
            "pickup_address": self.pickup_address,
            "destination_address": self.destination_address,
            "scheduled_at": (
                self.scheduled_at.isoformat() if self.scheduled_at else None
            ),
            "status": self.status.value,
            "tracking_notes": self.tracking_notes,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self) -> str:
        return f"<Transport {self.id} status={self.status.value}>"
