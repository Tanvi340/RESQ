"""Disaster / relief operation model."""
from datetime import datetime, timezone
import enum

from app.extensions import db


class DisasterType(enum.Enum):
    FLOOD = "FLOOD"
    EARTHQUAKE = "EARTHQUAKE"
    CYCLONE = "CYCLONE"
    FIRE = "FIRE"
    LANDSLIDE = "LANDSLIDE"
    DROUGHT = "DROUGHT"
    OTHER = "OTHER"


class DisasterStatus(enum.Enum):
    ACTIVE = "ACTIVE"
    CONTAINED = "CONTAINED"
    RECOVERY = "RECOVERY"
    CLOSED = "CLOSED"


class Disaster(db.Model):
    __tablename__ = "disasters"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    disaster_type = db.Column(db.Enum(DisasterType), nullable=False)
    description = db.Column(db.Text, nullable=True)
    affected_region = db.Column(db.String(255), nullable=False)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    severity = db.Column(db.String(50), nullable=True, default="MODERATE")  # LOW/MODERATE/HIGH/CRITICAL
    status = db.Column(
        db.Enum(DisasterStatus), nullable=False, default=DisasterStatus.ACTIVE, index=True
    )
    start_date = db.Column(db.DateTime, nullable=True)
    end_date = db.Column(db.DateTime, nullable=True)
    created_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Relationships
    creator = db.relationship("User", foreign_keys=[created_by])
    donations = db.relationship("Donation", back_populates="disaster", lazy="dynamic")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "disaster_type": self.disaster_type.value,
            "description": self.description,
            "affected_region": self.affected_region,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "severity": self.severity,
            "status": self.status.value,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self) -> str:
        return f"<Disaster {self.title} ({self.status.value})>"
