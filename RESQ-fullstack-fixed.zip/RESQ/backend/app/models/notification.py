"""Notification model (in-app / logging fallback)."""
from datetime import datetime, timezone
import enum

from app.extensions import db


class NotificationType(enum.Enum):
    DONATION_SUBMITTED = "DONATION_SUBMITTED"
    DONATION_APPROVED = "DONATION_APPROVED"
    DONATION_REJECTED = "DONATION_REJECTED"
    TRANSPORT_SCHEDULED = "TRANSPORT_SCHEDULED"
    DONATION_IN_TRANSIT = "DONATION_IN_TRANSIT"
    DONATION_RECEIVED = "DONATION_RECEIVED"
    HUB_STATUS_CHANGED = "HUB_STATUS_CHANGED"
    CAPACITY_WARNING = "CAPACITY_WARNING"
    SYSTEM = "SYSTEM"


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    notification_type = db.Column(db.Enum(NotificationType), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text, nullable=False)
    related_entity_type = db.Column(db.String(50), nullable=True)
    related_entity_id = db.Column(db.Integer, nullable=True)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False, index=True
    )

    # Relationships
    user = db.relationship("User", back_populates="notifications")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "notification_type": self.notification_type.value,
            "title": self.title,
            "message": self.message,
            "related_entity_type": self.related_entity_type,
            "related_entity_id": self.related_entity_id,
            "is_read": self.is_read,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self) -> str:
        return f"<Notification {self.id} type={self.notification_type.value}>"
