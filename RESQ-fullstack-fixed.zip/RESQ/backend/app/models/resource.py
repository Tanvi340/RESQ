"""Resource model."""
from datetime import datetime, timezone
import enum

from app.extensions import db


class ResourceCategory(enum.Enum):
    CLOTHING = "Clothing"
    BLANKETS = "Blankets"
    FOOD = "Food"
    DRINKING_WATER = "Drinking Water"
    HYGIENE_KITS = "Hygiene Kits"
    MEDICAL_SUPPLIES = "Medical Supplies"
    SHELTER_MATERIALS = "Shelter Materials"
    BABY_SUPPLIES = "Baby Supplies"
    OTHER_ESSENTIALS = "Other Essentials"


class Resource(db.Model):
    __tablename__ = "resources"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(100), nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)
    default_unit = db.Column(db.String(50), nullable=False, default="units")
    handling_notes = db.Column(db.Text, nullable=True)
    storage_requirements = db.Column(db.Text, nullable=True)
    # Approximate volume in liters per unit (for capacity calculations)
    volume_per_unit = db.Column(db.Float, nullable=False, default=1.0)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    requires_special_handling = db.Column(db.Boolean, default=False, nullable=False)
    is_perishable = db.Column(db.Boolean, default=False, nullable=False)

    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Relationships
    donations = db.relationship("Donation", back_populates="resource", lazy="dynamic")
    inventory_items = db.relationship(
        "Inventory", back_populates="resource", lazy="dynamic"
    )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "category": self.category,
            "description": self.description,
            "default_unit": self.default_unit,
            "handling_notes": self.handling_notes,
            "storage_requirements": self.storage_requirements,
            "volume_per_unit": self.volume_per_unit,
            "is_active": self.is_active,
            "requires_special_handling": self.requires_special_handling,
            "is_perishable": self.is_perishable,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self) -> str:
        return f"<Resource {self.name} ({self.category})>"
