"""Audit log model."""
from datetime import datetime, timezone
import json

from app.extensions import db


class AuditLog(db.Model):
    __tablename__ = "audit_logs"

    id = db.Column(db.Integer, primary_key=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    action = db.Column(db.String(100), nullable=False, index=True)
    entity_type = db.Column(db.String(50), nullable=False, index=True)
    entity_id = db.Column(db.Integer, nullable=True)
    previous_state = db.Column(db.Text, nullable=True)
    new_state = db.Column(db.Text, nullable=True)
    extra_data = db.Column(db.Text, nullable=True)
    timestamp = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False, index=True
    )

    # Relationships
    actor = db.relationship("User", back_populates="audit_logs")

    def set_previous_state(self, data: dict) -> None:
        self.previous_state = json.dumps(data) if data else None

    def set_new_state(self, data: dict) -> None:
        self.new_state = json.dumps(data) if data else None

    def set_extra(self, data: dict) -> None:
        self.extra_data = json.dumps(data) if data else None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "actor_id": self.actor_id,
            "action": self.action,
            "entity_type": self.entity_type,
            "entity_id": self.entity_id,
            "previous_state": json.loads(self.previous_state) if self.previous_state else None,
            "new_state": json.loads(self.new_state) if self.new_state else None,
            "extra_data": json.loads(self.extra_data) if self.extra_data else None,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }

    def __repr__(self) -> str:
        return f"<AuditLog {self.action} on {self.entity_type}:{self.entity_id}>"
