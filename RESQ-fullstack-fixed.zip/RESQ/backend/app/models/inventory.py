"""Inventory model."""
from datetime import datetime, timezone

from app.extensions import db


class Inventory(db.Model):
    __tablename__ = "inventory"

    id = db.Column(db.Integer, primary_key=True)
    hub_id = db.Column(db.Integer, db.ForeignKey("hubs.id"), nullable=False, index=True)
    resource_id = db.Column(
        db.Integer, db.ForeignKey("resources.id"), nullable=False, index=True
    )
    available_quantity = db.Column(db.Float, nullable=False, default=0.0)
    reserved_quantity = db.Column(db.Float, nullable=False, default=0.0)
    unit = db.Column(db.String(50), nullable=False, default="units")
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Relationships
    hub = db.relationship("Hub", back_populates="inventory_items")
    resource = db.relationship("Resource", back_populates="inventory_items")

    __table_args__ = (
        db.UniqueConstraint("hub_id", "resource_id", name="uq_inventory_hub_resource"),
        db.CheckConstraint(
            "available_quantity >= 0", name="ck_inventory_available_nonneg"
        ),
        db.CheckConstraint(
            "reserved_quantity >= 0", name="ck_inventory_reserved_nonneg"
        ),
    )

    def to_dict(self, include_relations: bool = False) -> dict:
        data = {
            "id": self.id,
            "hub_id": self.hub_id,
            "resource_id": self.resource_id,
            "available_quantity": self.available_quantity,
            "reserved_quantity": self.reserved_quantity,
            "unit": self.unit,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
        if include_relations:
            if self.resource:
                data["resource"] = self.resource.to_dict()
            if self.hub:
                data["hub_name"] = self.hub.name
        return data

    def __repr__(self) -> str:
        return f"<Inventory hub={self.hub_id} resource={self.resource_id}>"
