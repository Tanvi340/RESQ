"""Flask extensions initialization."""
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from flask_cors import CORS

db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()
cors = CORS()

# Optional OpenAPI (Flask-Smorest) – install flask-smorest if docs needed
try:
    from flask_smorest import Api
    api = Api()
except ImportError:
    api = None
