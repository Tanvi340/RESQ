"""CLI commands."""
import click
from flask.cli import with_appcontext

from app.extensions import db


@click.command("init-db")
@with_appcontext
def init_db():
    """Create all database tables."""
    db.create_all()
    click.echo("Database tables created.")


@click.command("drop-db")
@with_appcontext
def drop_db():
    """Drop all database tables (DANGEROUS)."""
    if click.confirm("This will delete all data. Continue?"):
        db.drop_all()
        click.echo("Database tables dropped.")
