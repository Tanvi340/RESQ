"""Hub schemas."""
from marshmallow import Schema, fields, validate, validates_schema, ValidationError


class HubCreateSchema(Schema):
    name = fields.Str(required=True, validate=validate.Length(min=2, max=200))
    description = fields.Str(allow_none=True)
    address = fields.Str(required=True, validate=validate.Length(min=5, max=500))
    city = fields.Str(required=True, validate=validate.Length(min=2, max=100))
    state = fields.Str(required=True, validate=validate.Length(min=2, max=100))
    pincode = fields.Str(allow_none=True, validate=validate.Length(max=20))
    latitude = fields.Float(required=True, validate=validate.Range(min=-90, max=90))
    longitude = fields.Float(required=True, validate=validate.Range(min=-180, max=180))
    total_storage_capacity = fields.Float(
        required=True, validate=validate.Range(min=0)
    )
    accepted_resource_categories = fields.List(
        fields.Str(), required=True, validate=validate.Length(min=1)
    )
    contact_phone = fields.Str(allow_none=True)
    contact_email = fields.Email(allow_none=True)
    admin_id = fields.Int(allow_none=True)  # only super admin can set


class HubUpdateSchema(Schema):
    name = fields.Str(validate=validate.Length(min=2, max=200))
    description = fields.Str(allow_none=True)
    address = fields.Str(validate=validate.Length(min=5, max=500))
    city = fields.Str(validate=validate.Length(min=2, max=100))
    state = fields.Str(validate=validate.Length(min=2, max=100))
    pincode = fields.Str(allow_none=True)
    latitude = fields.Float(validate=validate.Range(min=-90, max=90))
    longitude = fields.Float(validate=validate.Range(min=-180, max=180))
    total_storage_capacity = fields.Float(validate=validate.Range(min=0))
    accepted_resource_categories = fields.List(fields.Str())
    contact_phone = fields.Str(allow_none=True)
    contact_email = fields.Email(allow_none=True)


class HubStatusSchema(Schema):
    operating_status = fields.Str(
        required=True, validate=validate.OneOf(["ACTIVE", "INACTIVE", "FULL"])
    )


class NearbyHubsSchema(Schema):
    latitude = fields.Float(required=True, validate=validate.Range(min=-90, max=90))
    longitude = fields.Float(required=True, validate=validate.Range(min=-180, max=180))
    radius_km = fields.Float(load_default=50.0, validate=validate.Range(min=0.1, max=500))
    resource_id = fields.Int(allow_none=True)
    resource_category = fields.Str(allow_none=True)
    required_capacity = fields.Float(load_default=0.0, validate=validate.Range(min=0))
    quantity = fields.Float(allow_none=True, validate=validate.Range(min=0))
