"""Authentication schemas."""
from marshmallow import Schema, fields, validate, validates, ValidationError


class RegisterSchema(Schema):
    full_name = fields.Str(required=True, validate=validate.Length(min=2, max=150))
    email = fields.Email(required=True)
    phone_number = fields.Str(allow_none=True, validate=validate.Length(max=20))
    password = fields.Str(required=True, validate=validate.Length(min=8, max=128))
    role = fields.Str(
        load_default="DONOR",
        validate=validate.OneOf(["DONOR", "HUB_ADMIN"]),
    )


class LoginSchema(Schema):
    email = fields.Email(required=True)
    password = fields.Str(required=True)


class ChangePasswordSchema(Schema):
    current_password = fields.Str(required=True)
    new_password = fields.Str(required=True, validate=validate.Length(min=8, max=128))


class RefreshSchema(Schema):
    """Empty body; token comes from header or cookie."""
    pass
