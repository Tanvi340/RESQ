"""Marshmallow schemas."""
from app.schemas.auth_schema import RegisterSchema, LoginSchema, ChangePasswordSchema
from app.schemas.user_schema import UserUpdateSchema, UserResponseSchema
from app.schemas.hub_schema import (
    HubCreateSchema,
    HubUpdateSchema,
    HubStatusSchema,
    NearbyHubsSchema,
)
from app.schemas.resource_schema import ResourceCreateSchema, ResourceUpdateSchema
from app.schemas.donation_schema import (
    DonationCreateSchema,
    DonationRejectSchema,
    DonationApproveSchema,
    DonationListQuerySchema,
)
from app.schemas.inventory_schema import InventoryAdjustSchema
from app.schemas.transport_schema import (
    TransportCreateSchema,
    TransportUpdateSchema,
    TransportScheduleSchema,
)

__all__ = [
    "RegisterSchema",
    "LoginSchema",
    "ChangePasswordSchema",
    "UserUpdateSchema",
    "UserResponseSchema",
    "HubCreateSchema",
    "HubUpdateSchema",
    "HubStatusSchema",
    "NearbyHubsSchema",
    "ResourceCreateSchema",
    "ResourceUpdateSchema",
    "DonationCreateSchema",
    "DonationRejectSchema",
    "DonationApproveSchema",
    "DonationListQuerySchema",
    "InventoryAdjustSchema",
    "TransportCreateSchema",
    "TransportUpdateSchema",
    "TransportScheduleSchema",
]
