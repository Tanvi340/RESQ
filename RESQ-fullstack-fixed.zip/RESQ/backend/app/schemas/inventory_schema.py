"""Inventory schemas."""
from marshmallow import Schema, fields, validate


class InventoryAdjustSchema(Schema):
    hub_id = fields.Int(required=True)
    resource_id = fields.Int(required=True)
    quantity_change = fields.Float(required=True)  # can be negative
    reason = fields.Str(required=True, validate=validate.Length(min=5, max=500))
    unit = fields.Str(allow_none=True)
