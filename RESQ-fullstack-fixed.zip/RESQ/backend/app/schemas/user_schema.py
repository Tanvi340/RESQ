"""User schemas."""
from marshmallow import Schema, fields, validate


class UserUpdateSchema(Schema):
    full_name = fields.Str(validate=validate.Length(min=2, max=150))
    phone_number = fields.Str(allow_none=True, validate=validate.Length(max=20))


class UserResponseSchema(Schema):
    id = fields.Int()
    full_name = fields.Str()
    email = fields.Email()
    phone_number = fields.Str(allow_none=True)
    role = fields.Str()
    is_active = fields.Bool()
    created_at = fields.Str()
    updated_at = fields.Str()
