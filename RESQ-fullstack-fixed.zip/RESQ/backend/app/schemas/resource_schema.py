"""Resource schemas."""
from marshmallow import Schema, fields, validate


class ResourceCreateSchema(Schema):
    name = fields.Str(required=True, validate=validate.Length(min=2, max=200))
    category = fields.Str(required=True)
    description = fields.Str(allow_none=True)
    default_unit = fields.Str(load_default="units")
    handling_notes = fields.Str(allow_none=True)
    storage_requirements = fields.Str(allow_none=True)
    volume_per_unit = fields.Float(load_default=1.0, validate=validate.Range(min=0))
    requires_special_handling = fields.Bool(load_default=False)
    is_perishable = fields.Bool(load_default=False)


class ResourceUpdateSchema(Schema):
    name = fields.Str(validate=validate.Length(min=2, max=200))
    category = fields.Str()
    description = fields.Str(allow_none=True)
    default_unit = fields.Str()
    handling_notes = fields.Str(allow_none=True)
    storage_requirements = fields.Str(allow_none=True)
    volume_per_unit = fields.Float(validate=validate.Range(min=0))
    is_active = fields.Bool()
    requires_special_handling = fields.Bool()
    is_perishable = fields.Bool()
