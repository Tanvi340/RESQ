"""Donation schemas."""
from marshmallow import Schema, fields, validate


class DonationCreateSchema(Schema):
    hub_id = fields.Int(required=True)
    resource_id = fields.Int(required=True)
    quantity = fields.Float(required=True, validate=validate.Range(min=0.01))
    unit = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    condition = fields.Str(load_default="Good", validate=validate.Length(max=100))
    description = fields.Str(allow_none=True)
    donor_latitude = fields.Float(allow_none=True, validate=validate.Range(min=-90, max=90))
    donor_longitude = fields.Float(
        allow_none=True, validate=validate.Range(min=-180, max=180)
    )
    donor_address = fields.Str(allow_none=True, validate=validate.Length(max=500))
    pickup_required = fields.Bool(load_default=False)
    preferred_delivery_date = fields.DateTime(allow_none=True)
    disaster_id = fields.Int(allow_none=True)
    # Optional explicit volume; otherwise computed from resource.volume_per_unit * quantity
    estimated_volume = fields.Float(allow_none=True, validate=validate.Range(min=0))


class DonationRejectSchema(Schema):
    rejection_reason = fields.Str(required=True, validate=validate.Length(min=5, max=1000))
    admin_notes = fields.Str(allow_none=True)


class DonationApproveSchema(Schema):
    admin_notes = fields.Str(allow_none=True)


class DonationListQuerySchema(Schema):
    status = fields.Str(allow_none=True)
    hub_id = fields.Int(allow_none=True)
    page = fields.Int(load_default=1, validate=validate.Range(min=1))
    per_page = fields.Int(load_default=20, validate=validate.Range(min=1, max=100))
