"""Transport schemas."""
from marshmallow import Schema, fields, validate


class TransportCreateSchema(Schema):
    responsible_party = fields.Str(
        required=True, validate=validate.OneOf(["DONOR", "HUB_ADMIN"])
    )
    transport_method = fields.Str(allow_none=True, validate=validate.Length(max=100))
    pickup_address = fields.Str(allow_none=True, validate=validate.Length(max=500))
    destination_address = fields.Str(allow_none=True, validate=validate.Length(max=500))
    scheduled_at = fields.DateTime(allow_none=True)
    tracking_notes = fields.Str(allow_none=True)


class TransportUpdateSchema(Schema):
    transport_method = fields.Str(allow_none=True, validate=validate.Length(max=100))
    pickup_address = fields.Str(allow_none=True, validate=validate.Length(max=500))
    destination_address = fields.Str(allow_none=True, validate=validate.Length(max=500))
    scheduled_at = fields.DateTime(allow_none=True)
    tracking_notes = fields.Str(allow_none=True)


class TransportScheduleSchema(Schema):
    scheduled_at = fields.DateTime(required=True)
    transport_method = fields.Str(allow_none=True)
    pickup_address = fields.Str(allow_none=True)
    destination_address = fields.Str(allow_none=True)
    tracking_notes = fields.Str(allow_none=True)
