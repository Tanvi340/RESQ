# RESQ Backend

**Disaster Relief Resource Donation & Hub Coordination Platform**

RESQ connects donors of physical resources (clothes, water, food, hygiene kits, medical supplies, etc.) with nearby disaster-relief collection hubs that have sufficient storage capacity. It manages donation requests, hub capacity reservations, approval workflows, transport coordination, and inventory updates.

---

## Features

- JWT authentication with role-based access (DONOR, HUB_ADMIN, SUPER_ADMIN)
- Hub registration, capacity tracking, and status management
- Intelligent nearby-hub recommendation (Haversine distance + capacity + category compatibility)
- Full donation lifecycle: PENDING → APPROVED → TRANSPORT → IN_TRANSIT → RECEIVED
- Atomic capacity reservation on approval; release on cancel; occupy on receipt
- Inventory tracking per hub and resource
- Transport coordination (donor-managed or hub-admin-managed)
- Disaster/relief operation association
- In-app notification logging
- Audit trail for sensitive actions
- OpenAPI-ready structure, consistent JSON responses
- SQLite for local development; PostgreSQL-ready for production

---

## Technology Stack

| Component        | Technology              |
|------------------|-------------------------|
| Language         | Python 3.11+            |
| Framework        | Flask 3                 |
| ORM              | Flask-SQLAlchemy        |
| Migrations       | Flask-Migrate           |
| Auth             | Flask-JWT-Extended      |
| Validation       | Marshmallow             |
| CORS             | Flask-CORS              |
| Config           | python-dotenv           |
| Testing          | pytest + Flask test client |
| Distance         | Haversine formula       |

---

## Folder Structure

```
backend/
├── app/
│   ├── __init__.py          # Application factory
│   ├── config.py
│   ├── extensions.py
│   ├── commands.py
│   ├── models/              # SQLAlchemy models
│   ├── schemas/             # Marshmallow schemas
│   ├── routes/              # API blueprints
│   ├── services/            # Business logic
│   └── utils/               # Helpers, exceptions, decorators
├── tests/
├── migrations/
├── uploads/
├── instance/
├── .env.example
├── requirements.txt
├── run.py
├── seed.py
├── pytest.ini
└── README.md
```

---

## Donation Workflow

1. Donor registers / logs in.
2. Donor selects resource, quantity, location; backend recommends nearby compatible hubs.
3. Donor submits donation → status `PENDING_APPROVAL` (no capacity reserved yet).
4. Hub admin approves → capacity reserved atomically → status `TRANSPORT_PENDING`.
5. Donor or hub admin arranges transport → `TRANSPORT_ARRANGED` / `IN_TRANSIT`.
6. Hub admin confirms receipt → reservation released, capacity occupied, inventory increased → `RECEIVED`.
7. Donor can track status throughout; cancel releases reservation safely.

**Capacity rules**

- Capacity is measured in a normalized volume unit (liters equivalent).
- `available = total - reserved - occupied`
- Reservation happens only on approval.
- Receipt converts reserved → occupied and increments inventory quantity.
- Partial receipts are not supported in v1.

---

## Quick Start (Windows PowerShell)

```powershell
# Clone / enter backend folder
cd RESQ\backend

# Create virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt

# Configure environment
Copy-Item .env.example .env
# Edit .env if needed (defaults work for SQLite)

# Initialize database
python -c "from app import create_app; from app.extensions import db; app=create_app(); app.app_context().push(); db.create_all(); print('DB ready')"

# Seed sample data
python seed.py

# Run server
python run.py
```

Server starts at `http://127.0.0.1:5000`. Health check: `GET /api/v1/health`.

### Linux / macOS

```bash
cd RESQ/backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -c "from app import create_app; from app.extensions import db; app=create_app(); app.app_context().push(); db.create_all()"
python seed.py
python run.py
```

---

## Development Credentials (seed data only)

| Role         | Email                  | Password       |
|--------------|------------------------|----------------|
| Super Admin  | superadmin@resq.local  | SuperAdmin@123 |
| Hub Admin    | admin1@resq.local      | HubAdmin@123   |
| Donor        | donor1@resq.local      | Donor@12345    |

**Never use these credentials in production.**

---

## API Overview

Base path: `/api/v1`

### Auth
| Method | Path | Description |
|--------|------|-------------|
| POST | `/auth/register` | Register (DONOR or HUB_ADMIN only) |
| POST | `/auth/login` | Login → access + refresh tokens |
| POST | `/auth/refresh` | Refresh access token |
| POST | `/auth/logout` | Logout (client discards token) |
| GET  | `/auth/me` | Current user |
| POST | `/auth/change-password` | Change password |
| PATCH| `/users/me` | Update profile |

### Hubs
| Method | Path | Description |
|--------|------|-------------|
| GET  | `/hubs` | List active hubs |
| GET  | `/hubs/nearby` | Recommend nearby hubs |
| GET  | `/hubs/<id>` | Hub detail |
| GET  | `/hubs/<id>/capacity` | Capacity summary |
| GET  | `/hubs/<id>/inventory` | Hub inventory |
| POST | `/hubs` | Create hub (admin) |
| PATCH| `/hubs/<id>` | Update hub |
| PATCH| `/hubs/<id>/status` | Change status |

**Nearby query params:** `latitude`, `longitude`, `radius_km`, `resource_id` or `resource_category`, `quantity` / `required_capacity`

### Donations
| Method | Path | Description |
|--------|------|-------------|
| POST | `/donations` | Create donation |
| GET  | `/donations` | List (role-scoped) |
| GET  | `/donations/my` | My donations |
| GET  | `/donations/<id>` | Detail |
| PATCH| `/donations/<id>/cancel` | Cancel |
| POST | `/donations/<id>/approve` | Approve (hub admin) |
| POST | `/donations/<id>/reject` | Reject |
| POST | `/donations/<id>/confirm-receipt` | Confirm receipt |
| GET  | `/donations/<id>/history` | Audit history |

### Transport
| Method | Path | Description |
|--------|------|-------------|
| POST | `/donations/<id>/transport` | Create transport |
| GET  | `/donations/<id>/transport` | Get transport |
| PATCH| `/transport/<id>` | Update |
| POST | `/transport/<id>/schedule` | Schedule |
| POST | `/transport/<id>/mark-picked-up` | Mark picked up |
| POST | `/transport/<id>/mark-in-transit` | Mark in transit |
| POST | `/transport/<id>/mark-delivered` | Mark delivered |

### Inventory / Admin / Disasters
- `GET /inventory`, `GET /inventory/<hub_id>`, `POST /inventory/adjustments`
- `GET /admin/dashboard`
- `GET /admin/resources`
- `GET/POST/PATCH /disasters`, `GET /disasters/<id>/hubs`, `GET /disasters/<id>/donations`
- `GET /health`, `GET /ready`

---

## Response Format

**Success**
```json
{
  "success": true,
  "message": "Donation created successfully",
  "data": { "id": 101, "status": "PENDING_APPROVAL" },
  "meta": { "page": 1, "total": 10 }
}
```

**Error**
```json
{
  "success": false,
  "message": "Insufficient available capacity",
  "error_code": "INSUFFICIENT_CAPACITY"
}
```

HTTP status codes: 200, 201, 400, 401, 403, 404, 409, 422, 500.

---

## Authentication (Flutter)

```dart
// Login
final response = await http.post(
  Uri.parse('$baseUrl/api/v1/auth/login'),
  headers: {'Content-Type': 'application/json'},
  body: jsonEncode({'email': email, 'password': password}),
);
final data = jsonDecode(response.body);
if (data['success'] == true) {
  final accessToken = data['data']['access_token'];
  final refreshToken = data['data']['refresh_token'];
  // Store securely
}

// Authenticated request
final headers = {
  'Content-Type': 'application/json',
  'Authorization': 'Bearer $accessToken',
};

// Nearby hubs
final nearby = await http.get(
  Uri.parse('$baseUrl/api/v1/hubs/nearby?latitude=13.08&longitude=80.27&radius_km=30&resource_id=5&quantity=20'),
  headers: headers,
);

// Create donation
final create = await http.post(
  Uri.parse('$baseUrl/api/v1/donations'),
  headers: headers,
  body: jsonEncode({
    'hub_id': 1,
    'resource_id': 5,
    'quantity': 20,
    'unit': 'bottles',
    'donor_latitude': 13.08,
    'donor_longitude': 80.27,
  }),
);

// My donations
final mine = await http.get(
  Uri.parse('$baseUrl/api/v1/donations/my'),
  headers: headers,
);
```

All timestamps are ISO 8601 UTC.

---

## Running Tests

```bash
# From backend/ with venv active
pytest -v
# or
python -m pytest tests/ -v
```

Tests use an in-memory SQLite database and isolated fixtures. They cover auth, hub recommendations, donation lifecycle, capacity, inventory, and transport.

---

## Migrations (optional)

```bash
export FLASK_APP=run.py
flask db init          # once
flask db migrate -m "initial"
flask db upgrade
```

For simple local use, `db.create_all()` (used by seed and the init snippet above) is sufficient.

---

## Production Considerations

- Set strong `SECRET_KEY` and `JWT_SECRET_KEY` (never defaults).
- Use PostgreSQL: `DATABASE_URL=postgresql://user:pass@host:5432/resq_db`
- Run behind gunicorn: `gunicorn -w 4 -b 0.0.0.0:8000 "run:app"`
- Restrict `CORS_ORIGINS` to your frontend domains.
- Enable HTTPS and secure cookie flags if using cookies.
- SQLite locking is sufficient for local testing; PostgreSQL `SELECT FOR UPDATE` is used for capacity reservation in production.
- Do not commit `.env`, uploaded private files, or real credentials.

---

## Known Limitations (v1)

- No live GPS tracking or built-in vehicle fleet.
- No partial delivery support.
- Notifications are stored in DB + logged; no push/SMS/email without optional external providers.
- Rate limiting is not enabled by default (document optional Flask-Limiter integration).
- Recommendation engine is rule-based (distance + capacity + category), not ML.

---

## License

MIT (hackathon / educational use). Adapt as needed for your project.
