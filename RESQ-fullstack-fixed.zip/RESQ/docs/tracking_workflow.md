# Tracking workflow

## Statuses

Delivery: PLANNED → ASSIGNED → IN_TRANSIT → ARRIVED → COMPLETED (or CANCELLED)

## Location API

- `POST /api/v1/deliveries/:id/locations` — agent submits lat/lon  
- `GET /api/v1/deliveries/:id/location` — latest + freshness  
- `GET /api/v1/deliveries/:id/locations` — history  

Only assigned agent, hub admin, or super admin may submit.  
Donors may read only deliveries linked via allocation.

## Freshness

- LIVE: last update ≤ 60 seconds  
- STALE: older than 60 seconds  
- LOCATION_UNAVAILABLE: no points yet  
- COMPLETED: delivery finished  

## Simulation

`is_simulated: true` on location payload; UI must show SIMULATED TRACKING. Disabled by default in production builds via `AppConfig.enableSimulatedTracking`.
