# RESQ — Disaster Relief Resource Coordination & Live Delivery Tracking

RESQ connects **donors**, **relief hubs**, **hub administrators**, and **delivery agents** to coordinate physical resource donations and track relief deliveries to disaster-affected areas.

## Two workflows

### A. Donation → Hub
1. Donor creates a donation request  
2. System recommends nearby hubs (distance + capacity + category)  
3. Hub admin approves → capacity reserved  
4. Hub confirms receipt → inventory updated  

### B. Hub → Disaster area
1. Admin creates a relief delivery from hub inventory  
2. Assigns a delivery agent  
3. Agent dispatches and shares GPS (or demo simulation)  
4. Map shows hub, destination, and live/stale agent location  
5. Agent or admin confirms completion  

## Stack

| Layer | Tech |
|-------|------|
| Frontend | Flutter (Material 3), flutter_map + OpenStreetMap, geolocator |
| Backend | Python 3.11+, Flask, SQLAlchemy, JWT |
| DB | SQLite (local) / PostgreSQL (production) |

## Quick start (Windows PowerShell)

### Backend

```powershell
cd RESQ\backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install Flask Flask-SQLAlchemy Flask-Migrate Flask-JWT-Extended Flask-CORS marshmallow python-dotenv Werkzeug SQLAlchemy pytest email-validator
copy .env.example .env
python -c "from app import create_app; from app.extensions import db; app=create_app(); app.app_context().push(); db.create_all(); print('DB ready')"
python seed.py
python run.py
```

Health: http://127.0.0.1:5000/api/v1/health

### Frontend

```powershell
cd RESQ\frontend
flutter pub get
# Set API URL if needed (Android emulator: 10.0.2.2)
flutter run
```

In `lib/config/api_config.dart`:
- Emulator: `http://10.0.2.2:5000/api/v1`
- Desktop / iOS sim: `http://127.0.0.1:5000/api/v1`
- Physical phone: `http://<your-PC-LAN-IP>:5000/api/v1`

## Demo credentials

| Role | Email | Password |
|------|-------|----------|
| Super Admin | superadmin@resq.local | SuperAdmin@123 |
| Hub Admin | admin1@resq.local | HubAdmin@123 |
| Donor | donor1@resq.local | Donor@12345 |
| Delivery Agent | agent1@resq.local | Agent@12345 |

## Tracking

- **Live GPS**: Delivery agent opens assigned delivery → “Share live GPS” (device permission required).  
- **Simulated**: “Simulate track” walks coordinates from hub toward destination; map is labelled as simulated.  
- Polling: map refreshes every ~10s while open.  
- Freshness: LIVE (&lt;60s), STALE, or LOCATION UNAVAILABLE.

## Project layout

```
RESQ/
├── backend/     Flask API, models, seed, tests
├── frontend/    Flutter app
└── docs/        Architecture notes
```

## Known limitations

- Straight-line map guide is not a road route (optional routing APIs not required).  
- Background GPS needs extra Android foreground-service setup (not claimed in MVP).  
- Simulated tracking is for demos only.  
- No official government disaster-data integration.

## License

MIT — hackathon / educational use.
